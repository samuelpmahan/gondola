module gobi.generated/compiled

go 1.27.0

require github.com/samuelpmahan/gondola v0.0.0

replace github.com/samuelpmahan/gondola => "/home/runner/work/gondola/gondola"
