// Generated file based on perl_groups.go
// Updated when compliance tests are re-run, DO NOT EDIT!

import * as $ from "@goscript/builtin/index.js"
import * as __goscript_parse from "./parse.gs.ts"
import "@goscript/unicode/index.js"
import "@goscript/strconv/index.js"
import "@goscript/sort/index.js"
import "@goscript/strings/index.js"
import "@goscript/sync/index.js"
import "@goscript/unicode/utf8/index.js"
import "@goscript/slices/index.js"

export let code1: $.Slice<number> = $.typedSliceOf(Int32Array, [0x30, 0x39]) as $.Slice<number>

export function __goscript_set_code1(__goscriptValue: $.Slice<number>): void {
	code1 = __goscriptValue
}

export let code2: $.Slice<number> = $.typedSliceOf(Int32Array, [0x9, 0xa, 0xc, 0xd, 0x20, 0x20]) as $.Slice<number>

export function __goscript_set_code2(__goscriptValue: $.Slice<number>): void {
	code2 = __goscriptValue
}

export let code3: $.Slice<number> = $.typedSliceOf(Int32Array, [0x30, 0x39, 0x41, 0x5a, 0x5f, 0x5f, 0x61, 0x7a]) as $.Slice<number>

export function __goscript_set_code3(__goscriptValue: $.Slice<number>): void {
	code3 = __goscriptValue
}

export var perlGroup: globalThis.Map<string, __goscript_parse.charGroup> | null

export function __goscript_init_perlGroup(): void {
	if (((perlGroup) as any) === undefined) {
		perlGroup = $.makeMap<string, __goscript_parse.charGroup>([["\\d", new __goscript_parse.charGroup(true, 1, code1)], ["\\D", new __goscript_parse.charGroup(true, -1, code1)], ["\\s", new __goscript_parse.charGroup(true, 1, code2)], ["\\S", new __goscript_parse.charGroup(true, -1, code2)], ["\\w", new __goscript_parse.charGroup(true, 1, code3)], ["\\W", new __goscript_parse.charGroup(true, -1, code3)]])
	}
}

export function __goscript_get_perlGroup(): globalThis.Map<string, __goscript_parse.charGroup> | null {
	if (((perlGroup) as any) === undefined) {
		__goscript_init_perlGroup()
	}
	return perlGroup
}

export function __goscript_set_perlGroup(__goscriptValue: globalThis.Map<string, __goscript_parse.charGroup> | null): void {
	perlGroup = __goscriptValue
}

export let code4: $.Slice<number> = $.typedSliceOf(Int32Array, [0x30, 0x39, 0x41, 0x5a, 0x61, 0x7a]) as $.Slice<number>

export function __goscript_set_code4(__goscriptValue: $.Slice<number>): void {
	code4 = __goscriptValue
}

export let code5: $.Slice<number> = $.typedSliceOf(Int32Array, [0x41, 0x5a, 0x61, 0x7a]) as $.Slice<number>

export function __goscript_set_code5(__goscriptValue: $.Slice<number>): void {
	code5 = __goscriptValue
}

export let code6: $.Slice<number> = $.typedSliceOf(Int32Array, [0x0, 0x7f]) as $.Slice<number>

export function __goscript_set_code6(__goscriptValue: $.Slice<number>): void {
	code6 = __goscriptValue
}

export let code7: $.Slice<number> = $.typedSliceOf(Int32Array, [0x9, 0x9, 0x20, 0x20]) as $.Slice<number>

export function __goscript_set_code7(__goscriptValue: $.Slice<number>): void {
	code7 = __goscriptValue
}

export let code8: $.Slice<number> = $.typedSliceOf(Int32Array, [0x0, 0x1f, 0x7f, 0x7f]) as $.Slice<number>

export function __goscript_set_code8(__goscriptValue: $.Slice<number>): void {
	code8 = __goscriptValue
}

export let code9: $.Slice<number> = $.typedSliceOf(Int32Array, [0x30, 0x39]) as $.Slice<number>

export function __goscript_set_code9(__goscriptValue: $.Slice<number>): void {
	code9 = __goscriptValue
}

export let code10: $.Slice<number> = $.typedSliceOf(Int32Array, [0x21, 0x7e]) as $.Slice<number>

export function __goscript_set_code10(__goscriptValue: $.Slice<number>): void {
	code10 = __goscriptValue
}

export let code11: $.Slice<number> = $.typedSliceOf(Int32Array, [0x61, 0x7a]) as $.Slice<number>

export function __goscript_set_code11(__goscriptValue: $.Slice<number>): void {
	code11 = __goscriptValue
}

export let code12: $.Slice<number> = $.typedSliceOf(Int32Array, [0x20, 0x7e]) as $.Slice<number>

export function __goscript_set_code12(__goscriptValue: $.Slice<number>): void {
	code12 = __goscriptValue
}

export let code13: $.Slice<number> = $.typedSliceOf(Int32Array, [0x21, 0x2f, 0x3a, 0x40, 0x5b, 0x60, 0x7b, 0x7e]) as $.Slice<number>

export function __goscript_set_code13(__goscriptValue: $.Slice<number>): void {
	code13 = __goscriptValue
}

export let code14: $.Slice<number> = $.typedSliceOf(Int32Array, [0x9, 0xd, 0x20, 0x20]) as $.Slice<number>

export function __goscript_set_code14(__goscriptValue: $.Slice<number>): void {
	code14 = __goscriptValue
}

export let code15: $.Slice<number> = $.typedSliceOf(Int32Array, [0x41, 0x5a]) as $.Slice<number>

export function __goscript_set_code15(__goscriptValue: $.Slice<number>): void {
	code15 = __goscriptValue
}

export let code16: $.Slice<number> = $.typedSliceOf(Int32Array, [0x30, 0x39, 0x41, 0x5a, 0x5f, 0x5f, 0x61, 0x7a]) as $.Slice<number>

export function __goscript_set_code16(__goscriptValue: $.Slice<number>): void {
	code16 = __goscriptValue
}

export let code17: $.Slice<number> = $.typedSliceOf(Int32Array, [0x30, 0x39, 0x41, 0x46, 0x61, 0x66]) as $.Slice<number>

export function __goscript_set_code17(__goscriptValue: $.Slice<number>): void {
	code17 = __goscriptValue
}

export var posixGroup: globalThis.Map<string, __goscript_parse.charGroup> | null

export function __goscript_init_posixGroup(): void {
	if (((posixGroup) as any) === undefined) {
		posixGroup = $.makeMap<string, __goscript_parse.charGroup>([["[:alnum:]", new __goscript_parse.charGroup(true, 1, code4)], ["[:^alnum:]", new __goscript_parse.charGroup(true, -1, code4)], ["[:alpha:]", new __goscript_parse.charGroup(true, 1, code5)], ["[:^alpha:]", new __goscript_parse.charGroup(true, -1, code5)], ["[:ascii:]", new __goscript_parse.charGroup(true, 1, code6)], ["[:^ascii:]", new __goscript_parse.charGroup(true, -1, code6)], ["[:blank:]", new __goscript_parse.charGroup(true, 1, code7)], ["[:^blank:]", new __goscript_parse.charGroup(true, -1, code7)], ["[:cntrl:]", new __goscript_parse.charGroup(true, 1, code8)], ["[:^cntrl:]", new __goscript_parse.charGroup(true, -1, code8)], ["[:digit:]", new __goscript_parse.charGroup(true, 1, code9)], ["[:^digit:]", new __goscript_parse.charGroup(true, -1, code9)], ["[:graph:]", new __goscript_parse.charGroup(true, 1, code10)], ["[:^graph:]", new __goscript_parse.charGroup(true, -1, code10)], ["[:lower:]", new __goscript_parse.charGroup(true, 1, code11)], ["[:^lower:]", new __goscript_parse.charGroup(true, -1, code11)], ["[:print:]", new __goscript_parse.charGroup(true, 1, code12)], ["[:^print:]", new __goscript_parse.charGroup(true, -1, code12)], ["[:punct:]", new __goscript_parse.charGroup(true, 1, code13)], ["[:^punct:]", new __goscript_parse.charGroup(true, -1, code13)], ["[:space:]", new __goscript_parse.charGroup(true, 1, code14)], ["[:^space:]", new __goscript_parse.charGroup(true, -1, code14)], ["[:upper:]", new __goscript_parse.charGroup(true, 1, code15)], ["[:^upper:]", new __goscript_parse.charGroup(true, -1, code15)], ["[:word:]", new __goscript_parse.charGroup(true, 1, code16)], ["[:^word:]", new __goscript_parse.charGroup(true, -1, code16)], ["[:xdigit:]", new __goscript_parse.charGroup(true, 1, code17)], ["[:^xdigit:]", new __goscript_parse.charGroup(true, -1, code17)]])
	}
}

export function __goscript_get_posixGroup(): globalThis.Map<string, __goscript_parse.charGroup> | null {
	if (((posixGroup) as any) === undefined) {
		__goscript_init_posixGroup()
	}
	return posixGroup
}

export function __goscript_set_posixGroup(__goscriptValue: globalThis.Map<string, __goscript_parse.charGroup> | null): void {
	posixGroup = __goscriptValue
}
