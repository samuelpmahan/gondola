// Generated file based on app.go
// Updated when compliance tests are re-run, DO NOT EDIT!

import * as $ from "@goscript/builtin/index.js"
import * as strconv from "@goscript/strconv/index.js"
import * as gobi from "@goscript/github.com/samuelpmahan/gondola/gobi/index.js"
import "@goscript/github.com/samuelpmahan/gondola/gobi/index.js"

$.registerTypePackagePath("github.com/samuelpmahan/gondola/fixtures/compiled/list", ["list.Row", "list.State"])

export class Row {
	public declare ID: bigint

	public declare Label: string

	public declare Checked: boolean

	constructor(__goscriptValue?: boolean, ID$?: bigint, Label$?: string, Checked$?: boolean) {
		this.ID = ID$ ?? 0n
		this.Label = Label$ ?? ""
		this.Checked = Checked$ ?? false
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): Row {
		return new Row(true, this.ID, this.Label, this.Checked)
	}

	public __goscriptAssign(source: Row): this {
		this.ID = source.ID
		this.Label = source.Label
		this.Checked = source.Checked
		return this
	}

	static __typeInfo = $.registerStructType(
		"list.Row",
		() => new Row(),
		() => [],
		Row,
		() => [/* @__PURE__ */ $.structField("ID", /* @__PURE__ */ $.basicType("uint64"), [0], 0, true), /* @__PURE__ */ $.structField("Label", /* @__PURE__ */ $.basicType("string"), [1], 8, true), /* @__PURE__ */ $.structField("Checked", /* @__PURE__ */ $.basicType("bool"), [2], 24, true)]
	)
}

export class State {
	public declare Rows: $.Slice<Row>

	public declare NextID: bigint

	constructor(__goscriptValue?: boolean, Rows$?: $.Slice<Row>, NextID$?: bigint) {
		this.Rows = Rows$ ?? (null! as $.Slice<Row>)
		this.NextID = NextID$ ?? 0n
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): State {
		return new State(true, this.Rows, this.NextID)
	}

	public __goscriptAssign(source: State): this {
		this.Rows = source.Rows
		this.NextID = source.NextID
		return this
	}

	static __typeInfo = $.registerStructType(
		"list.State",
		() => new State(),
		() => [],
		State,
		() => [/* @__PURE__ */ $.structField("Rows", /* @__PURE__ */ $.sliceType("list.Row"), [0], 0, true), /* @__PURE__ */ $.structField("NextID", /* @__PURE__ */ $.basicType("uint64"), [1], 24, true)]
	)
}

export function Init(): State {
	return new State(true, null)
}

export function Update(state: State, message: gobi.Message): [State, $.Slice<gobi.Effect>] {
	switch (message.Name) {
		case "add":
		{
			if (state.NextID < 9007199254740991n) {
				state.NextID++
				if (state.Rows == null) {
					state.Rows = $.makeSlice<Row>(0, undefined, undefined, () => new Row(true))
				}
				state.Rows = $.appendOne(state.Rows, new Row(true, state.NextID))
			}
			break
		}
		case "reset":
		{
			state.Rows = $.makeSlice<Row>(0, undefined, undefined, () => new Row(true))
			break
		}
		default:
		{
			state = state.__goscriptAssign(updateRows((state).clone(), message))
			break
		}
	}
	return [state, null]
}

export function updateRows(state: State, message: gobi.Message): State {
	for (let index = 0; index < $.sliceLen(state.Rows); index++) {
		let id = strconv.FormatUint($.plainSliceIndex(state.Rows!, index).ID, 10)
		if ($.stringEqual(message.Name, ("edit/" + id))) {
			$.plainSliceIndex(state.Rows!, index).Label = message.Arg
		} else {
			if (($.stringEqual(message.Name, ("check/" + id))) && (($.stringEqual(message.Arg, "true")) || ($.stringEqual(message.Arg, "false")))) {
				$.plainSliceIndex(state.Rows!, index).Checked = $.stringEqual(message.Arg, "true")
			} else {
				if (($.stringEqual(message.Name, ("move-up/" + id))) && (index > 0)) {
					let __goscriptAssign0_0: Row = ($.plainSliceIndex(state.Rows!, index - 1)).clone()
					let __goscriptAssign0_1: Row = ($.plainSliceIndex(state.Rows!, index)).clone()
					$.sliceElems(state.Rows!)[$.sliceSlot(state.Rows!, index)].__goscriptAssign(__goscriptAssign0_0)
					$.sliceElems(state.Rows!)[$.sliceSlot(state.Rows!, index - 1)].__goscriptAssign(__goscriptAssign0_1)
					return (state).clone()
				} else {
					if ($.stringEqual(message.Name, ("remove/" + id))) {
						state.Rows = $.appendSlice($.goSlice(state.Rows, undefined, index), $.goSlice(state.Rows, index + 1, undefined))
						if ($.sliceLen(state.Rows) == 0) {
							state.Rows = $.makeSlice<Row>(0, undefined, undefined, () => new Row(true))
						}
						return (state).clone()
					}
				}
			}
		}
	}
	return (state).clone()
}
