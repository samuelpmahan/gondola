// Generated file based on trace.go
// Updated when compliance tests are re-run, DO NOT EDIT!

import * as $ from "@goscript/builtin/index.js"
import * as fmt from "@goscript/fmt/index.js"
import * as gobi from "@goscript/github.com/samuelpmahan/gondola/gobi/index.js"
import * as __goscript_contract from "./contract.gs.ts"
import * as __goscript_value from "./value.gs.ts"
import * as __goscript_view from "./view.gs.ts"
import "./view.gs.ts"

$.registerTypePackagePath("github.com/samuelpmahan/gondola/compilercontract", ["compilercontract.EffectKind", "compilercontract.Action", "compilercontract.MessageValue", "compilercontract.EffectValue", "compilercontract.NodeRecord", "compilercontract.AttrRecord", "compilercontract.StyleRecord", "compilercontract.HandlerRecord", "compilercontract.EffectRequest", "compilercontract.EffectCompletion", "compilercontract.DOMControl", "compilercontract.DOMSnapshot", "compilercontract.Tick", "compilercontract.Trace", "compilercontract.HostStep", "compilercontract.HostScript", "compilercontract.ViewRecord"])

export type EffectKind = string

export class Action {
	public declare Path: string

	public declare Event: string

	public declare Value: string

	constructor(__goscriptValue?: boolean, Path$?: string, Event$?: string, Value$?: string) {
		this.Path = Path$ ?? ""
		this.Event = Event$ ?? ""
		this.Value = Value$ ?? ""
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): Action {
		return new Action(true, this.Path, this.Event, this.Value)
	}

	public __goscriptAssign(source: Action): this {
		this.Path = source.Path
		this.Event = source.Event
		this.Value = source.Value
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.Action",
		() => new Action(),
		() => [],
		Action,
		() => [/* @__PURE__ */ $.structField("Path", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"path\"" }), /* @__PURE__ */ $.structField("Event", /* @__PURE__ */ $.basicType("string"), [1], 16, true, { tag: "json:\"event\"" }), /* @__PURE__ */ $.structField("Value", /* @__PURE__ */ $.basicType("string"), [2], 32, true, { tag: "json:\"value\"" })]
	)
}

export class MessageValue {
	public declare Name: string

	public declare Arg: string

	constructor(__goscriptValue?: boolean, Name$?: string, Arg$?: string) {
		this.Name = Name$ ?? ""
		this.Arg = Arg$ ?? ""
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): MessageValue {
		return new MessageValue(true, this.Name, this.Arg)
	}

	public __goscriptAssign(source: MessageValue): this {
		this.Name = source.Name
		this.Arg = source.Arg
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.MessageValue",
		() => new MessageValue(),
		() => [],
		MessageValue,
		() => [/* @__PURE__ */ $.structField("Name", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"name\"" }), /* @__PURE__ */ $.structField("Arg", /* @__PURE__ */ $.basicType("string"), [1], 16, true, { tag: "json:\"arg\"" })]
	)
}

export class EffectValue {
	public declare Kind: string

	public declare Name: string

	public declare Arg: string

	public declare Reply: string

	constructor(__goscriptValue?: boolean, Kind$?: string, Name$?: string, Arg$?: string, Reply$?: string) {
		this.Kind = Kind$ ?? ""
		this.Name = Name$ ?? ""
		this.Arg = Arg$ ?? ""
		this.Reply = Reply$ ?? ""
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): EffectValue {
		return new EffectValue(true, this.Kind, this.Name, this.Arg, this.Reply)
	}

	public __goscriptAssign(source: EffectValue): this {
		this.Kind = source.Kind
		this.Name = source.Name
		this.Arg = source.Arg
		this.Reply = source.Reply
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.EffectValue",
		() => new EffectValue(),
		() => [],
		EffectValue,
		() => [/* @__PURE__ */ $.structField("Kind", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"kind\"" }), /* @__PURE__ */ $.structField("Name", /* @__PURE__ */ $.basicType("string"), [1], 16, true, { tag: "json:\"name\"" }), /* @__PURE__ */ $.structField("Arg", /* @__PURE__ */ $.basicType("string"), [2], 32, true, { tag: "json:\"arg\"" }), /* @__PURE__ */ $.structField("Reply", /* @__PURE__ */ $.basicType("string"), [3], 48, true, { tag: "json:\"reply\"" })]
	)
}

export class NodeRecord {
	public declare Kind: gobi.Kind

	public declare Tag: string

	public declare Key: string

	public declare Attrs: $.Slice<AttrRecord>

	public declare On: $.Slice<HandlerRecord>

	public declare Kids: $.Slice<NodeRecord>

	public declare Text: string

	constructor(__goscriptValue?: boolean, Kind$?: gobi.Kind, Tag$?: string, Key$?: string, Attrs$?: $.Slice<AttrRecord>, On$?: $.Slice<HandlerRecord>, Kids$?: $.Slice<NodeRecord>, Text$?: string) {
		this.Kind = Kind$ ?? 0
		this.Tag = Tag$ ?? ""
		this.Key = Key$ ?? ""
		this.Attrs = Attrs$ ?? (null! as $.Slice<AttrRecord>)
		this.On = On$ ?? (null! as $.Slice<HandlerRecord>)
		this.Kids = Kids$ ?? (null! as $.Slice<NodeRecord>)
		this.Text = Text$ ?? ""
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): NodeRecord {
		return new NodeRecord(true, this.Kind, this.Tag, this.Key, this.Attrs, this.On, this.Kids, this.Text)
	}

	public __goscriptAssign(source: NodeRecord): this {
		this.Kind = source.Kind
		this.Tag = source.Tag
		this.Key = source.Key
		this.Attrs = source.Attrs
		this.On = source.On
		this.Kids = source.Kids
		this.Text = source.Text
		return this
	}

	public GobiNode(): gobi.Node {
		const record = this;
		let node = new gobi.Node(true, record.Kind, record.Tag, record.Key, undefined, undefined, undefined, record.Text)
		if (record.Attrs != null) {
			node.Attrs = $.makeSlice<gobi.Attr>($.sliceLen(record.Attrs), undefined, undefined, () => new gobi.Attr(true))
			for (let __goscriptRangeTarget1 = record.Attrs, __goscriptRangeWindow0 = $.sliceRange(__goscriptRangeTarget1), i = 0; i < __goscriptRangeWindow0.length; i++) {
				let attr = ((__goscriptRangeWindow0.backing[__goscriptRangeWindow0.offset + i] as AttrRecord)).clone()
				$.sliceElems(node.Attrs!)[$.sliceSlot(node.Attrs!, i)].__goscriptAssign(new gobi.Attr(true, attr.Name, attr.Value, attr.Flag))
				if (attr.Style != null) {
					$.plainSliceIndex(node.Attrs!, i).Style = $.makeSlice<gobi.Style>($.sliceLen(attr.Style), undefined, undefined, () => new gobi.Style(true))
					for (let __goscriptRangeTarget0 = attr.Style, __goscriptRangeWindow1 = $.sliceRange(__goscriptRangeTarget0), j = 0; j < __goscriptRangeWindow1.length; j++) {
						let style = ((__goscriptRangeWindow1.backing[__goscriptRangeWindow1.offset + j] as StyleRecord)).clone()
						$.sliceElems($.plainSliceIndex(node.Attrs!, i).Style!)[$.sliceSlot($.plainSliceIndex(node.Attrs!, i).Style!, j)].__goscriptAssign(new gobi.Style(true, style.Property, style.Value))
					}
				}
			}
		}
		if (record.On != null) {
			node.On = $.makeSlice<gobi.On>($.sliceLen(record.On), undefined, undefined, () => new gobi.On(true))
			for (let __goscriptRangeTarget2 = record.On, __goscriptRangeWindow2 = $.sliceRange(__goscriptRangeTarget2), i = 0; i < __goscriptRangeWindow2.length; i++) {
				let h = ((__goscriptRangeWindow2.backing[__goscriptRangeWindow2.offset + i] as HandlerRecord)).clone()
				$.sliceElems(node.On!)[$.sliceSlot(node.On!, i)].__goscriptAssign(new gobi.On(true, h.Event, h.Message, h.Arg))
			}
		}
		if (record.Kids != null) {
			node.Kids = $.makeSlice<gobi.Node>($.sliceLen(record.Kids), undefined, undefined, () => new gobi.Node(true))
			for (let __goscriptRangeTarget3 = record.Kids, __goscriptRangeWindow3 = $.sliceRange(__goscriptRangeTarget3), i = 0; i < __goscriptRangeWindow3.length; i++) {
				let kid = ((__goscriptRangeWindow3.backing[__goscriptRangeWindow3.offset + i] as NodeRecord)).clone()
				$.sliceElems(node.Kids!)[$.sliceSlot(node.Kids!, i)].__goscriptAssign($.markAsStructValue($.cloneStructValue(kid)).GobiNode())
			}
		}
		return node
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.NodeRecord",
		() => new NodeRecord(),
		() => [$.methodSignature("GobiNode", [], ["gobi.Node"])],
		NodeRecord,
		() => [/* @__PURE__ */ $.structField("Kind", /* @__PURE__ */ $.basicType("uint8", "gobi.Kind"), [0], 0, true, { tag: "json:\"kind\"" }), /* @__PURE__ */ $.structField("Tag", /* @__PURE__ */ $.basicType("string"), [1], 8, true, { tag: "json:\"tag\"" }), /* @__PURE__ */ $.structField("Key", /* @__PURE__ */ $.basicType("string"), [2], 24, true, { tag: "json:\"key\"" }), /* @__PURE__ */ $.structField("Attrs", /* @__PURE__ */ $.sliceType("compilercontract.AttrRecord"), [3], 40, true, { tag: "json:\"attrs\"" }), /* @__PURE__ */ $.structField("On", /* @__PURE__ */ $.sliceType("compilercontract.HandlerRecord"), [4], 64, true, { tag: "json:\"on\"" }), /* @__PURE__ */ $.structField("Kids", /* @__PURE__ */ $.sliceType("compilercontract.NodeRecord"), [5], 88, true, { tag: "json:\"kids\"" }), /* @__PURE__ */ $.structField("Text", /* @__PURE__ */ $.basicType("string"), [6], 112, true, { tag: "json:\"text\"" })]
	)
}

export class AttrRecord {
	public declare Name: string

	public declare Value: string

	public declare Flag: boolean

	public declare Style: $.Slice<StyleRecord>

	constructor(__goscriptValue?: boolean, Name$?: string, Value$?: string, Flag$?: boolean, Style$?: $.Slice<StyleRecord>) {
		this.Name = Name$ ?? ""
		this.Value = Value$ ?? ""
		this.Flag = Flag$ ?? false
		this.Style = Style$ ?? (null! as $.Slice<StyleRecord>)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): AttrRecord {
		return new AttrRecord(true, this.Name, this.Value, this.Flag, this.Style)
	}

	public __goscriptAssign(source: AttrRecord): this {
		this.Name = source.Name
		this.Value = source.Value
		this.Flag = source.Flag
		this.Style = source.Style
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.AttrRecord",
		() => new AttrRecord(),
		() => [],
		AttrRecord,
		() => [/* @__PURE__ */ $.structField("Name", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"name\"" }), /* @__PURE__ */ $.structField("Value", /* @__PURE__ */ $.basicType("string"), [1], 16, true, { tag: "json:\"value\"" }), /* @__PURE__ */ $.structField("Flag", /* @__PURE__ */ $.basicType("bool"), [2], 32, true, { tag: "json:\"flag\"" }), /* @__PURE__ */ $.structField("Style", /* @__PURE__ */ $.sliceType("compilercontract.StyleRecord"), [3], 40, true, { tag: "json:\"style\"" })]
	)
}

export class StyleRecord {
	public declare Property: string

	public declare Value: string

	constructor(__goscriptValue?: boolean, Property$?: string, Value$?: string) {
		this.Property = Property$ ?? ""
		this.Value = Value$ ?? ""
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): StyleRecord {
		return new StyleRecord(true, this.Property, this.Value)
	}

	public __goscriptAssign(source: StyleRecord): this {
		this.Property = source.Property
		this.Value = source.Value
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.StyleRecord",
		() => new StyleRecord(),
		() => [],
		StyleRecord,
		() => [/* @__PURE__ */ $.structField("Property", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"property\"" }), /* @__PURE__ */ $.structField("Value", /* @__PURE__ */ $.basicType("string"), [1], 16, true, { tag: "json:\"value\"" })]
	)
}

export class HandlerRecord {
	public declare Event: string

	public declare Message: string

	public declare Arg: string

	constructor(__goscriptValue?: boolean, Event$?: string, Message$?: string, Arg$?: string) {
		this.Event = Event$ ?? ""
		this.Message = Message$ ?? ""
		this.Arg = Arg$ ?? ""
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): HandlerRecord {
		return new HandlerRecord(true, this.Event, this.Message, this.Arg)
	}

	public __goscriptAssign(source: HandlerRecord): this {
		this.Event = source.Event
		this.Message = source.Message
		this.Arg = source.Arg
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.HandlerRecord",
		() => new HandlerRecord(),
		() => [],
		HandlerRecord,
		() => [/* @__PURE__ */ $.structField("Event", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"event\"" }), /* @__PURE__ */ $.structField("Message", /* @__PURE__ */ $.basicType("string"), [1], 16, true, { tag: "json:\"message\"" }), /* @__PURE__ */ $.structField("Arg", /* @__PURE__ */ $.basicType("string"), [2], 32, true, { tag: "json:\"arg\"" })]
	)
}

export class EffectRequest {
	public declare DispatchID: string

	public declare EffectIndex: bigint

	public declare Effect: EffectValue

	constructor(__goscriptValue?: boolean, DispatchID$?: string, EffectIndex$?: bigint, Effect$?: EffectValue) {
		this.DispatchID = DispatchID$ ?? ""
		this.EffectIndex = EffectIndex$ ?? 0n
		this.Effect = Effect$ ?? new EffectValue(true)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): EffectRequest {
		return new EffectRequest(true, this.DispatchID, this.EffectIndex, this.Effect.clone())
	}

	public __goscriptAssign(source: EffectRequest): this {
		this.DispatchID = source.DispatchID
		this.EffectIndex = source.EffectIndex
		this.Effect.__goscriptAssign(source.Effect)
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.EffectRequest",
		() => new EffectRequest(),
		() => [],
		EffectRequest,
		() => [/* @__PURE__ */ $.structField("DispatchID", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"dispatchId\"" }), /* @__PURE__ */ $.structField("EffectIndex", /* @__PURE__ */ $.basicType("uint64"), [1], 16, true, { tag: "json:\"effectIndex\"" }), /* @__PURE__ */ $.structField("Effect", "compilercontract.EffectValue", [2], 24, true, { tag: "json:\"effect\"" })]
	)
}

export class EffectCompletion {
	public declare DispatchID: string

	public declare EffectIndex: bigint

	public declare Message: MessageValue

	constructor(__goscriptValue?: boolean, DispatchID$?: string, EffectIndex$?: bigint, Message$?: MessageValue) {
		this.DispatchID = DispatchID$ ?? ""
		this.EffectIndex = EffectIndex$ ?? 0n
		this.Message = Message$ ?? new MessageValue(true)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): EffectCompletion {
		return new EffectCompletion(true, this.DispatchID, this.EffectIndex, this.Message.clone())
	}

	public __goscriptAssign(source: EffectCompletion): this {
		this.DispatchID = source.DispatchID
		this.EffectIndex = source.EffectIndex
		this.Message.__goscriptAssign(source.Message)
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.EffectCompletion",
		() => new EffectCompletion(),
		() => [],
		EffectCompletion,
		() => [/* @__PURE__ */ $.structField("DispatchID", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"dispatchId\"" }), /* @__PURE__ */ $.structField("EffectIndex", /* @__PURE__ */ $.basicType("uint64"), [1], 16, true, { tag: "json:\"effectIndex\"" }), /* @__PURE__ */ $.structField("Message", "compilercontract.MessageValue", [2], 24, true, { tag: "json:\"message\"" })]
	)
}

export class DOMControl {
	public declare Path: string

	public declare Key: string

	public declare Tag: string

	public declare Type: string

	public declare Value: string

	public declare Checked: boolean

	public declare Disabled: boolean

	constructor(__goscriptValue?: boolean, Path$?: string, Key$?: string, Tag$?: string, Type$?: string, Value$?: string, Checked$?: boolean, Disabled$?: boolean) {
		this.Path = Path$ ?? ""
		this.Key = Key$ ?? ""
		this.Tag = Tag$ ?? ""
		this.Type = Type$ ?? ""
		this.Value = Value$ ?? ""
		this.Checked = Checked$ ?? false
		this.Disabled = Disabled$ ?? false
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): DOMControl {
		return new DOMControl(true, this.Path, this.Key, this.Tag, this.Type, this.Value, this.Checked, this.Disabled)
	}

	public __goscriptAssign(source: DOMControl): this {
		this.Path = source.Path
		this.Key = source.Key
		this.Tag = source.Tag
		this.Type = source.Type
		this.Value = source.Value
		this.Checked = source.Checked
		this.Disabled = source.Disabled
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.DOMControl",
		() => new DOMControl(),
		() => [],
		DOMControl,
		() => [/* @__PURE__ */ $.structField("Path", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"path\"" }), /* @__PURE__ */ $.structField("Key", /* @__PURE__ */ $.basicType("string"), [1], 16, true, { tag: "json:\"key\"" }), /* @__PURE__ */ $.structField("Tag", /* @__PURE__ */ $.basicType("string"), [2], 32, true, { tag: "json:\"tag\"" }), /* @__PURE__ */ $.structField("Type", /* @__PURE__ */ $.basicType("string"), [3], 48, true, { tag: "json:\"type\"" }), /* @__PURE__ */ $.structField("Value", /* @__PURE__ */ $.basicType("string"), [4], 64, true, { tag: "json:\"value\"" }), /* @__PURE__ */ $.structField("Checked", /* @__PURE__ */ $.basicType("bool"), [5], 80, true, { tag: "json:\"checked\"" }), /* @__PURE__ */ $.structField("Disabled", /* @__PURE__ */ $.basicType("bool"), [6], 81, true, { tag: "json:\"disabled\"" })]
	)
}

export class DOMSnapshot {
	public declare Normalization: string

	public declare HTML: string

	public declare Controls: $.Slice<DOMControl>

	constructor(__goscriptValue?: boolean, Normalization$?: string, HTML$?: string, Controls$?: $.Slice<DOMControl>) {
		this.Normalization = Normalization$ ?? ""
		this.HTML = HTML$ ?? ""
		this.Controls = Controls$ ?? (null! as $.Slice<DOMControl>)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): DOMSnapshot {
		return new DOMSnapshot(true, this.Normalization, this.HTML, this.Controls)
	}

	public __goscriptAssign(source: DOMSnapshot): this {
		this.Normalization = source.Normalization
		this.HTML = source.HTML
		this.Controls = source.Controls
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.DOMSnapshot",
		() => new DOMSnapshot(),
		() => [],
		DOMSnapshot,
		() => [/* @__PURE__ */ $.structField("Normalization", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"normalization\"" }), /* @__PURE__ */ $.structField("HTML", /* @__PURE__ */ $.basicType("string"), [1], 16, true, { tag: "json:\"html\"" }), /* @__PURE__ */ $.structField("Controls", /* @__PURE__ */ $.sliceType("compilercontract.DOMControl"), [2], 32, true, { tag: "json:\"controls\"" })]
	)
}

export class ViewRecord {
	public declare Tree: NodeRecord

	public declare Bindings: $.Slice<__goscript_contract.Binding>

	constructor(__goscriptValue?: boolean, Tree$?: NodeRecord, Bindings$?: $.Slice<__goscript_contract.Binding>) {
		this.Tree = Tree$ ?? new NodeRecord(true)
		this.Bindings = Bindings$ ?? (null! as $.Slice<__goscript_contract.Binding>)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): ViewRecord {
		return new ViewRecord(true, this.Tree.clone(), this.Bindings)
	}

	public __goscriptAssign(source: ViewRecord): this {
		this.Tree.__goscriptAssign(source.Tree)
		this.Bindings = source.Bindings
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.ViewRecord",
		() => new ViewRecord(),
		() => [],
		ViewRecord,
		() => [/* @__PURE__ */ $.structField("Tree", "compilercontract.NodeRecord", [0], 0, true, { tag: "json:\"tree\"" }), /* @__PURE__ */ $.structField("Bindings", /* @__PURE__ */ $.sliceType("compilercontract.Binding"), [1], 128, true, { tag: "json:\"bindings\"" })]
	)
}

export class Tick {
	public declare Index: bigint

	public declare Action: Action | $.VarRef<Action> | null

	public declare Message: MessageValue | $.VarRef<MessageValue> | null

	public declare DispatchID: $.VarRef<string> | null

	public declare State: __goscript_value.Value

	public declare RequestedEffects: $.Slice<EffectRequest>

	public declare CompletedEffects: $.Slice<EffectCompletion>

	public declare View: ViewRecord

	public declare DOM: DOMSnapshot | $.VarRef<DOMSnapshot> | null

	constructor(__goscriptValue?: boolean, Index$?: bigint, Action$?: Action | $.VarRef<Action> | null, Message$?: MessageValue | $.VarRef<MessageValue> | null, DispatchID$?: $.VarRef<string> | null, State$?: __goscript_value.Value, RequestedEffects$?: $.Slice<EffectRequest>, CompletedEffects$?: $.Slice<EffectCompletion>, View$?: ViewRecord, DOM$?: DOMSnapshot | $.VarRef<DOMSnapshot> | null) {
		this.Index = Index$ ?? 0n
		this.Action = Action$ ?? (null! as Action | $.VarRef<Action> | null)
		this.Message = Message$ ?? (null! as MessageValue | $.VarRef<MessageValue> | null)
		this.DispatchID = DispatchID$ ?? (null! as $.VarRef<string> | null)
		this.State = State$ ?? new __goscript_value.Value(true)
		this.RequestedEffects = RequestedEffects$ ?? (null! as $.Slice<EffectRequest>)
		this.CompletedEffects = CompletedEffects$ ?? (null! as $.Slice<EffectCompletion>)
		this.View = View$ ?? new ViewRecord(true)
		this.DOM = DOM$ ?? (null! as DOMSnapshot | $.VarRef<DOMSnapshot> | null)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): Tick {
		return new Tick(true, this.Index, this.Action, this.Message, this.DispatchID, this.State.clone(), this.RequestedEffects, this.CompletedEffects, this.View.clone(), this.DOM)
	}

	public __goscriptAssign(source: Tick): this {
		this.Index = source.Index
		this.Action = source.Action
		this.Message = source.Message
		this.DispatchID = source.DispatchID
		this.State.__goscriptAssign(source.State)
		this.RequestedEffects = source.RequestedEffects
		this.CompletedEffects = source.CompletedEffects
		this.View.__goscriptAssign(source.View)
		this.DOM = source.DOM
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.Tick",
		() => new Tick(),
		() => [],
		Tick,
		() => [/* @__PURE__ */ $.structField("Index", /* @__PURE__ */ $.basicType("uint64"), [0], 0, true, { tag: "json:\"index\"" }), /* @__PURE__ */ $.structField("Action", /* @__PURE__ */ $.pointerType("compilercontract.Action"), [1], 8, true, { tag: "json:\"action\"" }), /* @__PURE__ */ $.structField("Message", /* @__PURE__ */ $.pointerType("compilercontract.MessageValue"), [2], 16, true, { tag: "json:\"message\"" }), /* @__PURE__ */ $.structField("DispatchID", /* @__PURE__ */ $.pointerType(/* @__PURE__ */ $.basicType("string")), [3], 24, true, { tag: "json:\"dispatchId\"" }), /* @__PURE__ */ $.structField("State", "compilercontract.Value", [4], 32, true, { tag: "json:\"state\"" }), /* @__PURE__ */ $.structField("RequestedEffects", /* @__PURE__ */ $.sliceType("compilercontract.EffectRequest"), [5], 120, true, { tag: "json:\"requestedEffects\"" }), /* @__PURE__ */ $.structField("CompletedEffects", /* @__PURE__ */ $.sliceType("compilercontract.EffectCompletion"), [6], 144, true, { tag: "json:\"completedEffects\"" }), /* @__PURE__ */ $.structField("View", "compilercontract.ViewRecord", [7], 168, true, { tag: "json:\"view\"" }), /* @__PURE__ */ $.structField("DOM", /* @__PURE__ */ $.pointerType("compilercontract.DOMSnapshot"), [8], 320, true, { tag: "json:\"dom\"" })]
	)
}

export class Trace {
	public declare Schema: string

	public declare AppID: string

	public declare Ticks: $.Slice<Tick>

	constructor(__goscriptValue?: boolean, Schema$?: string, AppID$?: string, Ticks$?: $.Slice<Tick>) {
		this.Schema = Schema$ ?? ""
		this.AppID = AppID$ ?? ""
		this.Ticks = Ticks$ ?? (null! as $.Slice<Tick>)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): Trace {
		return new Trace(true, this.Schema, this.AppID, this.Ticks)
	}

	public __goscriptAssign(source: Trace): this {
		this.Schema = source.Schema
		this.AppID = source.AppID
		this.Ticks = source.Ticks
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.Trace",
		() => new Trace(),
		() => [],
		Trace,
		() => [/* @__PURE__ */ $.structField("Schema", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"schema\"" }), /* @__PURE__ */ $.structField("AppID", /* @__PURE__ */ $.basicType("string"), [1], 16, true, { tag: "json:\"appId\"" }), /* @__PURE__ */ $.structField("Ticks", /* @__PURE__ */ $.sliceType("compilercontract.Tick"), [2], 32, true, { tag: "json:\"ticks\"" })]
	)
}

export class HostStep {
	public declare Request: EffectRequest

	public declare Completion: MessageValue | $.VarRef<MessageValue> | null

	constructor(__goscriptValue?: boolean, Request$?: EffectRequest, Completion$?: MessageValue | $.VarRef<MessageValue> | null) {
		this.Request = Request$ ?? new EffectRequest(true)
		this.Completion = Completion$ ?? (null! as MessageValue | $.VarRef<MessageValue> | null)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): HostStep {
		return new HostStep(true, this.Request.clone(), this.Completion)
	}

	public __goscriptAssign(source: HostStep): this {
		this.Request.__goscriptAssign(source.Request)
		this.Completion = source.Completion
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.HostStep",
		() => new HostStep(),
		() => [],
		HostStep,
		() => [/* @__PURE__ */ $.structField("Request", "compilercontract.EffectRequest", [0], 0, true, { tag: "json:\"request\"" }), /* @__PURE__ */ $.structField("Completion", /* @__PURE__ */ $.pointerType("compilercontract.MessageValue"), [1], 88, true, { tag: "json:\"completion\"" })]
	)
}

export class HostScript {
	public declare Schema: string

	public declare Steps: $.Slice<HostStep>

	constructor(__goscriptValue?: boolean, Schema$?: string, Steps$?: $.Slice<HostStep>) {
		this.Schema = Schema$ ?? ""
		this.Steps = Steps$ ?? (null! as $.Slice<HostStep>)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): HostScript {
		return new HostScript(true, this.Schema, this.Steps)
	}

	public __goscriptAssign(source: HostScript): this {
		this.Schema = source.Schema
		this.Steps = source.Steps
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.HostScript",
		() => new HostScript(),
		() => [],
		HostScript,
		() => [/* @__PURE__ */ $.structField("Schema", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"schema\"" }), /* @__PURE__ */ $.structField("Steps", /* @__PURE__ */ $.sliceType("compilercontract.HostStep"), [1], 16, true, { tag: "json:\"steps\"" })]
	)
}

export const EffectKindRequest: EffectKind = "fixture.request"

export function NodeRecordFromGobi(node: gobi.Node): NodeRecord {
	let out = new NodeRecord(true, node.Kind, node.Tag, node.Key, undefined, undefined, undefined, node.Text)
	if (node.Attrs != null) {
		out.Attrs = $.makeSlice<AttrRecord>($.sliceLen(node.Attrs), undefined, undefined, () => new AttrRecord(true))
		for (let __goscriptRangeTarget5 = node.Attrs, __goscriptRangeWindow4 = $.sliceRange(__goscriptRangeTarget5), i = 0; i < __goscriptRangeWindow4.length; i++) {
			let attr = ((__goscriptRangeWindow4.backing[__goscriptRangeWindow4.offset + i] as gobi.Attr)).clone()
			$.sliceElems(out.Attrs!)[$.sliceSlot(out.Attrs!, i)].__goscriptAssign(new AttrRecord(true, attr.Name, attr.Value, attr.Flag))
			if (attr.Style != null) {
				$.plainSliceIndex(out.Attrs!, i).Style = $.makeSlice<StyleRecord>($.sliceLen(attr.Style), undefined, undefined, () => new StyleRecord(true))
				for (let __goscriptRangeTarget4 = attr.Style, __goscriptRangeWindow5 = $.sliceRange(__goscriptRangeTarget4), j = 0; j < __goscriptRangeWindow5.length; j++) {
					let style = ((__goscriptRangeWindow5.backing[__goscriptRangeWindow5.offset + j] as gobi.Style)).clone()
					$.sliceElems($.plainSliceIndex(out.Attrs!, i).Style!)[$.sliceSlot($.plainSliceIndex(out.Attrs!, i).Style!, j)].__goscriptAssign(new StyleRecord(true, style.Property, style.Value))
				}
			}
		}
	}
	if (node.On != null) {
		out.On = $.makeSlice<HandlerRecord>($.sliceLen(node.On), undefined, undefined, () => new HandlerRecord(true))
		for (let __goscriptRangeTarget6 = node.On, __goscriptRangeWindow6 = $.sliceRange(__goscriptRangeTarget6), i = 0; i < __goscriptRangeWindow6.length; i++) {
			let h = ((__goscriptRangeWindow6.backing[__goscriptRangeWindow6.offset + i] as gobi.On)).clone()
			$.sliceElems(out.On!)[$.sliceSlot(out.On!, i)].__goscriptAssign(new HandlerRecord(true, h.Event, h.Message, h.Arg))
		}
	}
	if (node.Kids != null) {
		out.Kids = $.makeSlice<NodeRecord>($.sliceLen(node.Kids), undefined, undefined, () => new NodeRecord(true))
		for (let __goscriptRangeTarget7 = node.Kids, __goscriptRangeWindow7 = $.sliceRange(__goscriptRangeTarget7), i = 0; i < __goscriptRangeWindow7.length; i++) {
			let kid = ((__goscriptRangeWindow7.backing[__goscriptRangeWindow7.offset + i] as gobi.Node)).clone()
			$.sliceElems(out.Kids!)[$.sliceSlot(out.Kids!, i)].__goscriptAssign(NodeRecordFromGobi((kid).clone()))
		}
	}
	return out
}

export function ViewRecordFromView(view: __goscript_contract.View): ViewRecord {
	let bindings: $.Slice<__goscript_contract.Binding> = view.Bindings
	if (bindings == null) {
		bindings = $.arrayToSlice<__goscript_contract.Binding>([])
	} else {
		let copyOfBindings: $.Slice<__goscript_contract.Binding> = $.makeSlice<__goscript_contract.Binding>($.sliceLen(bindings), undefined, undefined, () => new __goscript_contract.Binding(true))
		$.copy(copyOfBindings, bindings, true)
		bindings = copyOfBindings
	}
	return (() => { const __goscriptLiteralField0 = NodeRecordFromGobi(view.Tree); return new ViewRecord(true, __goscriptLiteralField0, bindings) })()
}

export function MessageFromGobi(message: gobi.Message): MessageValue {
	return new MessageValue(true, message.Name, message.Arg)
}

export function EffectFromGobi(effect: gobi.Effect): EffectValue {
	return new EffectValue(true, effect.Kind, effect.Name, effect.Arg, effect.Reply)
}

export function NewTrace(appID: string): Trace {
	return new Trace(true, "gobi.trace/v1", appID, $.arrayToSlice<Tick>([]))
}

export function NewView(tree: gobi.Node, bindings: $.Slice<__goscript_contract.Binding>): __goscript_contract.View {
	let copied = $.makeSlice<__goscript_contract.Binding>($.sliceLen(bindings), undefined, undefined, () => new __goscript_contract.Binding(true))
	$.copy(copied, bindings, true)
	return new __goscript_contract.View(true, (tree).clone(), copied)
}

export function AppendTick(trace: Trace | $.VarRef<Trace> | null, tick: Tick): $.GoError {
	const trace$: Trace = trace == null ? $.pointerTarget<Trace>(trace) : (trace as any).__isVarRef === true ? (trace as any).value : (trace as any).__goValue === undefined ? (trace as any) : $.pointerTarget<Trace>(trace)
	if (trace == null) {
		return fmt.Errorf("nil trace")
	}
	if (!$.stringEqual((trace$ as Trace).Schema, "gobi.trace/v1")) {
		return fmt.Errorf("trace schema must be %q", "gobi.trace/v1")
	}
	if ($.stringEqual((trace$ as Trace).AppID, "")) {
		return fmt.Errorf("trace appId is empty")
	}
	if ((trace$ as Trace).Ticks == null) {
		return fmt.Errorf("trace ticks must be a non-null array")
	}
	if (tick.Index != $.uint64($.sliceLen((trace$ as Trace).Ticks))) {
		return fmt.Errorf("tick index %d is not next index %d", $.basicInterfaceValue(tick.Index, "uint64"), $.basicInterfaceValue($.sliceLen((trace$ as Trace).Ticks), "int"))
	}
	if (tick.RequestedEffects == null) {
		tick.RequestedEffects = $.arrayToSlice<EffectRequest>([])
	}
	if (tick.CompletedEffects == null) {
		tick.CompletedEffects = $.arrayToSlice<EffectCompletion>([])
	}
	if (tick.View.Bindings == null) {
		tick.View.Bindings = $.arrayToSlice<__goscript_contract.Binding>([])
	}
	if ((tick.DOM != null) && ($.pointerValue<DOMSnapshot>(tick.DOM).Controls == null)) {
		$.pointerValue<DOMSnapshot>(tick.DOM).Controls = $.arrayToSlice<DOMControl>([])
	}
	;(trace$ as Trace).Ticks = $.appendOne((trace$ as Trace).Ticks, (tick).clone())
	return null
}

export async function ValidateHostScript(script: HostScript, requests: $.Slice<EffectRequest>, completions: $.Slice<EffectCompletion>): globalThis.Promise<$.Slice<__goscript_contract.Diagnostic>> {
	let diagnostics: $.Slice<__goscript_contract.Diagnostic> = $.makeSlice<__goscript_contract.Diagnostic>(0, undefined, undefined, () => new __goscript_contract.Diagnostic(true))
	let add = $.functionValue((code: string, msg: string) => {
		diagnostics = $.appendOne(diagnostics, new __goscript_contract.Diagnostic(true, code, "error", msg, undefined, $.arrayToSlice<__goscript_contract.Span>([])))
	}, ({ kind: $.TypeKind.Function, params: [/* @__PURE__ */ $.basicType("string"), /* @__PURE__ */ $.basicType("string")], results: [] } as $.FunctionTypeInfo))
	if (!$.stringEqual(script.Schema, "gobi.host-script/v1")) {
		add("host.schema", "host script schema must be " + "gobi.host-script/v1")
	}
	if (script.Steps == null) {
		add("host.steps", "host steps must be a non-null array")
	}
	if (requests == null) {
		add("host.requests", "observed requests must be a non-null array")
	}
	if (completions == null) {
		add("host.completions", "observed completions must be a non-null array")
	}
	if (((script.Steps == null) || (requests == null)) || (completions == null)) {
		return diagnostics
	}
	if ($.sliceLen(script.Steps) != $.sliceLen(requests)) {
		add("host.request-count", (fmt.Sprintf("host has %d steps for %d requests", $.basicInterfaceValue($.sliceLen(script.Steps), "int"), $.basicInterfaceValue($.sliceLen(requests), "int")) as string))
	}
	let expectedCompletions: $.Slice<EffectCompletion> = $.makeSlice<EffectCompletion>(0, undefined, undefined, () => new EffectCompletion(true))
	for (let __goscriptRangeTarget8 = script.Steps, __goscriptRangeWindow8 = $.sliceRange(__goscriptRangeTarget8), __goscriptSliceWindow0 = $.sliceRange(requests), i = 0; i < __goscriptRangeWindow8.length; i++) {
		let step = ((__goscriptRangeWindow8.backing[__goscriptRangeWindow8.offset + i] as HostStep)).clone()
		let req = (step.Request).clone()
		if (((!$.stringEqual(req.Effect.Kind, "fixture.request")) || (!$.stringEqual(req.Effect.Name, "lookup"))) || (!$.stringEqual(req.Effect.Reply, "complete"))) {
			add("host.effect-kind", (fmt.Sprintf("step %d has unsupported effect descriptor", $.basicInterfaceValue(i, "int")) as string))
		}
		if ($.stringEqual(req.DispatchID, "")) {
			add("host.dispatch-id", (fmt.Sprintf("step %d has empty dispatchId", $.basicInterfaceValue(i, "int")) as string))
		}
		if ((i < __goscriptSliceWindow0.length) && (!$.structEqual(req, ((__goscriptSliceWindow0.backing as any[])[$.windowSlot(__goscriptSliceWindow0, i)] as EffectRequest)))) {
			add("host.request-order", (fmt.Sprintf("step %d request does not exactly match observed request", $.basicInterfaceValue(i, "int")) as string))
		}
		if ($.stringEqual(req.Effect.Reply, "")) {
			if (step.Completion != null) {
				add("host.unexpected-completion", (fmt.Sprintf("step %d has a completion for a fire-and-forget effect", $.basicInterfaceValue(i, "int")) as string))
			}
		} else {
			if (step.Completion == null) {
				add("host.missing-completion", (fmt.Sprintf("step %d is missing its completion message", $.basicInterfaceValue(i, "int")) as string))
				continue
			}
			if (!$.stringEqual($.pointerValue<MessageValue>(step.Completion).Name, req.Effect.Reply)) {
				add("host.reply-name", (fmt.Sprintf("step %d reply name %q does not match effect reply %q", $.basicInterfaceValue(i, "int"), $.pointerValue<MessageValue>(step.Completion).Name, req.Effect.Reply) as string))
			}
			expectedCompletions = $.appendOne(expectedCompletions, new EffectCompletion(true, req.DispatchID, req.EffectIndex, ($.pointerValue<MessageValue>(step.Completion)).clone()))
		}
	}
	if ($.sliceLen(expectedCompletions) != $.sliceLen(completions)) {
		add("host.completion-count", (fmt.Sprintf("host script expects %d completions but observed %d", $.basicInterfaceValue($.sliceLen(expectedCompletions), "int"), $.basicInterfaceValue($.sliceLen(completions), "int")) as string))
	}
	let limit = $.sliceLen(expectedCompletions)
	if ($.sliceLen(completions) < limit) {
		limit = $.sliceLen(completions)
	}
	for (let __goscriptSliceWindow1 = $.sliceRange(expectedCompletions), __goscriptSliceWindow2 = $.sliceRange(completions), i = 0; i < limit; i++) {
		if (!$.structEqual(((__goscriptSliceWindow1.backing as any[])[$.windowSlot(__goscriptSliceWindow1, i)] as EffectCompletion), ((__goscriptSliceWindow2.backing as any[])[$.windowSlot(__goscriptSliceWindow2, i)] as EffectCompletion))) {
			add("host.completion-order", (fmt.Sprintf("completion %d does not match expected request/reply", $.basicInterfaceValue(i, "int")) as string))
		}
	}
	return diagnostics
}
