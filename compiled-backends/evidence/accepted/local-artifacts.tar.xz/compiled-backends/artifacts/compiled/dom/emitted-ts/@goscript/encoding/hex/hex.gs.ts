// Generated file based on hex.go
// Updated when compliance tests are re-run, DO NOT EDIT!

import * as $ from "@goscript/builtin/index.js"
import * as errors from "@goscript/errors/index.js"
import * as fmt from "@goscript/fmt/index.js"
import * as io from "@goscript/io/index.js"
import * as slices from "@goscript/slices/index.js"
import * as strings from "@goscript/strings/index.js"
import "@goscript/io/index.js"

$.registerTypePackagePath("encoding/hex", ["hex.InvalidByteError", "hex.encoder", "hex.decoder", "hex.dumper"])

export type InvalidByteError = number

$.registerNamedValueType(
	"hex.InvalidByteError",
	{Error: (receiver: any) => (InvalidByteError_Error as any)(($.isVarRef(receiver) ? receiver.value : receiver))},
	[$.methodSignature("Error", [], [/* @__PURE__ */ $.basicType("string")])]
);

$.registerNamedValueType(
	"*hex.InvalidByteError",
	{Error: (receiver: any) => (InvalidByteError_Error as any)($.pointerValue(receiver))},
	[$.methodSignature("Error", [], [/* @__PURE__ */ $.basicType("string")])]
);

export class encoder {
	public declare w: io.Writer | null

	public declare err: $.GoError

	public declare out: Uint8Array

	constructor(__goscriptValue?: boolean, w$?: io.Writer | null, err$?: $.GoError, out$?: Uint8Array) {
		this.w = w$ ?? (null! as io.Writer | null)
		this.err = err$ ?? (null! as $.GoError)
		this.out = out$ ?? $.arrayValue(new Uint8Array(1024))
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): encoder {
		return new encoder(true, this.w, this.err, $.cloneArrayValue(this.out, __goscriptStatic1()))
	}

	public __goscriptAssign(source: encoder): this {
		this.w = $.assignFieldValue(this.w, source.w)
		this.err = $.assignFieldValue(this.err, source.err)
		this.out = $.assignFieldValue(this.out, source.out, __goscriptStatic1())
		return this
	}

	public async Write(p: $.Slice<number>): globalThis.Promise<[number, $.GoError]> {
		const e: encoder | $.VarRef<encoder> | null = this;
		let n = 0
		let err: $.GoError = null! as $.GoError
		const e$: encoder = e == null ? $.pointerTarget<encoder>(e) : (e as any).__isVarRef === true ? (e as any).value : (e as any).__goValue === undefined ? (e as any) : $.pointerTarget<encoder>(e)
		while (($.sliceLen(p) > 0) && ((e$ as encoder).err == null)) {
			let chunkSize = 512
			if ($.sliceLen(p) < chunkSize) {
				chunkSize = $.sliceLen(p)
			}

			let written = 0
			let encoded = Encode($.goSlice((e$ as encoder).out, undefined, undefined), $.goSlice(p, undefined, chunkSize))
			let __goscriptTuple1: any = await $.pointerValue<Exclude<io.Writer, null>>((e$ as encoder).w).Write($.goSlice((e$ as encoder).out, undefined, encoded))
			written = __goscriptTuple1[0];
			;(e$ as encoder).err = __goscriptTuple1[1]
			n += globalThis.Math.trunc(written / 2)
			p = $.goSlice(p, chunkSize, undefined)
		}
		return [n, (e$ as encoder).err]
	}

	static __typeInfo = $.registerStructType(
		"hex.encoder",
		() => new encoder(),
		() => [$.methodSignature("Write", [["p", /* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("uint8"))]], [["n", /* @__PURE__ */ $.basicType("int")], ["err", "error"]], true)],
		encoder,
		() => [/* @__PURE__ */ $.structField("w", "io.Writer", [0], 0, false, { pkgPath: "encoding/hex" }), /* @__PURE__ */ $.structField("err", "error", [1], 16, false, { pkgPath: "encoding/hex" }), /* @__PURE__ */ $.structField("out", /* @__PURE__ */ $.arrayType(/* @__PURE__ */ $.basicType("uint8"), 1024), [2], 32, false, { pkgPath: "encoding/hex" })]
	)
}

export class decoder {
	public declare r: io.Reader | null

	public declare err: $.GoError

	public declare _in: $.Slice<number>

	public declare arr: Uint8Array

	constructor(__goscriptValue?: boolean, r$?: io.Reader | null, err$?: $.GoError, _in$?: $.Slice<number>, arr$?: Uint8Array) {
		this.r = r$ ?? (null! as io.Reader | null)
		this.err = err$ ?? (null! as $.GoError)
		this._in = _in$ ?? (null! as $.Slice<number>)
		this.arr = arr$ ?? $.arrayValue(new Uint8Array(1024))
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): decoder {
		return new decoder(true, this.r, this.err, this._in, $.cloneArrayValue(this.arr, __goscriptStatic1()))
	}

	public __goscriptAssign(source: decoder): this {
		this.r = $.assignFieldValue(this.r, source.r)
		this.err = $.assignFieldValue(this.err, source.err)
		this._in = source._in
		this.arr = $.assignFieldValue(this.arr, source.arr, __goscriptStatic1())
		return this
	}

	public async Read(p: $.Slice<number>): globalThis.Promise<[number, $.GoError]> {
		const d: decoder | $.VarRef<decoder> | null = this;
		let n = 0
		let err: $.GoError = null! as $.GoError
		const d$: decoder = d == null ? $.pointerTarget<decoder>(d) : (d as any).__isVarRef === true ? (d as any).value : (d as any).__goValue === undefined ? (d as any) : $.pointerTarget<decoder>(d)
		// Fill internal buffer with sufficient bytes to decode
		if (($.sliceLen((d$ as decoder)._in) < 2) && ((d$ as decoder).err == null)) {
			let numCopy = 0
			let numRead = 0
			numCopy = $.copy($.goSlice((d$ as decoder).arr, undefined, undefined), (d$ as decoder)._in)
			let __goscriptTuple2: any = await $.pointerValue<Exclude<io.Reader, null>>((d$ as decoder).r).Read($.goSlice((d$ as decoder).arr, numCopy, undefined))
			numRead = __goscriptTuple2[0];
			;(d$ as decoder).err = __goscriptTuple2[1];
			;(d$ as decoder)._in = $.goSlice((d$ as decoder).arr, undefined, numCopy + numRead)
			if (($.comparableEqual((d$ as decoder).err, io.EOF)) && (($.sliceLen((d$ as decoder)._in) % 2) != 0)) {

				{
					let a = $.indexByteString("\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\xff\xff\xff\xff\xff\xff\xff\x0a\x0b\x0c\x0d\x0e\x0f\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\x0a\x0b\x0c\x0d\x0e\x0f\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff", $.typedSliceIndex((d$ as decoder)._in!, $.sliceLen((d$ as decoder)._in) - 1))
					if (a > 0x0f) {
						;(d$ as decoder).err = $.namedValueInterfaceValue<$.GoError>($.typedSliceIndex((d$ as decoder)._in!, $.sliceLen((d$ as decoder)._in) - 1), "hex.InvalidByteError", {"Error": InvalidByteError_Error}, /* @__PURE__ */ $.basicType("uint8", "hex.InvalidByteError"))
					} else {
						;(d$ as decoder).err = io.ErrUnexpectedEOF
					}
				}
			}
		}

		// Decode internal buffer into output buffer
		{
			let numAvail = globalThis.Math.trunc($.sliceLen((d$ as decoder)._in) / 2)
			if ($.sliceLen(p) > numAvail) {
				p = $.goSlice(p, undefined, numAvail)
			}
		}
		let __goscriptTuple3: any = Decode(p, $.goSlice((d$ as decoder)._in, undefined, $.sliceLen(p) * 2))
		let numDec: number = __goscriptTuple3[0]
		err = __goscriptTuple3[1];
		;(d$ as decoder)._in = $.goSlice((d$ as decoder)._in, 2 * numDec, undefined)
		if (err != null) {
			let __goscriptAssign0_0: $.Slice<number> = null
			let __goscriptAssign0_1: $.GoError = err;
			;(d$ as decoder)._in = __goscriptAssign0_0;
			;(d$ as decoder).err = __goscriptAssign0_1
		}

		if ($.sliceLen((d$ as decoder)._in) < 2) {
			return [numDec, (d$ as decoder).err]
		}
		return [numDec, null]
	}

	static __typeInfo = $.registerStructType(
		"hex.decoder",
		() => new decoder(),
		() => [$.methodSignature("Read", [["p", /* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("uint8"))]], [["n", /* @__PURE__ */ $.basicType("int")], ["err", "error"]], true)],
		decoder,
		() => [/* @__PURE__ */ $.structField("r", "io.Reader", [0], 0, false, { pkgPath: "encoding/hex" }), /* @__PURE__ */ $.structField("err", "error", [1], 16, false, { pkgPath: "encoding/hex" }), /* @__PURE__ */ $.structField("in", /* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("uint8")), [2], 32, false, { key: "_in", pkgPath: "encoding/hex" }), /* @__PURE__ */ $.structField("arr", /* @__PURE__ */ $.arrayType(/* @__PURE__ */ $.basicType("uint8"), 1024), [3], 56, false, { pkgPath: "encoding/hex" })]
	)
}

export class dumper {
	public declare w: io.Writer | null

	public declare rightChars: Uint8Array

	public declare buf: Uint8Array

	public declare used: number

	public declare n: number

	public declare closed: boolean

	constructor(__goscriptValue?: boolean, w$?: io.Writer | null, rightChars$?: Uint8Array, buf$?: Uint8Array, used$?: number, n$?: number, closed$?: boolean) {
		this.w = w$ ?? (null! as io.Writer | null)
		this.rightChars = rightChars$ ?? $.arrayValue(new Uint8Array(18))
		this.buf = buf$ ?? $.arrayValue(new Uint8Array(14))
		this.used = used$ ?? 0
		this.n = n$ ?? 0
		this.closed = closed$ ?? false
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): dumper {
		return new dumper(true, this.w, $.cloneArrayValue(this.rightChars, __goscriptStatic2()), $.cloneArrayValue(this.buf, __goscriptStatic3()), this.used, this.n, this.closed)
	}

	public __goscriptAssign(source: dumper): this {
		this.w = $.assignFieldValue(this.w, source.w)
		this.rightChars = $.assignFieldValue(this.rightChars, source.rightChars, __goscriptStatic2())
		this.buf = $.assignFieldValue(this.buf, source.buf, __goscriptStatic3())
		this.used = source.used
		this.n = source.n
		this.closed = source.closed
		return this
	}

	public async Close(): globalThis.Promise<$.GoError> {
		const h: dumper | $.VarRef<dumper> | null = this;
		let err: $.GoError = null! as $.GoError
		const h$: dumper = h == null ? $.pointerTarget<dumper>(h) : (h as any).__isVarRef === true ? (h as any).value : (h as any).__goValue === undefined ? (h as any) : $.pointerTarget<dumper>(h)
		// See the comments in Write() for the details of this format.
		if ((h$ as dumper).closed) {
			return err
		}
		;(h$ as dumper).closed = true
		if ((h$ as dumper).used == 0) {
			return err
		}
		;(h$ as dumper).buf[0] = 32;
		;(h$ as dumper).buf[1] = 32;
		;(h$ as dumper).buf[2] = 32;
		;(h$ as dumper).buf[3] = 32;
		;(h$ as dumper).buf[4] = 124
		let nBytes = (h$ as dumper).used
		while ((h$ as dumper).used < 16) {
			let l = 3
			if ((h$ as dumper).used == 7) {
				l = 4
			} else {
				if ((h$ as dumper).used == 15) {
					l = 5
				}
			}
			let __goscriptTuple4: any = await $.pointerValue<Exclude<io.Writer, null>>((h$ as dumper).w).Write($.goSlice((h$ as dumper).buf, undefined, l))
			err = __goscriptTuple4[1]
			if (err != null) {
				return err
			}
			;(h$ as dumper).used++
		}
		;(h$ as dumper).rightChars[nBytes] = 124;
		;(h$ as dumper).rightChars[nBytes + 1] = 10
		let __goscriptTuple5: any = await $.pointerValue<Exclude<io.Writer, null>>((h$ as dumper).w).Write($.goSlice((h$ as dumper).rightChars, undefined, nBytes + 2))
		err = __goscriptTuple5[1]
		return err
	}

	public async Write(data: $.Slice<number>): globalThis.Promise<[number, $.GoError]> {
		const h: dumper | $.VarRef<dumper> | null = this;
		let n = 0
		let err: $.GoError = null! as $.GoError
		const h$: dumper = h == null ? $.pointerTarget<dumper>(h) : (h as any).__isVarRef === true ? (h as any).value : (h as any).__goValue === undefined ? (h as any) : $.pointerTarget<dumper>(h)
		if ((h$ as dumper).closed) {
			return [0, errors.New("encoding/hex: dumper closed")]
		}

		// Output lines look like:
		// 00000010  2e 2f 30 31 32 33 34 35  36 37 38 39 3a 3b 3c 3d  |./0123456789:;<=|
		// ^ offset                          ^ extra space              ^ ASCII of line.
		for (let __goscriptRangeTarget1 = data, __goscriptRangeWindow1 = $.sliceRange(__goscriptRangeTarget1), i = 0; i < __goscriptRangeWindow1.length; i++) {
			if ((h$ as dumper).used == 0) {
				// At the beginning of a line we print the current
				// offset in hex.
				;(h$ as dumper).buf[0] = $.uint($.wideUintShr((h$ as dumper).n, 24), 8);
				;(h$ as dumper).buf[1] = $.uint($.wideUintShr((h$ as dumper).n, 16), 8);
				;(h$ as dumper).buf[2] = $.uint($.wideUintShr((h$ as dumper).n, 8), 8);
				;(h$ as dumper).buf[3] = $.uint((h$ as dumper).n, 8)
				Encode($.goSlice((h$ as dumper).buf, 4, undefined), $.goSlice((h$ as dumper).buf, undefined, 4));
				;(h$ as dumper).buf[12] = 32;
				;(h$ as dumper).buf[13] = 32
				let __goscriptTuple6: any = await $.pointerValue<Exclude<io.Writer, null>>((h$ as dumper).w).Write($.goSlice((h$ as dumper).buf, 4, undefined))
				err = __goscriptTuple6[1]
				if (err != null) {
					return [n, err]
				}
			}
			Encode($.goSlice((h$ as dumper).buf, undefined, undefined), $.goSlice(data, i, i + 1));
			;(h$ as dumper).buf[2] = 32
			let l = 3
			if ((h$ as dumper).used == 7) {
				// There's an additional space after the 8th byte.
				;(h$ as dumper).buf[3] = 32
				l = 4
			} else {
				if ((h$ as dumper).used == 15) {
					// At the end of the line there's an extra space and
					// the bar for the right column.
					;(h$ as dumper).buf[3] = 32;
					;(h$ as dumper).buf[4] = 124
					l = 5
				}
			}
			let __goscriptTuple7: any = await $.pointerValue<Exclude<io.Writer, null>>((h$ as dumper).w).Write($.goSlice((h$ as dumper).buf, undefined, l))
			err = __goscriptTuple7[1]
			if (err != null) {
				return [n, err]
			}
			n++;
			;(h$ as dumper).rightChars[(h$ as dumper).used] = toChar(((__goscriptRangeWindow1.backing as any[])[__goscriptRangeWindow1.offset + i] as number));
			;(h$ as dumper).used++;
			;(h$ as dumper).n++
			if ((h$ as dumper).used == 16) {
				;(h$ as dumper).rightChars[16] = 124;
				;(h$ as dumper).rightChars[17] = 10
				let __goscriptTuple8: any = await $.pointerValue<Exclude<io.Writer, null>>((h$ as dumper).w).Write($.goSlice((h$ as dumper).rightChars, undefined, undefined))
				err = __goscriptTuple8[1]
				if (err != null) {
					return [n, err]
				}
				;(h$ as dumper).used = 0
			}
		}
		return [n, err]
	}

	static __typeInfo = $.registerStructType(
		"hex.dumper",
		() => new dumper(),
		() => [$.methodSignature("Close", [], [["err", "error"]], true), $.methodSignature("Write", [["data", /* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("uint8"))]], [["n", /* @__PURE__ */ $.basicType("int")], ["err", "error"]], true)],
		dumper,
		() => [/* @__PURE__ */ $.structField("w", "io.Writer", [0], 0, false, { pkgPath: "encoding/hex" }), /* @__PURE__ */ $.structField("rightChars", /* @__PURE__ */ $.arrayType(/* @__PURE__ */ $.basicType("uint8"), 18), [1], 16, false, { pkgPath: "encoding/hex" }), /* @__PURE__ */ $.structField("buf", /* @__PURE__ */ $.arrayType(/* @__PURE__ */ $.basicType("uint8"), 14), [2], 34, false, { pkgPath: "encoding/hex" }), /* @__PURE__ */ $.structField("used", /* @__PURE__ */ $.basicType("int"), [3], 48, false, { pkgPath: "encoding/hex" }), /* @__PURE__ */ $.structField("n", /* @__PURE__ */ $.basicType("uint"), [4], 56, false, { pkgPath: "encoding/hex" }), /* @__PURE__ */ $.structField("closed", /* @__PURE__ */ $.basicType("bool"), [5], 64, false, { pkgPath: "encoding/hex" })]
	)
}

export const hextable: string = "0123456789abcdef"

export const reverseHexTable: string = "\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\xff\xff\xff\xff\xff\xff\xff\n\x0b\x0c\r\x0e\x0f\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\n\x0b\x0c\r\x0e\x0f\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff"

export const bufferSize: number = 1024

export function EncodedLen(n: number): number {
	return n * 2
}

export function Encode(dst: $.Slice<number>, src: $.Slice<number>): number {
	let j = 0
	for (let __goscriptRangeTarget0 = src, __goscriptRangeWindow0 = $.sliceRange(__goscriptRangeTarget0), __goscriptSliceWindow0 = $.sliceRange(dst), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow0.length; __rangeIndex++) {
		let v = $.uint((__goscriptRangeWindow0.backing[__goscriptRangeWindow0.offset + __rangeIndex] as number), 8);
		;(__goscriptSliceWindow0.backing as any[])[$.windowSlot(__goscriptSliceWindow0, j)] = $.indexByteString("\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x61\x62\x63\x64\x65\x66", $.uintShr(v, 4, 8));
		;(__goscriptSliceWindow0.backing as any[])[$.windowSlot(__goscriptSliceWindow0, j + 1)] = $.indexByteString("\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x61\x62\x63\x64\x65\x66", v & 0x0f)
		j += 2
	}
	return $.sliceLen(src) * 2
}

export function AppendEncode(dst: $.Slice<number>, src: $.Slice<number>): $.Slice<number> {
	let n = EncodedLen($.sliceLen(src))
	dst = (slices.Grow(dst, n, () => (0 as number)) as $.Slice<number>)
	Encode($.goSlice($.goSlice(dst, $.sliceLen(dst), undefined), undefined, n), src)
	return $.goSlice(dst, undefined, $.sliceLen(dst) + n)
}

export let ErrLength: $.GoError = errors.New("encoding/hex: odd length hex string")

export function __goscript_set_ErrLength(__goscriptValue: $.GoError): void {
	ErrLength = __goscriptValue
}

export function InvalidByteError_Error(e: InvalidByteError): string {
	return (fmt.Sprintf("encoding/hex: invalid byte: %#U", $.basicInterfaceValue(e, "rune", "int32")) as string)
}

export function DecodedLen(x: number): number {
	return globalThis.Math.trunc(x / 2)
}

export function Decode(dst: $.Slice<number>, src: $.Slice<number>): [number, $.GoError] {
	let i = 0
	let j = 0
	for (let __goscriptSliceWindow1 = $.sliceRange(src), __goscriptSliceWindow2 = $.sliceRange(dst); j < (__goscriptSliceWindow1.length - 1); j += 2) {
		let p = ((__goscriptSliceWindow1.backing as any[])[$.windowSlot(__goscriptSliceWindow1, j)] as number)
		let q = ((__goscriptSliceWindow1.backing as any[])[$.windowSlot(__goscriptSliceWindow1, j + 1)] as number)

		let a = $.indexByteString("\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\xff\xff\xff\xff\xff\xff\xff\x0a\x0b\x0c\x0d\x0e\x0f\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\x0a\x0b\x0c\x0d\x0e\x0f\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff", p)
		let b = $.indexByteString("\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\xff\xff\xff\xff\xff\xff\xff\x0a\x0b\x0c\x0d\x0e\x0f\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\x0a\x0b\x0c\x0d\x0e\x0f\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff", q)
		if (a > 0x0f) {
			return [i, $.namedValueInterfaceValue<$.GoError>(p, "hex.InvalidByteError", {"Error": InvalidByteError_Error}, /* @__PURE__ */ $.basicType("uint8", "hex.InvalidByteError"))]
		}
		if (b > 0x0f) {
			return [i, $.namedValueInterfaceValue<$.GoError>(q, "hex.InvalidByteError", {"Error": InvalidByteError_Error}, /* @__PURE__ */ $.basicType("uint8", "hex.InvalidByteError"))]
		}
		;(__goscriptSliceWindow2.backing as any[])[$.windowSlot(__goscriptSliceWindow2, i)] = $.uint((((a << 4) & 0xff)) | b, 8)
		i++
	}
	if (($.sliceLen(src) % 2) == 1) {
		// Check for invalid char before reporting bad length,
		// since the invalid char (if present) is an earlier problem.
		if ($.indexByteString("\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\xff\xff\xff\xff\xff\xff\xff\x0a\x0b\x0c\x0d\x0e\x0f\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\x0a\x0b\x0c\x0d\x0e\x0f\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff", $.typedSliceIndex(src!, j)) > 0x0f) {
			return [i, $.namedValueInterfaceValue<$.GoError>($.typedSliceIndex(src!, j), "hex.InvalidByteError", {"Error": InvalidByteError_Error}, /* @__PURE__ */ $.basicType("uint8", "hex.InvalidByteError"))]
		}
		return [i, ErrLength]
	}
	return [i, null]
}

export function AppendDecode(dst: $.Slice<number>, src: $.Slice<number>): [$.Slice<number>, $.GoError] {
	let n = DecodedLen($.sliceLen(src))
	dst = (slices.Grow(dst, n, () => (0 as number)) as $.Slice<number>)
	let __goscriptTuple0: any = Decode($.goSlice($.goSlice(dst, $.sliceLen(dst), undefined), undefined, n), src)
	n = __goscriptTuple0[0]
	let err: $.GoError = __goscriptTuple0[1]
	return [$.goSlice(dst, undefined, $.sliceLen(dst) + n), err]
}

export function EncodeToString(src: $.Slice<number>): string {
	let dst = $.makeSlice<number>(EncodedLen($.sliceLen(src)), undefined, "byte")
	Encode(dst, src)
	return $.bytesToString(dst)
}

export function DecodeString(s: string): [$.Slice<number>, $.GoError] {
	let dst = $.makeSlice<number>(DecodedLen($.stringLen(s)), undefined, "byte")
	let [n, err] = Decode(dst, $.stringToBytes(s))
	return [$.goSlice(dst, undefined, n), err]
}

export async function Dump(data: $.Slice<number>): globalThis.Promise<string> {
	if ($.sliceLen(data) == 0) {
		return ""
	}

	let buf = $.varRef($.markAsStructValue(new strings.Builder()))
	// Dumper will write 79 bytes per complete 16 byte chunk, and at least
	// 64 bytes for whatever remains. Round the allocation up, since only a
	// maximum of 15 bytes will be wasted.
	buf.value.Grow((1 + (globalThis.Math.trunc(($.sliceLen(data) - 1) / 16))) * 79)

	let __goscriptShadow0 = Dumper($.interfaceValue<io.Writer | null>(buf, "*strings.Builder", __goscriptStatic0()))
	await (__goscriptShadow0 !== null && (__goscriptShadow0 as any).__isVarRef !== true && ((__goscriptShadow0 as any).__goValue === undefined || (__goscriptShadow0 as any).__goType?.charCodeAt(0) !== 42) ? (__goscriptShadow0 as Exclude<io.WriteCloser, null>) : $.pointerValue<Exclude<io.WriteCloser, null>>(__goscriptShadow0)).Write(data)
	await (__goscriptShadow0 !== null && (__goscriptShadow0 as any).__isVarRef !== true && ((__goscriptShadow0 as any).__goValue === undefined || (__goscriptShadow0 as any).__goType?.charCodeAt(0) !== 42) ? (__goscriptShadow0 as Exclude<io.WriteCloser, null>) : $.pointerValue<Exclude<io.WriteCloser, null>>(__goscriptShadow0)).Close()
	return buf.value.String()
}

export function NewEncoder(w: io.Writer | null): io.Writer | null {
	return $.interfaceValue<io.Writer | null>(new encoder(false, w), "*hex.encoder", /* @__PURE__ */ $.pointerType("hex.encoder"))
}

export function NewDecoder(r: io.Reader | null): io.Reader | null {
	return $.interfaceValue<io.Reader | null>(new decoder(false, r), "*hex.decoder", /* @__PURE__ */ $.pointerType("hex.decoder"))
}

export function Dumper(w: io.Writer | null): io.WriteCloser | null {
	return $.interfaceValue<io.WriteCloser | null>(new dumper(false, w), "*hex.dumper", /* @__PURE__ */ $.pointerType("hex.dumper"))
}

export function toChar(b: number): number {
	if ((b < 32) || (b > 126)) {
		return 46
	}
	return b
}

var __goscriptStatic0$value: any
function __goscriptStatic0(): any {
	return __goscriptStatic0$value ??= ($.overrideTypeMethods(/* @__PURE__ */ $.pointerType("strings.Builder"), "strings.Builder", () => [$.methodSignature("Cap", [], [/* @__PURE__ */ $.basicType("int")], true), $.methodSignature("Grow", [["n", /* @__PURE__ */ $.basicType("int")]], [], true), $.methodSignature("Len", [], [/* @__PURE__ */ $.basicType("int")], true), $.methodSignature("Reset", [], [], true), $.methodSignature("String", [], [/* @__PURE__ */ $.basicType("string")], true), $.methodSignature("Write", [["p", /* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("uint8"))]], [/* @__PURE__ */ $.basicType("int"), "error"], true), $.methodSignature("WriteByte", [["c", /* @__PURE__ */ $.basicType("uint8")]], ["error"], true), $.methodSignature("WriteRune", [["r", /* @__PURE__ */ $.basicType("int32")]], [/* @__PURE__ */ $.basicType("int"), "error"], true), $.methodSignature("WriteString", [["s", /* @__PURE__ */ $.basicType("string")]], [/* @__PURE__ */ $.basicType("int"), "error"], true)]))
}

var __goscriptStatic1$value: any
function __goscriptStatic1(): any {
	return __goscriptStatic1$value ??= (/* @__PURE__ */ $.arrayType(/* @__PURE__ */ $.basicType("uint8"), 1024))
}

var __goscriptStatic2$value: any
function __goscriptStatic2(): any {
	return __goscriptStatic2$value ??= (/* @__PURE__ */ $.arrayType(/* @__PURE__ */ $.basicType("uint8"), 18))
}

var __goscriptStatic3$value: any
function __goscriptStatic3(): any {
	return __goscriptStatic3$value ??= (/* @__PURE__ */ $.arrayType(/* @__PURE__ */ $.basicType("uint8"), 14))
}
