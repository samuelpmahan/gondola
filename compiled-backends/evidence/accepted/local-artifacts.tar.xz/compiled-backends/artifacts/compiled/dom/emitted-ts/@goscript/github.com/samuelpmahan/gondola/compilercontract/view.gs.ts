// Generated file based on view.go
// Updated when compliance tests are re-run, DO NOT EDIT!

import * as $ from "@goscript/builtin/index.js"
import * as json from "@goscript/encoding/json/index.js"
import * as fmt from "@goscript/fmt/index.js"
import * as gobi from "@goscript/github.com/samuelpmahan/gondola/gobi/index.js"
import * as __goscript_contract from "./contract.gs.ts"
import * as __goscript_json from "./json.gs.ts"
import * as __goscript_trace from "./trace.gs.ts"
import "@goscript/encoding/json/index.js"
import "@goscript/fmt/index.js"
import "@goscript/github.com/samuelpmahan/gondola/gobi/index.js"
import "./contract.gs.ts"
import "./json.gs.ts"
import "./trace.gs.ts"
