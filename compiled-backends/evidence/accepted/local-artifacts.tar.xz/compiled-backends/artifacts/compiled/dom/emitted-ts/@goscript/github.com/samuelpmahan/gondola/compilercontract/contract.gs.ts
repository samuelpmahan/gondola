// Generated file based on contract.go
// Updated when compliance tests are re-run, DO NOT EDIT!

import * as $ from "@goscript/builtin/index.js"
import * as gobi from "@goscript/github.com/samuelpmahan/gondola/gobi/index.js"
import * as json from "@goscript/encoding/json/index.js"
import * as fmt from "@goscript/fmt/index.js"
import * as __goscript_json from "./json.gs.ts"
import * as __goscript_trace from "./trace.gs.ts"
import * as __goscript_value from "./value.gs.ts"
import * as __goscript_view from "./view.gs.ts"
import "./value.gs.ts"
import "./view.gs.ts"

$.registerTypePackagePath("github.com/samuelpmahan/gondola/compilercontract", ["compilercontract.SymbolID", "compilercontract.TypeID", "compilercontract.Span", "compilercontract.Diagnostic", "compilercontract.Signature", "compilercontract.Symbol", "compilercontract.Component", "compilercontract.AppIR", "compilercontract.TypeKind", "compilercontract.TypeInfo", "compilercontract.JSRepresentation", "compilercontract.TypeField", "compilercontract.Capability", "compilercontract.BindingSource", "compilercontract.Binding", "compilercontract.View", "compilercontract.SourceFile", "compilercontract.OperationKind", "compilercontract.TypedProgram", "compilercontract.TypedPackage", "compilercontract.TypedFunction", "compilercontract.Operation", "compilercontract.AnalyzeOptions", "compilercontract.AnalysisResult", "compilercontract.BuildRequest", "compilercontract.OutputFile", "compilercontract.BuildResult"])

export type SymbolID = string

export type TypeID = string

export type TypeKind = string

export type JSRepresentation = string

export type Capability = string

export type BindingSource = string

export type OperationKind = string

export class Span {
	public declare File: string

	public declare StartByte: number

	public declare EndByte: number

	constructor(__goscriptValue?: boolean, File$?: string, StartByte$?: number, EndByte$?: number) {
		this.File = File$ ?? ""
		this.StartByte = StartByte$ ?? 0
		this.EndByte = EndByte$ ?? 0
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): Span {
		return new Span(true, this.File, this.StartByte, this.EndByte)
	}

	public __goscriptAssign(source: Span): this {
		this.File = source.File
		this.StartByte = source.StartByte
		this.EndByte = source.EndByte
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.Span",
		() => new Span(),
		() => [],
		Span,
		() => [/* @__PURE__ */ $.structField("File", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"file\"" }), /* @__PURE__ */ $.structField("StartByte", /* @__PURE__ */ $.basicType("int"), [1], 16, true, { tag: "json:\"startByte\"" }), /* @__PURE__ */ $.structField("EndByte", /* @__PURE__ */ $.basicType("int"), [2], 24, true, { tag: "json:\"endByte\"" })]
	)
}

export class Diagnostic {
	public declare Code: string

	public declare Severity: string

	public declare Message: string

	public declare Span: Span

	public declare Related: $.Slice<Span>

	constructor(__goscriptValue?: boolean, Code$?: string, Severity$?: string, Message$?: string, Span$?: Span, Related$?: $.Slice<Span>) {
		this.Code = Code$ ?? ""
		this.Severity = Severity$ ?? ""
		this.Message = Message$ ?? ""
		this.Span = Span$ ?? new Span(true)
		this.Related = Related$ ?? (null! as $.Slice<Span>)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): Diagnostic {
		return new Diagnostic(true, this.Code, this.Severity, this.Message, this.Span.clone(), this.Related)
	}

	public __goscriptAssign(source: Diagnostic): this {
		this.Code = source.Code
		this.Severity = source.Severity
		this.Message = source.Message
		this.Span.__goscriptAssign(source.Span)
		this.Related = source.Related
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.Diagnostic",
		() => new Diagnostic(),
		() => [],
		Diagnostic,
		() => [/* @__PURE__ */ $.structField("Code", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"code\"" }), /* @__PURE__ */ $.structField("Severity", /* @__PURE__ */ $.basicType("string"), [1], 16, true, { tag: "json:\"severity\"" }), /* @__PURE__ */ $.structField("Message", /* @__PURE__ */ $.basicType("string"), [2], 32, true, { tag: "json:\"message\"" }), /* @__PURE__ */ $.structField("Span", "compilercontract.Span", [3], 48, true, { tag: "json:\"span\"" }), /* @__PURE__ */ $.structField("Related", /* @__PURE__ */ $.sliceType("compilercontract.Span"), [4], 80, true, { tag: "json:\"related\"" })]
	)
}

export class Signature {
	public declare Params: $.Slice<TypeID>

	public declare Results: $.Slice<TypeID>

	constructor(__goscriptValue?: boolean, Params$?: $.Slice<TypeID>, Results$?: $.Slice<TypeID>) {
		this.Params = Params$ ?? (null! as $.Slice<TypeID>)
		this.Results = Results$ ?? (null! as $.Slice<TypeID>)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): Signature {
		return new Signature(true, this.Params, this.Results)
	}

	public __goscriptAssign(source: Signature): this {
		this.Params = source.Params
		this.Results = source.Results
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.Signature",
		() => new Signature(),
		() => [],
		Signature,
		() => [/* @__PURE__ */ $.structField("Params", /* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), [0], 0, true, { tag: "json:\"params\"" }), /* @__PURE__ */ $.structField("Results", /* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), [1], 24, true, { tag: "json:\"results\"" })]
	)
}

export class Symbol {
	public declare ID: SymbolID

	public declare PackagePath: string

	public declare Name: string

	public declare Signature: Signature

	public declare Span: Span

	public declare Calls: $.Slice<SymbolID>

	constructor(__goscriptValue?: boolean, ID$?: SymbolID, PackagePath$?: string, Name$?: string, Signature$?: Signature, Span$?: Span, Calls$?: $.Slice<SymbolID>) {
		this.ID = ID$ ?? ""
		this.PackagePath = PackagePath$ ?? ""
		this.Name = Name$ ?? ""
		this.Signature = Signature$ ?? new Signature(true)
		this.Span = Span$ ?? new Span(true)
		this.Calls = Calls$ ?? (null! as $.Slice<SymbolID>)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): Symbol {
		return new Symbol(true, this.ID, this.PackagePath, this.Name, this.Signature.clone(), this.Span.clone(), this.Calls)
	}

	public __goscriptAssign(source: Symbol): this {
		this.ID = source.ID
		this.PackagePath = source.PackagePath
		this.Name = source.Name
		this.Signature.__goscriptAssign(source.Signature)
		this.Span.__goscriptAssign(source.Span)
		this.Calls = source.Calls
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.Symbol",
		() => new Symbol(),
		() => [],
		Symbol,
		() => [/* @__PURE__ */ $.structField("ID", /* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID"), [0], 0, true, { tag: "json:\"id\"" }), /* @__PURE__ */ $.structField("PackagePath", /* @__PURE__ */ $.basicType("string"), [1], 16, true, { tag: "json:\"packagePath\"" }), /* @__PURE__ */ $.structField("Name", /* @__PURE__ */ $.basicType("string"), [2], 32, true, { tag: "json:\"name\"" }), /* @__PURE__ */ $.structField("Signature", "compilercontract.Signature", [3], 48, true, { tag: "json:\"signature\"" }), /* @__PURE__ */ $.structField("Span", "compilercontract.Span", [4], 96, true, { tag: "json:\"span\"" }), /* @__PURE__ */ $.structField("Calls", /* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID")), [5], 128, true, { tag: "json:\"calls\"" })]
	)
}

export class Component {
	public declare ID: string

	public declare PackagePath: string

	public declare StateType: TypeID

	public declare MessageType: TypeID

	public declare Init: SymbolID

	public declare Update: SymbolID

	public declare View: SymbolID

	public declare Capabilities: $.Slice<Capability>

	constructor(__goscriptValue?: boolean, ID$?: string, PackagePath$?: string, StateType$?: TypeID, MessageType$?: TypeID, Init$?: SymbolID, Update$?: SymbolID, View$?: SymbolID, Capabilities$?: $.Slice<Capability>) {
		this.ID = ID$ ?? ""
		this.PackagePath = PackagePath$ ?? ""
		this.StateType = StateType$ ?? ""
		this.MessageType = MessageType$ ?? ""
		this.Init = Init$ ?? ""
		this.Update = Update$ ?? ""
		this.View = View$ ?? ""
		this.Capabilities = Capabilities$ ?? (null! as $.Slice<Capability>)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): Component {
		return new Component(true, this.ID, this.PackagePath, this.StateType, this.MessageType, this.Init, this.Update, this.View, this.Capabilities)
	}

	public __goscriptAssign(source: Component): this {
		this.ID = source.ID
		this.PackagePath = source.PackagePath
		this.StateType = source.StateType
		this.MessageType = source.MessageType
		this.Init = source.Init
		this.Update = source.Update
		this.View = source.View
		this.Capabilities = source.Capabilities
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.Component",
		() => new Component(),
		() => [],
		Component,
		() => [/* @__PURE__ */ $.structField("ID", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"id\"" }), /* @__PURE__ */ $.structField("PackagePath", /* @__PURE__ */ $.basicType("string"), [1], 16, true, { tag: "json:\"packagePath\"" }), /* @__PURE__ */ $.structField("StateType", /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID"), [2], 32, true, { tag: "json:\"stateType\"" }), /* @__PURE__ */ $.structField("MessageType", /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID"), [3], 48, true, { tag: "json:\"messageType\"" }), /* @__PURE__ */ $.structField("Init", /* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID"), [4], 64, true, { tag: "json:\"init\"" }), /* @__PURE__ */ $.structField("Update", /* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID"), [5], 80, true, { tag: "json:\"update\"" }), /* @__PURE__ */ $.structField("View", /* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID"), [6], 96, true, { tag: "json:\"view\"" }), /* @__PURE__ */ $.structField("Capabilities", /* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("string", "compilercontract.Capability")), [7], 112, true, { tag: "json:\"capabilities\"" })]
	)
}

export class AppIR {
	public declare Schema: string

	public declare PackagePath: string

	public declare Components: $.Slice<Component>

	public declare Symbols: $.Slice<Symbol>

	public declare Types: $.Slice<TypeInfo>

	constructor(__goscriptValue?: boolean, Schema$?: string, PackagePath$?: string, Components$?: $.Slice<Component>, Symbols$?: $.Slice<Symbol>, Types$?: $.Slice<TypeInfo>) {
		this.Schema = Schema$ ?? ""
		this.PackagePath = PackagePath$ ?? ""
		this.Components = Components$ ?? (null! as $.Slice<Component>)
		this.Symbols = Symbols$ ?? (null! as $.Slice<Symbol>)
		this.Types = Types$ ?? (null! as $.Slice<TypeInfo>)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): AppIR {
		return new AppIR(true, this.Schema, this.PackagePath, this.Components, this.Symbols, this.Types)
	}

	public __goscriptAssign(source: AppIR): this {
		this.Schema = source.Schema
		this.PackagePath = source.PackagePath
		this.Components = source.Components
		this.Symbols = source.Symbols
		this.Types = source.Types
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.AppIR",
		() => new AppIR(),
		() => [],
		AppIR,
		() => [/* @__PURE__ */ $.structField("Schema", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"schema\"" }), /* @__PURE__ */ $.structField("PackagePath", /* @__PURE__ */ $.basicType("string"), [1], 16, true, { tag: "json:\"packagePath\"" }), /* @__PURE__ */ $.structField("Components", /* @__PURE__ */ $.sliceType("compilercontract.Component"), [2], 32, true, { tag: "json:\"components\"" }), /* @__PURE__ */ $.structField("Symbols", /* @__PURE__ */ $.sliceType("compilercontract.Symbol"), [3], 56, true, { tag: "json:\"symbols\"" }), /* @__PURE__ */ $.structField("Types", /* @__PURE__ */ $.sliceType("compilercontract.TypeInfo"), [4], 80, true, { tag: "json:\"types\"" })]
	)
}

export class TypeInfo {
	public declare ID: TypeID

	public declare Kind: TypeKind

	public declare Bits: number

	public declare ElemType: TypeID

	public declare Length: $.VarRef<number> | null

	public declare Fields: $.Slice<TypeField>

	public declare JSRepresentation: JSRepresentation

	constructor(__goscriptValue?: boolean, ID$?: TypeID, Kind$?: TypeKind, Bits$?: number, ElemType$?: TypeID, Length$?: $.VarRef<number> | null, Fields$?: $.Slice<TypeField>, JSRepresentation$?: JSRepresentation) {
		this.ID = ID$ ?? ""
		this.Kind = Kind$ ?? ""
		this.Bits = Bits$ ?? 0
		this.ElemType = ElemType$ ?? ""
		this.Length = Length$ ?? (null! as $.VarRef<number> | null)
		this.Fields = Fields$ ?? (null! as $.Slice<TypeField>)
		this.JSRepresentation = JSRepresentation$ ?? ""
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): TypeInfo {
		return new TypeInfo(true, this.ID, this.Kind, this.Bits, this.ElemType, this.Length, this.Fields, this.JSRepresentation)
	}

	public __goscriptAssign(source: TypeInfo): this {
		this.ID = source.ID
		this.Kind = source.Kind
		this.Bits = source.Bits
		this.ElemType = source.ElemType
		this.Length = source.Length
		this.Fields = source.Fields
		this.JSRepresentation = source.JSRepresentation
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.TypeInfo",
		() => new TypeInfo(),
		() => [],
		TypeInfo,
		() => [/* @__PURE__ */ $.structField("ID", /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID"), [0], 0, true, { tag: "json:\"id\"" }), /* @__PURE__ */ $.structField("Kind", /* @__PURE__ */ $.basicType("string", "compilercontract.TypeKind"), [1], 16, true, { tag: "json:\"kind\"" }), /* @__PURE__ */ $.structField("Bits", /* @__PURE__ */ $.basicType("uint8"), [2], 32, true, { tag: "json:\"bits,omitempty\"" }), /* @__PURE__ */ $.structField("ElemType", /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID"), [3], 40, true, { tag: "json:\"elemType,omitempty\"" }), /* @__PURE__ */ $.structField("Length", /* @__PURE__ */ $.pointerType(/* @__PURE__ */ $.basicType("int")), [4], 56, true, { tag: "json:\"length,omitempty\"" }), /* @__PURE__ */ $.structField("Fields", /* @__PURE__ */ $.sliceType("compilercontract.TypeField"), [5], 64, true, { tag: "json:\"fields,omitempty\"" }), /* @__PURE__ */ $.structField("JSRepresentation", /* @__PURE__ */ $.basicType("string", "compilercontract.JSRepresentation"), [6], 88, true, { tag: "json:\"jsRepresentation,omitempty\"" })]
	)
}

export class TypeField {
	public declare Name: string

	public declare Type: TypeID

	constructor(__goscriptValue?: boolean, Name$?: string, Type$?: TypeID) {
		this.Name = Name$ ?? ""
		this.Type = Type$ ?? ""
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): TypeField {
		return new TypeField(true, this.Name, this.Type)
	}

	public __goscriptAssign(source: TypeField): this {
		this.Name = source.Name
		this.Type = source.Type
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.TypeField",
		() => new TypeField(),
		() => [],
		TypeField,
		() => [/* @__PURE__ */ $.structField("Name", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"name\"" }), /* @__PURE__ */ $.structField("Type", /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID"), [1], 16, true, { tag: "json:\"type\"" })]
	)
}

export class Binding {
	public declare Path: string

	public declare Event: string

	public declare Message: string

	public declare Source: BindingSource

	constructor(__goscriptValue?: boolean, Path$?: string, Event$?: string, Message$?: string, Source$?: BindingSource) {
		this.Path = Path$ ?? ""
		this.Event = Event$ ?? ""
		this.Message = Message$ ?? ""
		this.Source = Source$ ?? ""
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): Binding {
		return new Binding(true, this.Path, this.Event, this.Message, this.Source)
	}

	public __goscriptAssign(source: Binding): this {
		this.Path = source.Path
		this.Event = source.Event
		this.Message = source.Message
		this.Source = source.Source
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.Binding",
		() => new Binding(),
		() => [],
		Binding,
		() => [/* @__PURE__ */ $.structField("Path", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"path\"" }), /* @__PURE__ */ $.structField("Event", /* @__PURE__ */ $.basicType("string"), [1], 16, true, { tag: "json:\"event\"" }), /* @__PURE__ */ $.structField("Message", /* @__PURE__ */ $.basicType("string"), [2], 32, true, { tag: "json:\"message\"" }), /* @__PURE__ */ $.structField("Source", /* @__PURE__ */ $.basicType("string", "compilercontract.BindingSource"), [3], 48, true, { tag: "json:\"source\"" })]
	)
}

export class View {
	public declare Tree: gobi.Node

	public declare Bindings: $.Slice<Binding>

	constructor(__goscriptValue?: boolean, Tree$?: gobi.Node, Bindings$?: $.Slice<Binding>) {
		this.Tree = Tree$ ?? new gobi.Node(true)
		this.Bindings = Bindings$ ?? (null! as $.Slice<Binding>)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): View {
		return new View(true, this.Tree.clone(), this.Bindings)
	}

	public __goscriptAssign(source: View): this {
		this.Tree.__goscriptAssign(source.Tree)
		this.Bindings = source.Bindings
		return this
	}

	public MarshalJSON(): [$.Slice<number>, $.GoError] {
		const view = this;
		return (json.Marshal($.structInterfaceValue(__goscript_trace.ViewRecordFromView(view), "compilercontract.ViewRecord", "compilercontract.ViewRecord")) as [$.Slice<number>, $.GoError])
	}

	public async UnmarshalJSON(data: $.Slice<number>): globalThis.Promise<$.GoError> {
		const view: View | $.VarRef<View> | null = this;
		if (view == null) {
			return fmt.Errorf("cannot unmarshal View into nil receiver")
		}
		let raw: $.VarRef<{"Tree": __goscript_trace.NodeRecord, "Bindings": $.Slice<Binding>}> = $.varRef($.anonymousStructValue({"Tree": new __goscript_trace.NodeRecord(true), "Bindings": null}, { kind: $.TypeKind.Struct, methods: [], fields: [/* @__PURE__ */ $.structField("Tree", "compilercontract.NodeRecord", [0], 0, true, { tag: "json:\"tree\"" }), /* @__PURE__ */ $.structField("Bindings", /* @__PURE__ */ $.sliceType("compilercontract.Binding"), [1], 128, true, { tag: "json:\"bindings\"" })] }))
		{
			let err = await __goscript_json.decodeClosed(data, $.interfaceValue(raw, "*struct{Tree compilercontract.NodeRecord \"json:\\\"tree\\\"\"; Bindings []compilercontract.Binding \"json:\\\"bindings\\\"\"}", /* @__PURE__ */ $.pointerType({ kind: $.TypeKind.Struct, methods: [], fields: [/* @__PURE__ */ $.structField("Tree", "compilercontract.NodeRecord", [0], 0, true, { tag: "json:\"tree\"" }), /* @__PURE__ */ $.structField("Bindings", /* @__PURE__ */ $.sliceType("compilercontract.Binding"), [1], 128, true, { tag: "json:\"bindings\"" })] })))
			if (err != null) {
				return err
			}
		}
		if (raw.value.Bindings == null) {
			return fmt.Errorf("view.bindings is required and must be an array")
		}
		$.pointerValue<View>(view).__goscriptAssign((() => { const __goscriptLiteralField0 = $.markAsStructValue($.cloneStructValue(raw.value.Tree)).GobiNode(); return new View(true, __goscriptLiteralField0, raw.value.Bindings) })())
		return null
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.View",
		() => new View(),
		() => [$.methodSignature("MarshalJSON", [], [/* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("uint8")), "error"]), $.methodSignature("UnmarshalJSON", [["data", /* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("uint8"))]], ["error"], true)],
		View,
		() => [/* @__PURE__ */ $.structField("Tree", "gobi.Node", [0], 0, true, { tag: "json:\"-\"" }), /* @__PURE__ */ $.structField("Bindings", /* @__PURE__ */ $.sliceType("compilercontract.Binding"), [1], 128, true, { tag: "json:\"-\"" })]
	)
}

export class SourceFile {
	public declare Path: string

	public declare Source: string

	constructor(__goscriptValue?: boolean, Path$?: string, Source$?: string) {
		this.Path = Path$ ?? ""
		this.Source = Source$ ?? ""
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): SourceFile {
		return new SourceFile(true, this.Path, this.Source)
	}

	public __goscriptAssign(source: SourceFile): this {
		this.Path = source.Path
		this.Source = source.Source
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.SourceFile",
		() => new SourceFile(),
		() => [],
		SourceFile,
		() => [/* @__PURE__ */ $.structField("Path", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"path\"" }), /* @__PURE__ */ $.structField("Source", /* @__PURE__ */ $.basicType("string"), [1], 16, true, { tag: "json:\"source\"" })]
	)
}

export class TypedProgram {
	public declare Packages: $.Slice<TypedPackage>

	constructor(__goscriptValue?: boolean, Packages$?: $.Slice<TypedPackage>) {
		this.Packages = Packages$ ?? (null! as $.Slice<TypedPackage>)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): TypedProgram {
		return new TypedProgram(true, this.Packages)
	}

	public __goscriptAssign(source: TypedProgram): this {
		this.Packages = source.Packages
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.TypedProgram",
		() => new TypedProgram(),
		() => [],
		TypedProgram,
		() => [/* @__PURE__ */ $.structField("Packages", /* @__PURE__ */ $.sliceType("compilercontract.TypedPackage"), [0], 0, true, { tag: "json:\"packages\"" })]
	)
}

export class TypedPackage {
	public declare ImportPath: string

	public declare Files: $.Slice<SourceFile>

	public declare Types: $.Slice<TypeInfo>

	public declare Functions: $.Slice<TypedFunction>

	constructor(__goscriptValue?: boolean, ImportPath$?: string, Files$?: $.Slice<SourceFile>, Types$?: $.Slice<TypeInfo>, Functions$?: $.Slice<TypedFunction>) {
		this.ImportPath = ImportPath$ ?? ""
		this.Files = Files$ ?? (null! as $.Slice<SourceFile>)
		this.Types = Types$ ?? (null! as $.Slice<TypeInfo>)
		this.Functions = Functions$ ?? (null! as $.Slice<TypedFunction>)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): TypedPackage {
		return new TypedPackage(true, this.ImportPath, this.Files, this.Types, this.Functions)
	}

	public __goscriptAssign(source: TypedPackage): this {
		this.ImportPath = source.ImportPath
		this.Files = source.Files
		this.Types = source.Types
		this.Functions = source.Functions
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.TypedPackage",
		() => new TypedPackage(),
		() => [],
		TypedPackage,
		() => [/* @__PURE__ */ $.structField("ImportPath", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"importPath\"" }), /* @__PURE__ */ $.structField("Files", /* @__PURE__ */ $.sliceType("compilercontract.SourceFile"), [1], 16, true, { tag: "json:\"files\"" }), /* @__PURE__ */ $.structField("Types", /* @__PURE__ */ $.sliceType("compilercontract.TypeInfo"), [2], 40, true, { tag: "json:\"types\"" }), /* @__PURE__ */ $.structField("Functions", /* @__PURE__ */ $.sliceType("compilercontract.TypedFunction"), [3], 64, true, { tag: "json:\"functions\"" })]
	)
}

export class TypedFunction {
	public declare ID: SymbolID

	public declare PackagePath: string

	public declare Name: string

	public declare Signature: Signature

	public declare Span: Span

	public declare Body: $.Slice<Operation>

	constructor(__goscriptValue?: boolean, ID$?: SymbolID, PackagePath$?: string, Name$?: string, Signature$?: Signature, Span$?: Span, Body$?: $.Slice<Operation>) {
		this.ID = ID$ ?? ""
		this.PackagePath = PackagePath$ ?? ""
		this.Name = Name$ ?? ""
		this.Signature = Signature$ ?? new Signature(true)
		this.Span = Span$ ?? new Span(true)
		this.Body = Body$ ?? (null! as $.Slice<Operation>)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): TypedFunction {
		return new TypedFunction(true, this.ID, this.PackagePath, this.Name, this.Signature.clone(), this.Span.clone(), this.Body)
	}

	public __goscriptAssign(source: TypedFunction): this {
		this.ID = source.ID
		this.PackagePath = source.PackagePath
		this.Name = source.Name
		this.Signature.__goscriptAssign(source.Signature)
		this.Span.__goscriptAssign(source.Span)
		this.Body = source.Body
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.TypedFunction",
		() => new TypedFunction(),
		() => [],
		TypedFunction,
		() => [/* @__PURE__ */ $.structField("ID", /* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID"), [0], 0, true, { tag: "json:\"id\"" }), /* @__PURE__ */ $.structField("PackagePath", /* @__PURE__ */ $.basicType("string"), [1], 16, true, { tag: "json:\"packagePath\"" }), /* @__PURE__ */ $.structField("Name", /* @__PURE__ */ $.basicType("string"), [2], 32, true, { tag: "json:\"name\"" }), /* @__PURE__ */ $.structField("Signature", "compilercontract.Signature", [3], 48, true, { tag: "json:\"signature\"" }), /* @__PURE__ */ $.structField("Span", "compilercontract.Span", [4], 96, true, { tag: "json:\"span\"" }), /* @__PURE__ */ $.structField("Body", /* @__PURE__ */ $.sliceType("compilercontract.Operation"), [5], 128, true, { tag: "json:\"body\"" })]
	)
}

export class Operation {
	public declare Kind: OperationKind

	public declare Span: Span

	public declare TypeID: TypeID

	public declare SymbolID: SymbolID

	public declare Operator: string

	public declare Literal: __goscript_value.Value | $.VarRef<__goscript_value.Value> | null

	public declare Children: $.Slice<Operation>

	constructor(__goscriptValue?: boolean, Kind$?: OperationKind, Span$?: Span, TypeID$?: TypeID, SymbolID$?: SymbolID, Operator$?: string, Literal$?: __goscript_value.Value | $.VarRef<__goscript_value.Value> | null, Children$?: $.Slice<Operation>) {
		this.Kind = Kind$ ?? ""
		this.Span = Span$ ?? new Span(true)
		this.TypeID = TypeID$ ?? ""
		this.SymbolID = SymbolID$ ?? ""
		this.Operator = Operator$ ?? ""
		this.Literal = Literal$ ?? (null! as __goscript_value.Value | $.VarRef<__goscript_value.Value> | null)
		this.Children = Children$ ?? (null! as $.Slice<Operation>)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): Operation {
		return new Operation(true, this.Kind, this.Span.clone(), this.TypeID, this.SymbolID, this.Operator, this.Literal, this.Children)
	}

	public __goscriptAssign(source: Operation): this {
		this.Kind = source.Kind
		this.Span.__goscriptAssign(source.Span)
		this.TypeID = source.TypeID
		this.SymbolID = source.SymbolID
		this.Operator = source.Operator
		this.Literal = source.Literal
		this.Children = source.Children
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.Operation",
		() => new Operation(),
		() => [],
		Operation,
		() => [/* @__PURE__ */ $.structField("Kind", /* @__PURE__ */ $.basicType("string", "compilercontract.OperationKind"), [0], 0, true, { tag: "json:\"kind\"" }), /* @__PURE__ */ $.structField("Span", "compilercontract.Span", [1], 16, true, { tag: "json:\"span\"" }), /* @__PURE__ */ $.structField("TypeID", /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID"), [2], 48, true, { tag: "json:\"typeId,omitempty\"" }), /* @__PURE__ */ $.structField("SymbolID", /* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID"), [3], 64, true, { tag: "json:\"symbolId,omitempty\"" }), /* @__PURE__ */ $.structField("Operator", /* @__PURE__ */ $.basicType("string"), [4], 80, true, { tag: "json:\"operator,omitempty\"" }), /* @__PURE__ */ $.structField("Literal", /* @__PURE__ */ $.pointerType("compilercontract.Value"), [5], 96, true, { tag: "json:\"literal,omitempty\"" }), /* @__PURE__ */ $.structField("Children", /* @__PURE__ */ $.sliceType("compilercontract.Operation"), [6], 104, true, { tag: "json:\"children\"" })]
	)
}

export class AnalyzeOptions {
	public declare EntryPackages: $.Slice<string>

	constructor(__goscriptValue?: boolean, EntryPackages$?: $.Slice<string>) {
		this.EntryPackages = EntryPackages$ ?? (null! as $.Slice<string>)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): AnalyzeOptions {
		return new AnalyzeOptions(true, this.EntryPackages)
	}

	public __goscriptAssign(source: AnalyzeOptions): this {
		this.EntryPackages = source.EntryPackages
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.AnalyzeOptions",
		() => new AnalyzeOptions(),
		() => [],
		AnalyzeOptions,
		() => [/* @__PURE__ */ $.structField("EntryPackages", /* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("string")), [0], 0, true, { tag: "json:\"entryPackages\"" })]
	)
}

export class AnalysisResult {
	public declare Apps: $.Slice<AppIR>

	public declare Diagnostics: $.Slice<Diagnostic>

	constructor(__goscriptValue?: boolean, Apps$?: $.Slice<AppIR>, Diagnostics$?: $.Slice<Diagnostic>) {
		this.Apps = Apps$ ?? (null! as $.Slice<AppIR>)
		this.Diagnostics = Diagnostics$ ?? (null! as $.Slice<Diagnostic>)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): AnalysisResult {
		return new AnalysisResult(true, this.Apps, this.Diagnostics)
	}

	public __goscriptAssign(source: AnalysisResult): this {
		this.Apps = source.Apps
		this.Diagnostics = source.Diagnostics
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.AnalysisResult",
		() => new AnalysisResult(),
		() => [],
		AnalysisResult,
		() => [/* @__PURE__ */ $.structField("Apps", /* @__PURE__ */ $.sliceType("compilercontract.AppIR"), [0], 0, true, { tag: "json:\"apps\"" }), /* @__PURE__ */ $.structField("Diagnostics", /* @__PURE__ */ $.sliceType("compilercontract.Diagnostic"), [1], 24, true, { tag: "json:\"diagnostics\"" })]
	)
}

export class BuildRequest {
	public declare Schema: string

	public declare SourceRoot: string

	public declare EntryPackages: $.Slice<string>

	public declare Backend: string

	public declare OutputDir: string

	constructor(__goscriptValue?: boolean, Schema$?: string, SourceRoot$?: string, EntryPackages$?: $.Slice<string>, Backend$?: string, OutputDir$?: string) {
		this.Schema = Schema$ ?? ""
		this.SourceRoot = SourceRoot$ ?? ""
		this.EntryPackages = EntryPackages$ ?? (null! as $.Slice<string>)
		this.Backend = Backend$ ?? ""
		this.OutputDir = OutputDir$ ?? ""
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): BuildRequest {
		return new BuildRequest(true, this.Schema, this.SourceRoot, this.EntryPackages, this.Backend, this.OutputDir)
	}

	public __goscriptAssign(source: BuildRequest): this {
		this.Schema = source.Schema
		this.SourceRoot = source.SourceRoot
		this.EntryPackages = source.EntryPackages
		this.Backend = source.Backend
		this.OutputDir = source.OutputDir
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.BuildRequest",
		() => new BuildRequest(),
		() => [],
		BuildRequest,
		() => [/* @__PURE__ */ $.structField("Schema", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"schema\"" }), /* @__PURE__ */ $.structField("SourceRoot", /* @__PURE__ */ $.basicType("string"), [1], 16, true, { tag: "json:\"sourceRoot\"" }), /* @__PURE__ */ $.structField("EntryPackages", /* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("string")), [2], 32, true, { tag: "json:\"entryPackages\"" }), /* @__PURE__ */ $.structField("Backend", /* @__PURE__ */ $.basicType("string"), [3], 56, true, { tag: "json:\"backend\"" }), /* @__PURE__ */ $.structField("OutputDir", /* @__PURE__ */ $.basicType("string"), [4], 72, true, { tag: "json:\"outputDir\"" })]
	)
}

export class OutputFile {
	public declare Path: string

	public declare SHA256: string

	public declare Bytes: bigint

	constructor(__goscriptValue?: boolean, Path$?: string, SHA256$?: string, Bytes$?: bigint) {
		this.Path = Path$ ?? ""
		this.SHA256 = SHA256$ ?? ""
		this.Bytes = Bytes$ ?? 0n
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): OutputFile {
		return new OutputFile(true, this.Path, this.SHA256, this.Bytes)
	}

	public __goscriptAssign(source: OutputFile): this {
		this.Path = source.Path
		this.SHA256 = source.SHA256
		this.Bytes = source.Bytes
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.OutputFile",
		() => new OutputFile(),
		() => [],
		OutputFile,
		() => [/* @__PURE__ */ $.structField("Path", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"path\"" }), /* @__PURE__ */ $.structField("SHA256", /* @__PURE__ */ $.basicType("string"), [1], 16, true, { tag: "json:\"sha256\"" }), /* @__PURE__ */ $.structField("Bytes", /* @__PURE__ */ $.basicType("int64"), [2], 32, true, { tag: "json:\"bytes\"" })]
	)
}

export class BuildResult {
	public declare Schema: string

	public declare OK: boolean

	public declare Apps: $.Slice<AppIR>

	public declare Outputs: $.Slice<OutputFile>

	public declare Diagnostics: $.Slice<Diagnostic>

	public declare PreservedPreviousOutput: boolean

	constructor(__goscriptValue?: boolean, Schema$?: string, OK$?: boolean, Apps$?: $.Slice<AppIR>, Outputs$?: $.Slice<OutputFile>, Diagnostics$?: $.Slice<Diagnostic>, PreservedPreviousOutput$?: boolean) {
		this.Schema = Schema$ ?? ""
		this.OK = OK$ ?? false
		this.Apps = Apps$ ?? (null! as $.Slice<AppIR>)
		this.Outputs = Outputs$ ?? (null! as $.Slice<OutputFile>)
		this.Diagnostics = Diagnostics$ ?? (null! as $.Slice<Diagnostic>)
		this.PreservedPreviousOutput = PreservedPreviousOutput$ ?? false
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): BuildResult {
		return new BuildResult(true, this.Schema, this.OK, this.Apps, this.Outputs, this.Diagnostics, this.PreservedPreviousOutput)
	}

	public __goscriptAssign(source: BuildResult): this {
		this.Schema = source.Schema
		this.OK = source.OK
		this.Apps = source.Apps
		this.Outputs = source.Outputs
		this.Diagnostics = source.Diagnostics
		this.PreservedPreviousOutput = source.PreservedPreviousOutput
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.BuildResult",
		() => new BuildResult(),
		() => [],
		BuildResult,
		() => [/* @__PURE__ */ $.structField("Schema", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"schema\"" }), /* @__PURE__ */ $.structField("OK", /* @__PURE__ */ $.basicType("bool"), [1], 16, true, { tag: "json:\"ok\"" }), /* @__PURE__ */ $.structField("Apps", /* @__PURE__ */ $.sliceType("compilercontract.AppIR"), [2], 24, true, { tag: "json:\"apps\"" }), /* @__PURE__ */ $.structField("Outputs", /* @__PURE__ */ $.sliceType("compilercontract.OutputFile"), [3], 48, true, { tag: "json:\"outputs\"" }), /* @__PURE__ */ $.structField("Diagnostics", /* @__PURE__ */ $.sliceType("compilercontract.Diagnostic"), [4], 72, true, { tag: "json:\"diagnostics\"" }), /* @__PURE__ */ $.structField("PreservedPreviousOutput", /* @__PURE__ */ $.basicType("bool"), [5], 96, true, { tag: "json:\"preservedPreviousOutput\"" })]
	)
}

export const AppIRSchema: string = "gobi.app-ir/v1"

export const BuildRequestSchema: string = "gobi.build-request/v1"

export const BuildResultSchema: string = "gobi.build-result/v1"

export const TraceSchema: string = "gobi.trace/v1"

export const HostScriptSchema: string = "gobi.host-script/v1"

export const CompiledModuleSchema: string = "gobi.compiled-module/v1"

export const KindBool: TypeKind = "bool"

export const KindString: TypeKind = "string"

export const KindInt: TypeKind = "int"

export const KindUint: TypeKind = "uint"

export const KindFloat64: TypeKind = "float64"

export const KindStruct: TypeKind = "struct"

export const KindSlice: TypeKind = "slice"

export const KindArray: TypeKind = "array"

export const JSDirect: JSRepresentation = "direct"

export const JSBigInt: JSRepresentation = "bigint"

export const JSNumber: JSRepresentation = "number"

export const JSClass: JSRepresentation = "class"

export const JSArray: JSRepresentation = "array"

export const JSFloat64Array: JSRepresentation = "float64-array"

export const JSSliceWrapper: JSRepresentation = "goscript-slice"

export const JSArrayOrSlice: JSRepresentation = "array-or-goscript-slice"

export const JSFloat64ArrayOrSlice: JSRepresentation = "float64-array-or-goscript-slice"

export const CapabilityViewNode: Capability = "view.node"

export const CapabilityBindingValue: Capability = "binding.value"

export const CapabilityBindingChecked: Capability = "binding.checked"

export const CapabilityEffectRequest: Capability = "effect.request-reply"

export const CapabilitySafeInteger: Capability = "numeric.safe-integer"

export const CapabilityFloat64: Capability = "numeric.float64"

export const TargetValue: BindingSource = "target.value"

export const TargetChecked: BindingSource = "target.checked"

export const OpUnsupported: OperationKind = "unsupported"

export const OpBlock: OperationKind = "block"

export const OpDecl: OperationKind = "decl"

export const OpAssign: OperationKind = "assign"

export const OpReturn: OperationKind = "return"

export const OpIf: OperationKind = "if"

export const OpSwitch: OperationKind = "switch"

export const OpFor: OperationKind = "for"

export const OpRange: OperationKind = "range"

export const OpExpr: OperationKind = "expr"

export const OpIncDec: OperationKind = "incDec"

export const OpLiteral: OperationKind = "literal"

export const OpIdent: OperationKind = "ident"

export const OpBinary: OperationKind = "binary"

export const OpUnary: OperationKind = "unary"

export const OpCall: OperationKind = "call"

export const OpSelector: OperationKind = "selector"

export const OpIndex: OperationKind = "index"

export const OpComposite: OperationKind = "composite"

export const OpKeyValue: OperationKind = "keyValue"

export const OpParen: OperationKind = "paren"

export const OpBranch: OperationKind = "branch"
