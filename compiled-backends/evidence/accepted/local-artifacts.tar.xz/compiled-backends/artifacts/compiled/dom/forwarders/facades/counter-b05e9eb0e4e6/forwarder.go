package facade

import (
	gobiApp "github.com/samuelpmahan/gondola/counter"
	gobiType0 "github.com/samuelpmahan/gondola/gobi"
)

func GobiCompiledInit() gobiApp.State {
	return gobiApp.Init()
}

func GobiCompiledUpdate(state gobiApp.State, message gobiType0.Message) (gobiApp.State, []gobiType0.Effect) {
	return gobiApp.Update(state, message)
}

func GobiCompiledView(state gobiApp.State) gobiType0.Node {
	return gobiApp.View(state)
}
