// Generated file based on validation.go
// Updated when compliance tests are re-run, DO NOT EDIT!

import * as $ from "@goscript/builtin/index.js"
import * as fmt from "@goscript/fmt/index.js"
import * as path2 from "@goscript/path/index.js"
import * as regexp from "@goscript/regexp/index.js"
import * as strconv from "@goscript/strconv/index.js"
import * as strings from "@goscript/strings/index.js"
import * as utf8 from "@goscript/unicode/utf8/index.js"
import * as gobi from "@goscript/github.com/samuelpmahan/gondola/gobi/index.js"
import * as __goscript_contract from "./contract.gs.ts"
import * as __goscript_trace from "./trace.gs.ts"
import * as __goscript_value from "./value.gs.ts"
import "@goscript/encoding/json/index.js"
import "@goscript/bytes/index.js"
import "@goscript/io/index.js"
import "@goscript/reflect/index.js"
import "@goscript/encoding/hex/index.js"
import "@goscript/math/index.js"
import "@goscript/github.com/samuelpmahan/gondola/gobi/index.js"

$.registerTypePackagePath("github.com/samuelpmahan/gondola/compilercontract", ["compilercontract.requestKey"])

export let safeNamePattern: regexp.Regexp | $.VarRef<regexp.Regexp> | null = await regexp.MustCompile("^[A-Za-z_][A-Za-z0-9_.:/-]*$")

export function __goscript_set_safeNamePattern(__goscriptValue: regexp.Regexp | $.VarRef<regexp.Regexp> | null): void {
	safeNamePattern = __goscriptValue
}

export let htmlTagPattern: regexp.Regexp | $.VarRef<regexp.Regexp> | null = await regexp.MustCompile("^[a-z][a-z0-9-]*$")

export function __goscript_set_htmlTagPattern(__goscriptValue: regexp.Regexp | $.VarRef<regexp.Regexp> | null): void {
	htmlTagPattern = __goscriptValue
}

export let attrPattern: regexp.Regexp | $.VarRef<regexp.Regexp> | null = await regexp.MustCompile("^[a-z][a-z0-9:_-]*$")

export function __goscript_set_attrPattern(__goscriptValue: regexp.Regexp | $.VarRef<regexp.Regexp> | null): void {
	attrPattern = __goscriptValue
}

export let supportedEvents: globalThis.Map<string, boolean> | null = $.makeMap<string, boolean>([["click", true], ["dblclick", true], ["input", true], ["change", true], ["submit", true], ["reset", true], ["select", true], ["keydown", true], ["keyup", true], ["keypress", true], ["mouseenter", true], ["mouseleave", true], ["mousedown", true], ["mouseup", true], ["mousemove", true], ["focus", true], ["blur", true], ["scroll", true], ["wheel", true], ["touchstart", true], ["touchend", true], ["pointerdown", true], ["pointerup", true], ["load", true], ["error", true], ["contextmenu", true]])

export function __goscript_set_supportedEvents(__goscriptValue: globalThis.Map<string, boolean> | null): void {
	supportedEvents = __goscriptValue
}

export async function ValidateAppIR(app: __goscript_contract.AppIR): globalThis.Promise<$.Slice<__goscript_contract.Diagnostic>> {
	let out: $.Slice<__goscript_contract.Diagnostic> = null! as $.Slice<__goscript_contract.Diagnostic>
	let add = $.functionValue((code: string, message: string, span: __goscript_contract.Span) => {
		out = $.appendOne(out, new __goscript_contract.Diagnostic(true, code, "error", message, (span).clone(), $.arrayToSlice<__goscript_contract.Span>([])))
	}, ({ kind: $.TypeKind.Function, params: [/* @__PURE__ */ $.basicType("string"), /* @__PURE__ */ $.basicType("string"), "compilercontract.Span"], results: [] } as $.FunctionTypeInfo))
	if (!$.stringEqual(app.Schema, "gobi.app-ir/v1")) {
		add("app.schema", (fmt.Sprintf("schema must be %q", "gobi.app-ir/v1") as string), new __goscript_contract.Span(true))
	}
	if ($.stringEqual(app.PackagePath, "")) {
		add("app.package", "packagePath is required", new __goscript_contract.Span(true))
	}
	if (((app.Components == null) || (app.Symbols == null)) || (app.Types == null)) {
		add("app.arrays", "components, symbols, and types must be non-null arrays", new __goscript_contract.Span(true))
		return out
	}
	let __goscriptTuple0: any = __goscript_value.indexTypes(app.Types)
	let types: globalThis.Map<__goscript_contract.TypeID, __goscript_contract.TypeInfo> | null = __goscriptTuple0[0]
	let err: $.GoError = __goscriptTuple0[1]
	if (err != null) {
		add("app.types", (__goscriptAwait = (err !== null && (err as any).__isVarRef !== true && ((err as any).__goValue === undefined || (err as any).__goType?.charCodeAt(0) !== 42) ? (err as Exclude<$.GoError, null>) : $.pointerValue<Exclude<$.GoError, null>>(err)).Error(), __goscriptAwait instanceof Promise ? await __goscriptAwait : __goscriptAwait), new __goscript_contract.Span(true))
	}
	for (let __goscriptRangeTarget0 = app.Types, __goscriptRangeWindow0 = $.sliceRange(__goscriptRangeTarget0), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow0.length; __rangeIndex++) {
		let info = ((__goscriptRangeWindow0.backing[__goscriptRangeWindow0.offset + __rangeIndex] as __goscript_contract.TypeInfo)).clone()
		if (!validJSRepresentation(info)) {
			add("app.js-representation", (fmt.Sprintf("type %q has unprobed or incompatible jsRepresentation %q", $.namedValueInterfaceValue<any>(info.ID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), $.namedValueInterfaceValue<any>(info.JSRepresentation, "compilercontract.JSRepresentation", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.JSRepresentation"))) as string), new __goscript_contract.Span(true))
		}
	}
	{
		let __goscriptShadow0 = validateSliceRepresentations(app.Types)
		if (__goscriptShadow0 != null) {
			add("app.js-representation", (__goscriptAwait = (__goscriptShadow0 !== null && (__goscriptShadow0 as any).__isVarRef !== true && ((__goscriptShadow0 as any).__goValue === undefined || (__goscriptShadow0 as any).__goType?.charCodeAt(0) !== 42) ? (__goscriptShadow0 as Exclude<$.GoError, null>) : $.pointerValue<Exclude<$.GoError, null>>(__goscriptShadow0)).Error(), __goscriptAwait instanceof Promise ? await __goscriptAwait : __goscriptAwait), new __goscript_contract.Span(true))
		}
	}
	let symbols = $.makeMap<__goscript_contract.SymbolID, __goscript_contract.Symbol>()
	for (let __goscriptRangeTarget3 = app.Symbols, __goscriptRangeWindow1 = $.sliceRange(__goscriptRangeTarget3), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow1.length; __rangeIndex++) {
		let _symbol = ((__goscriptRangeWindow1.backing[__goscriptRangeWindow1.offset + __rangeIndex] as __goscript_contract.Symbol)).clone()
		if (($.stringEqual(_symbol.ID, "")) || !await (safeNamePattern !== null && (safeNamePattern as any).__isVarRef !== true && (safeNamePattern as any).__goValue === undefined ? ((safeNamePattern as any) as regexp.Regexp).MatchString(_symbol.ID) : regexp.Regexp.prototype.MatchString.call(safeNamePattern, _symbol.ID))) {
			add("app.symbol-id", (fmt.Sprintf("invalid symbol ID %q", $.namedValueInterfaceValue<any>(_symbol.ID, "compilercontract.SymbolID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID"))) as string), (_symbol.Span).clone())
		}
		{
			let [, exists] = $.mapGet<__goscript_contract.SymbolID, __goscript_contract.Symbol, __goscript_contract.Symbol>(symbols, _symbol.ID, new __goscript_contract.Symbol(true))
			if (exists) {
				add("app.symbol-duplicate", (fmt.Sprintf("duplicate symbol ID %q", $.namedValueInterfaceValue<any>(_symbol.ID, "compilercontract.SymbolID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID"))) as string), (_symbol.Span).clone())
			}
		}
		$.mapSet(symbols, _symbol.ID, (_symbol).clone())
		if (($.stringEqual(_symbol.PackagePath, "")) || ($.stringEqual(_symbol.Name, ""))) {
			add("app.symbol", (fmt.Sprintf("symbol %q requires packagePath and name", $.namedValueInterfaceValue<any>(_symbol.ID, "compilercontract.SymbolID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID"))) as string), (_symbol.Span).clone())
		}
		{
			let __goscriptShadow1 = validateSpan((_symbol.Span).clone())
			if (__goscriptShadow1 != null) {
				add("app.span", await fmt.Sprintf("symbol %q: %v", $.namedValueInterfaceValue<any>(_symbol.ID, "compilercontract.SymbolID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID")), (__goscriptShadow1 as any)), (_symbol.Span).clone())
			}
		}
		if (((_symbol.Signature.Params == null) || (_symbol.Signature.Results == null)) || (_symbol.Calls == null)) {
			add("app.symbol-arrays", (fmt.Sprintf("symbol %q params, results, and calls must be non-null arrays", $.namedValueInterfaceValue<any>(_symbol.ID, "compilercontract.SymbolID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID"))) as string), (_symbol.Span).clone())
		}
		for (let __goscriptRangeTarget1 = $.appendSlice($.appendSlice($.arrayToSlice<__goscript_contract.TypeID>([]), _symbol.Signature.Params), _symbol.Signature.Results), __goscriptRangeWindow2 = $.sliceRange(__goscriptRangeTarget1), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow2.length; __rangeIndex++) {
			let typeID = (__goscriptRangeWindow2.backing[__goscriptRangeWindow2.offset + __rangeIndex] as __goscript_contract.TypeID)
			{
				let [, ok] = $.mapGet<__goscript_contract.TypeID, __goscript_contract.TypeInfo, __goscript_contract.TypeInfo>(types, typeID, new __goscript_contract.TypeInfo(true))
				if (!ok) {
					add("app.symbol-type", (fmt.Sprintf("symbol %q refers to unknown type %q", $.namedValueInterfaceValue<any>(_symbol.ID, "compilercontract.SymbolID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID")), $.namedValueInterfaceValue<any>(typeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID"))) as string), (_symbol.Span).clone())
				}
			}
		}
		let seenCalls = $.makeMap<__goscript_contract.SymbolID, boolean>([])
		for (let __goscriptRangeTarget2 = _symbol.Calls, __goscriptRangeWindow3 = $.sliceRange(__goscriptRangeTarget2), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow3.length; __rangeIndex++) {
			let target = (__goscriptRangeWindow3.backing[__goscriptRangeWindow3.offset + __rangeIndex] as __goscript_contract.SymbolID)
			if ($.mapGet<__goscript_contract.SymbolID, boolean, boolean>(seenCalls, target, false)[0]) {
				add("app.call-duplicate", (fmt.Sprintf("symbol %q repeats call target %q", $.namedValueInterfaceValue<any>(_symbol.ID, "compilercontract.SymbolID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID")), $.namedValueInterfaceValue<any>(target, "compilercontract.SymbolID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID"))) as string), (_symbol.Span).clone())
			}
			$.mapSet(seenCalls, target, true)
			{
				let [, ok] = $.mapGet<__goscript_contract.SymbolID, __goscript_contract.Symbol, __goscript_contract.Symbol>(symbols, target, new __goscript_contract.Symbol(true))
				if (!ok) {
				}
			}
		}
	}
	for (let __goscriptRangeTarget5 = app.Symbols, __goscriptRangeWindow4 = $.sliceRange(__goscriptRangeTarget5), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow4.length; __rangeIndex++) {
		let _symbol = ((__goscriptRangeWindow4.backing[__goscriptRangeWindow4.offset + __rangeIndex] as __goscript_contract.Symbol)).clone()
		for (let __goscriptRangeTarget4 = _symbol.Calls, __goscriptRangeWindow5 = $.sliceRange(__goscriptRangeTarget4), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow5.length; __rangeIndex++) {
			let target = (__goscriptRangeWindow5.backing[__goscriptRangeWindow5.offset + __rangeIndex] as __goscript_contract.SymbolID)
			{
				let [, ok] = $.mapGet<__goscript_contract.SymbolID, __goscript_contract.Symbol, __goscript_contract.Symbol>(symbols, target, new __goscript_contract.Symbol(true))
				if (!ok) {
					add("app.call-target", (fmt.Sprintf("symbol %q calls missing AppIR symbol %q", $.namedValueInterfaceValue<any>(_symbol.ID, "compilercontract.SymbolID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID")), $.namedValueInterfaceValue<any>(target, "compilercontract.SymbolID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID"))) as string), (_symbol.Span).clone())
				}
			}
		}
	}
	if ($.sliceLen(app.Components) == 0) {
		add("app.components", "AppIR must contain at least one component", new __goscript_contract.Span(true))
	}
	let componentIDs = $.makeMap<string, boolean>([])
	let roleIDs = $.makeMap<__goscript_contract.SymbolID, boolean>([])
	let validCapabilities = $.makeMap<__goscript_contract.Capability, boolean>([["view.node", true], ["binding.value", true], ["binding.checked", true], ["effect.request-reply", true], ["numeric.safe-integer", true], ["numeric.float64", true]])
	for (let __goscriptRangeTarget8 = app.Components, __goscriptRangeWindow6 = $.sliceRange(__goscriptRangeTarget8), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow6.length; __rangeIndex++) {
		let component = ((__goscriptRangeWindow6.backing[__goscriptRangeWindow6.offset + __rangeIndex] as __goscript_contract.Component)).clone()
		let span = new __goscript_contract.Span(true)
		if (((($.stringEqual(component.ID, "")) || ($.stringEqual(component.PackagePath, ""))) || ($.stringEqual(component.StateType, ""))) || ($.stringEqual(component.MessageType, ""))) {
			add("app.component", "component requires id, packagePath, stateType, and messageType", (span).clone())
		}
		if ($.mapGet<string, boolean, boolean>(componentIDs, component.ID, false)[0]) {
			add("app.component-duplicate", (fmt.Sprintf("duplicate component ID %q", component.ID) as string), (span).clone())
		}
		$.mapSet(componentIDs, component.ID, true)
		for (let __goscriptRangeTarget6 = $.arrayToSlice<{"name": string, "id": __goscript_contract.SymbolID}>([$.anonymousStructValue({name: "Init", id: component.Init}, { kind: $.TypeKind.Struct, methods: [], fields: [/* @__PURE__ */ $.structField("name", /* @__PURE__ */ $.basicType("string"), [0], 0, false, { pkgPath: "github.com/samuelpmahan/gondola/compilercontract" }), /* @__PURE__ */ $.structField("id", /* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID"), [1], 16, false, { pkgPath: "github.com/samuelpmahan/gondola/compilercontract" })] }), $.anonymousStructValue({name: "Update", id: component.Update}, { kind: $.TypeKind.Struct, methods: [], fields: [/* @__PURE__ */ $.structField("name", /* @__PURE__ */ $.basicType("string"), [0], 0, false, { pkgPath: "github.com/samuelpmahan/gondola/compilercontract" }), /* @__PURE__ */ $.structField("id", /* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID"), [1], 16, false, { pkgPath: "github.com/samuelpmahan/gondola/compilercontract" })] }), $.anonymousStructValue({name: "View", id: component.View}, { kind: $.TypeKind.Struct, methods: [], fields: [/* @__PURE__ */ $.structField("name", /* @__PURE__ */ $.basicType("string"), [0], 0, false, { pkgPath: "github.com/samuelpmahan/gondola/compilercontract" }), /* @__PURE__ */ $.structField("id", /* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID"), [1], 16, false, { pkgPath: "github.com/samuelpmahan/gondola/compilercontract" })] })]), __goscriptRangeWindow7 = $.sliceRange(__goscriptRangeTarget6), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow7.length; __rangeIndex++) {
			let role = $.markAsStructValue($.cloneStructValue((__goscriptRangeWindow7.backing[__goscriptRangeWindow7.offset + __rangeIndex] as {"name": string, "id": __goscript_contract.SymbolID})))
			let [_symbol, ok] = $.mapGet<__goscript_contract.SymbolID, __goscript_contract.Symbol, __goscript_contract.Symbol>(symbols, role.id, new __goscript_contract.Symbol(true))
			if (!ok) {
				add("app.component-role", (fmt.Sprintf("component %q has missing %s symbol %q", component.ID, role.name, $.namedValueInterfaceValue<any>(role.id, "compilercontract.SymbolID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID"))) as string), (span).clone())
				continue
			}
			if ((!$.stringEqual(_symbol.PackagePath, component.PackagePath)) || (!$.stringEqual(_symbol.Name, role.name))) {
				add("app.component-role", (fmt.Sprintf("component %q %s role does not identify its package-level %s", component.ID, role.name, role.name) as string), (_symbol.Span).clone())
			}
			if ($.mapGet<__goscript_contract.SymbolID, boolean, boolean>(roleIDs, role.id, false)[0]) {
				add("app.component-role-duplicate", (fmt.Sprintf("symbol %q is reused as a component role", $.namedValueInterfaceValue<any>(role.id, "compilercontract.SymbolID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.SymbolID"))) as string), _symbol.Span)
			}
			$.mapSet(roleIDs, role.id, true)
		}
		let [state, stateOK] = $.mapGet<__goscript_contract.TypeID, __goscript_contract.TypeInfo, __goscript_contract.TypeInfo>(types, component.StateType, new __goscript_contract.TypeInfo(true))
		let [message, messageOK] = $.mapGet<__goscript_contract.TypeID, __goscript_contract.TypeInfo, __goscript_contract.TypeInfo>(types, component.MessageType, new __goscript_contract.TypeInfo(true))
		if (!stateOK || (!$.stringEqual(state.Kind, "struct"))) {
			add("app.state-type", (fmt.Sprintf("component %q stateType must be a declared struct", component.ID) as string), (span).clone())
		}
		if (!messageOK || (!$.stringEqual(message.Kind, "struct"))) {
			add("app.message-type", (fmt.Sprintf("component %q messageType must be a declared struct", component.ID) as string), (span).clone())
		}
		{
			let [init, ok] = $.mapGet<__goscript_contract.SymbolID, __goscript_contract.Symbol, __goscript_contract.Symbol>(symbols, component.Init, new __goscript_contract.Symbol(true))
			if (ok && (($.sliceLen(init.Signature.Params) != 0) || !equalTypes(init.Signature.Results, $.arrayToSlice<__goscript_contract.TypeID>([component.StateType])))) {
				add("app.init-signature", (fmt.Sprintf("component %q Init must be func() %s", component.ID, $.namedValueInterfaceValue<any>(component.StateType, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID"))) as string), init.Span)
			}
		}
		{
			let [update, ok] = $.mapGet<__goscript_contract.SymbolID, __goscript_contract.Symbol, __goscript_contract.Symbol>(symbols, component.Update, new __goscript_contract.Symbol(true))
			if (ok) {
				if ((((($.sliceLen(update.Signature.Params) != 2) || (!$.stringEqual($.plainSliceIndex(update.Signature.Params!, 0), component.StateType))) || (!$.stringEqual($.plainSliceIndex(update.Signature.Params!, 1), component.MessageType))) || ($.sliceLen(update.Signature.Results) != 2)) || (!$.stringEqual($.plainSliceIndex(update.Signature.Results!, 0), component.StateType))) {
					add("app.update-signature", (fmt.Sprintf("component %q Update must accept state and message and return state and effects", component.ID) as string), (update.Span).clone())
				} else {
					{
						let [effectSlice, __goscriptShadow2] = $.mapGet<__goscript_contract.TypeID, __goscript_contract.TypeInfo, __goscript_contract.TypeInfo>(types, $.plainSliceIndex(update.Signature.Results!, 1), new __goscript_contract.TypeInfo(true))
						if (!__goscriptShadow2 || (!$.stringEqual(effectSlice.Kind, "slice"))) {
							add("app.update-effects", (fmt.Sprintf("component %q Update effects result must be a slice", component.ID) as string), update.Span)
						}
					}
				}
			}
		}
		{
			let [view, ok] = $.mapGet<__goscript_contract.SymbolID, __goscript_contract.Symbol, __goscript_contract.Symbol>(symbols, component.View, new __goscript_contract.Symbol(true))
			if (ok && ((($.sliceLen(view.Signature.Params) != 1) || (!$.stringEqual($.plainSliceIndex(view.Signature.Params!, 0), component.StateType))) || ($.sliceLen(view.Signature.Results) != 1))) {
				add("app.view-signature", (fmt.Sprintf("component %q View must accept state and return one view value", component.ID) as string), view.Span)
			}
		}
		if (component.Capabilities == null) {
			add("app.capabilities", (fmt.Sprintf("component %q capabilities must be a non-null array", component.ID) as string), (span).clone())
		}
		let seen = $.makeMap<__goscript_contract.Capability, boolean>([])
		for (let __goscriptRangeTarget7 = component.Capabilities, __goscriptRangeWindow8 = $.sliceRange(__goscriptRangeTarget7), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow8.length; __rangeIndex++) {
			let capability = (__goscriptRangeWindow8.backing[__goscriptRangeWindow8.offset + __rangeIndex] as __goscript_contract.Capability)
			if (!$.mapGet<__goscript_contract.Capability, boolean, boolean>(validCapabilities, capability, false)[0]) {
				add("app.capability", (fmt.Sprintf("component %q has unknown capability %q", component.ID, $.namedValueInterfaceValue<any>(capability, "compilercontract.Capability", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.Capability"))) as string), (span).clone())
			}
			if ($.mapGet<__goscript_contract.Capability, boolean, boolean>(seen, capability, false)[0]) {
				add("app.capability-duplicate", (fmt.Sprintf("component %q repeats capability %q", component.ID, $.namedValueInterfaceValue<any>(capability, "compilercontract.Capability", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.Capability"))) as string), (span).clone())
			}
			$.mapSet(seen, capability, true)
		}
		if (!$.mapGet<__goscript_contract.Capability, boolean, boolean>(seen, "view.node", false)[0]) {
			add("app.capability-view", (fmt.Sprintf("component %q must declare view.node", component.ID) as string), span)
		}
	}
	return out
}

export function validJSRepresentation(info: __goscript_contract.TypeInfo): boolean {
	switch (info.Kind) {
		case "bool":
		case "string":
		{
			return $.stringEqual(info.JSRepresentation, "direct")
			break
		}
		case "int":
		case "uint":
		{
			if (info.Bits != 64) {
				return $.stringEqual(info.JSRepresentation, "number")
			}
			switch (info.ID) {
				case "int64":
				case "uint64":
				{
					return $.stringEqual(info.JSRepresentation, "bigint")
					break
				}
				case "int":
				case "uint":
				{
					return $.stringEqual(info.JSRepresentation, "number")
					break
				}
				default:
				{
					return ($.stringEqual(info.JSRepresentation, "number")) || ($.stringEqual(info.JSRepresentation, "bigint"))
					break
				}
			}
			break
		}
		case "float64":
		{
			return $.stringEqual(info.JSRepresentation, "number")
			break
		}
		case "struct":
		{
			return $.stringEqual(info.JSRepresentation, "class")
			break
		}
		case "array":
		{
			return $.stringEqual(info.JSRepresentation, "array")
			break
		}
		case "slice":
		{
			return (((($.stringEqual(info.JSRepresentation, "goscript-slice")) || ($.stringEqual(info.JSRepresentation, "array-or-goscript-slice"))) || ($.stringEqual(info.JSRepresentation, "float64-array-or-goscript-slice"))) || ($.stringEqual(info.JSRepresentation, "array"))) || ($.stringEqual(info.JSRepresentation, "float64-array"))
			break
		}
		default:
		{
			return false
			break
		}
	}
	throw new globalThis.Error("goscript: unreachable return")
}

export function validateSliceRepresentations(types: $.Slice<__goscript_contract.TypeInfo>): $.GoError {
	let index = $.makeMap<__goscript_contract.TypeID, __goscript_contract.TypeInfo>()
	for (let __goscriptRangeTarget9 = types, __goscriptRangeWindow9 = $.sliceRange(__goscriptRangeTarget9), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow9.length; __rangeIndex++) {
		let info = ((__goscriptRangeWindow9.backing[__goscriptRangeWindow9.offset + __rangeIndex] as __goscript_contract.TypeInfo)).clone()
		$.mapSet(index, info.ID, (info).clone())
	}
	for (let __goscriptRangeTarget10 = types, __goscriptRangeWindow10 = $.sliceRange(__goscriptRangeTarget10), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow10.length; __rangeIndex++) {
		let info = ((__goscriptRangeWindow10.backing[__goscriptRangeWindow10.offset + __rangeIndex] as __goscript_contract.TypeInfo)).clone()
		if (!$.stringEqual(info.Kind, "slice")) {
			continue
		}
		let [elem, ok] = $.mapGet<__goscript_contract.TypeID, __goscript_contract.TypeInfo, __goscript_contract.TypeInfo>(index, info.ElemType, new __goscript_contract.TypeInfo(true))
		if (!ok) {
			continue
		}
		let floatElement = $.stringEqual(elem.Kind, "float64")
		switch (info.JSRepresentation) {
			case "float64-array":
			case "float64-array-or-goscript-slice":
			{
				if (!floatElement) {
					return fmt.Errorf("slice type %q has float64 array representation but element type %q is not float64", $.namedValueInterfaceValue<any>(info.ID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), $.namedValueInterfaceValue<any>(info.ElemType, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))
				}
				break
			}
			case "array":
			case "array-or-goscript-slice":
			{
				if (floatElement) {
					return fmt.Errorf("slice type %q requires float64-array representation", $.namedValueInterfaceValue<any>(info.ID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))
				}
				break
			}
		}
	}
	return null
}

export async function ValidateTrace(trace: __goscript_trace.Trace, app: __goscript_contract.AppIR): globalThis.Promise<$.Slice<__goscript_contract.Diagnostic>> {
	let out: $.Slice<__goscript_contract.Diagnostic> = null! as $.Slice<__goscript_contract.Diagnostic>
	let add = $.functionValue((code: string, message: string, tick: bigint) => {
		out = $.appendOne(out, new __goscript_contract.Diagnostic(true, code, "error", message, new __goscript_contract.Span(true), $.arrayToSlice<__goscript_contract.Span>([])))
	}, ({ kind: $.TypeKind.Function, params: [/* @__PURE__ */ $.basicType("string"), /* @__PURE__ */ $.basicType("string"), /* @__PURE__ */ $.basicType("uint64")], results: [] } as $.FunctionTypeInfo))
	for (let __goscriptRangeTarget11 = await ValidateAppIR(app), __goscriptRangeWindow11 = $.sliceRange(__goscriptRangeTarget11), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow11.length; __rangeIndex++) {
		let diagnostic = ((__goscriptRangeWindow11.backing[__goscriptRangeWindow11.offset + __rangeIndex] as __goscript_contract.Diagnostic)).clone()
		out = $.appendOne(out, (diagnostic).clone())
	}
	if (!$.stringEqual(trace.Schema, "gobi.trace/v1")) {
		add("trace.schema", (fmt.Sprintf("schema must be %q", "gobi.trace/v1") as string), 0n)
	}
	if ($.stringEqual(trace.AppID, "")) {
		add("trace.app-id", "appId is required", 0n)
	}
	if (trace.Ticks == null) {
		add("trace.ticks", "ticks must be a non-null array", 0n)
		return out
	}
	if ($.sliceLen(trace.Ticks) == 0) {
		add("trace.empty", "trace must contain its init tick", 0n)
		return out
	}
	let component = new __goscript_contract.Component(true)
	if ($.sliceLen(app.Components) != 0) {
		component = component.__goscriptAssign($.plainSliceIndex(app.Components!, 0))
	}
	class requestKey {
		public declare dispatch: string

		public declare index: bigint

		constructor(init?: Partial<{dispatch?: string, index?: bigint}>, __goscriptValue?: boolean) {
			this.dispatch = init?.dispatch ?? ("" as string)
			this.index = init?.index ?? (0n as bigint)
			;(this as any).__goStructValue = __goscriptValue === true
		}

		public clone(): requestKey {
			return new requestKey(this, true)
		}

		public __goscriptAssign(source: requestKey): this {
			this.dispatch = source.dispatch
			this.index = source.index
			return this
		}

		static __typeInfo = $.registerStructType(
			"compilercontract.requestKey",
			() => new requestKey(),
			() => [],
			requestKey,
			() => [/* @__PURE__ */ $.structField("dispatch", /* @__PURE__ */ $.basicType("string"), [0], 0, false, { pkgPath: "github.com/samuelpmahan/gondola/compilercontract" }), /* @__PURE__ */ $.structField("index", /* @__PURE__ */ $.basicType("uint64"), [1], 16, false, { pkgPath: "github.com/samuelpmahan/gondola/compilercontract" })]
		)
	}
	let requests = $.makeMap<requestKey, __goscript_trace.EffectRequest>()
	let completed = $.makeMap<requestKey, boolean>()
	let requestOrder: $.Slice<requestKey> = $.makeSlice<requestKey>(0, undefined, undefined, () => $.markAsStructValue(new requestKey()))
	let dispatchCount = 0n
	for (let __goscriptRangeTarget16 = trace.Ticks, __goscriptRangeWindow12 = $.sliceRange(__goscriptRangeTarget16), i = 0; i < __goscriptRangeWindow12.length; i++) {
		let tick = ((__goscriptRangeWindow12.backing[__goscriptRangeWindow12.offset + i] as __goscript_trace.Tick)).clone()
		if (tick.Index != $.uint64(i)) {
			add("trace.tick-index", (fmt.Sprintf("tick at position %d has index %d", $.basicInterfaceValue(i, "int"), $.basicInterfaceValue(tick.Index, "uint64")) as string), $.uint64(i))
		}
		if (((tick.RequestedEffects == null) || (tick.CompletedEffects == null)) || (tick.View.Bindings == null)) {
			add("trace.required-arrays", (fmt.Sprintf("tick %d protocol arrays must not be null", $.basicInterfaceValue(i, "int")) as string), $.uint64(i))
		}
		if ((tick.DOM != null) && ($.pointerValue<__goscript_trace.DOMSnapshot>(tick.DOM).Controls == null)) {
			add("trace.dom-controls", (fmt.Sprintf("tick %d DOM controls must not be null", $.basicInterfaceValue(i, "int")) as string), $.uint64(i))
		}
		{
			let err = __goscript_value.ValidateValue((tick.State).clone(), app.Types)
			if (err != null) {
				add("trace.state", await fmt.Sprintf("tick %d state: %v", $.basicInterfaceValue(i, "int"), (err as any)), $.uint64(i))
			} else {
				if (!$.stringEqual(tick.State.TypeID, component.StateType)) {
					add("trace.state-type", (fmt.Sprintf("tick %d state has type %q, want %q", $.basicInterfaceValue(i, "int"), $.namedValueInterfaceValue<any>(tick.State.TypeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), $.namedValueInterfaceValue<any>(component.StateType, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID"))) as string), $.uint64(i))
				}
			}
		}
		{
			let err = await validateNode((tick.View.Tree).clone(), 0)
			if (err != null) {
				add("trace.tree", await fmt.Sprintf("tick %d tree: %v", $.basicInterfaceValue(i, "int"), (err as any)), $.uint64(i))
			}
		}
		for (let __goscriptRangeTarget12 = tick.View.Bindings, __goscriptRangeWindow13 = $.sliceRange(__goscriptRangeTarget12), j = 0; j < __goscriptRangeWindow13.length; j++) {
			let binding = ((__goscriptRangeWindow13.backing[__goscriptRangeWindow13.offset + j] as __goscript_contract.Binding)).clone()
			if ((($.stringEqual(binding.Message, "")) || ((!$.stringEqual(binding.Source, "target.value")) && (!$.stringEqual(binding.Source, "target.checked")))) || !$.mapGet<string, boolean, boolean>(supportedEvents, binding.Event, false)[0]) {
				add("trace.binding", (fmt.Sprintf("tick %d binding %d is invalid", $.basicInterfaceValue(i, "int"), $.basicInterfaceValue(j, "int")) as string), $.uint64(i))
			} else {
				{
					let err = validateBinding((tick.View).clone(), (binding).clone())
					if (err != null) {
						add("trace.binding", await fmt.Sprintf("tick %d binding %d: %v", $.basicInterfaceValue(i, "int"), $.basicInterfaceValue(j, "int"), (err as any)), $.uint64(i))
					}
				}
			}
		}
		if ((tick.DOM != null) && (!$.stringEqual($.pointerValue<__goscript_trace.DOMSnapshot>(tick.DOM).Normalization, "outerHTML-v1"))) {
			add("trace.dom-normalization", (fmt.Sprintf("tick %d has unsupported DOM normalization %q", $.basicInterfaceValue(i, "int"), $.pointerValue<__goscript_trace.DOMSnapshot>(tick.DOM).Normalization) as string), $.uint64(i))
		}
		if (tick.DOM != null) {
			for (let __goscriptRangeTarget13 = $.pointerValue<__goscript_trace.DOMSnapshot>(tick.DOM).Controls, __goscriptRangeWindow14 = $.sliceRange(__goscriptRangeTarget13), j = 0; j < __goscriptRangeWindow14.length; j++) {
				let control = ((__goscriptRangeWindow14.backing[__goscriptRangeWindow14.offset + j] as __goscript_trace.DOMControl)).clone()
				if ((($.stringEqual(control.Tag, "")) || !validUTF8String(control.Path)) || !validUTF8String(control.Value)) {
					add("trace.dom-control", (fmt.Sprintf("tick %d DOM control %d has invalid fields", $.basicInterfaceValue(i, "int"), $.basicInterfaceValue(j, "int")) as string), $.uint64(i))
				}
			}
		}
		if (i == 0) {
			if (((tick.Action != null) || (tick.Message != null)) || (tick.DispatchID != null)) {
				add("trace.init-envelope", "init tick must have null action, message, and dispatchId", 0n)
			}
		} else {
			if (tick.Action == null) {
				if ((tick.Message == null) || (tick.DispatchID == null)) {
					add("trace.reply-envelope", (fmt.Sprintf("reply tick %d must include message and dispatchId", $.basicInterfaceValue(i, "int")) as string), $.uint64(i))
				}
			} else {
				if ((tick.Message == null) != (tick.DispatchID == null)) {
					add("trace.action-envelope", (fmt.Sprintf("tick %d dispatch requires both message and dispatchId", $.basicInterfaceValue(i, "int")) as string), $.uint64(i))
				}
			}
		}
		if ((tick.Action != null) && (((!$.mapGet<string, boolean, boolean>(supportedEvents, $.pointerValue<__goscript_trace.Action>(tick.Action).Event, false)[0] || !validUTF8String($.pointerValue<__goscript_trace.Action>(tick.Action).Path)) || !validUTF8String($.pointerValue<__goscript_trace.Action>(tick.Action).Event)) || !validUTF8String($.pointerValue<__goscript_trace.Action>(tick.Action).Value))) {
			add("trace.action", (fmt.Sprintf("tick %d attempted action has invalid event or string", $.basicInterfaceValue(i, "int")) as string), $.uint64(i))
		}
		if (tick.DispatchID != null) {
			dispatchCount++
			let expected = (fmt.Sprintf("dispatch-%04d", $.basicInterfaceValue(dispatchCount, "uint64")) as string)
			if (!$.stringEqual($.pointerValue<string>(tick.DispatchID), expected)) {
				add("trace.dispatch-id", (fmt.Sprintf("tick %d has dispatchId %q, want %q", $.basicInterfaceValue(i, "int"), $.pointerValue<string>(tick.DispatchID), expected) as string), $.uint64(i))
			}
		}
		for (let __goscriptRangeTarget14 = tick.RequestedEffects, __goscriptRangeWindow15 = $.sliceRange(__goscriptRangeTarget14), j = 0; j < __goscriptRangeWindow15.length; j++) {
			let request = ((__goscriptRangeWindow15.backing[__goscriptRangeWindow15.offset + j] as __goscript_trace.EffectRequest)).clone()
			if (((tick.DispatchID == null) || (!$.stringEqual(request.DispatchID, $.pointerValue<string>(tick.DispatchID)))) || (request.EffectIndex != $.uint64(j))) {
				add("trace.effect-request-link", (fmt.Sprintf("tick %d request %d has invalid dispatch/effect index", $.basicInterfaceValue(i, "int"), $.basicInterfaceValue(j, "int")) as string), $.uint64(i))
			}
			if (((!$.stringEqual(request.Effect.Kind, "fixture.request")) || (!$.stringEqual(request.Effect.Name, "lookup"))) || (!$.stringEqual(request.Effect.Reply, "complete"))) {
				add("trace.effect-kind", (fmt.Sprintf("tick %d request %d has unsupported effect descriptor", $.basicInterfaceValue(i, "int"), $.basicInterfaceValue(j, "int")) as string), $.uint64(i))
			}
			let key = $.markAsStructValue(new requestKey({dispatch: request.DispatchID, index: request.EffectIndex}))
			if (!$.stringEqual($.mapGet<requestKey, __goscript_trace.EffectRequest, __goscript_trace.EffectRequest>(requests, key, new __goscript_trace.EffectRequest(true))[0].DispatchID, "")) {
				add("trace.effect-duplicate", (fmt.Sprintf("tick %d duplicates request %s/%d", $.basicInterfaceValue(i, "int"), request.DispatchID, $.basicInterfaceValue(request.EffectIndex, "uint64")) as string), $.uint64(i))
			} else {
				requestOrder = $.appendOne(requestOrder, $.markAsStructValue($.cloneStructValue(key)))
			}
			$.mapSet(requests, key, (request).clone())
		}
		for (let __goscriptRangeTarget15 = tick.CompletedEffects, __goscriptRangeWindow16 = $.sliceRange(__goscriptRangeTarget15), j = 0; j < __goscriptRangeWindow16.length; j++) {
			let completion = ((__goscriptRangeWindow16.backing[__goscriptRangeWindow16.offset + j] as __goscript_trace.EffectCompletion)).clone()
			let key = $.markAsStructValue(new requestKey({dispatch: completion.DispatchID, index: completion.EffectIndex}))
			let [request, ok] = $.mapGet<requestKey, __goscript_trace.EffectRequest, __goscript_trace.EffectRequest>(requests, key, new __goscript_trace.EffectRequest(true))
			if (!ok || $.mapGet<requestKey, boolean, boolean>(completed, key, false)[0]) {
				add("trace.effect-completion-link", (fmt.Sprintf("tick %d completion %d has missing or repeated request", $.basicInterfaceValue(i, "int"), $.basicInterfaceValue(j, "int")) as string), $.uint64(i))
				continue
			}
			if ((((tick.Action != null) || (tick.DispatchID == null)) || (tick.Message == null)) || (!($.pointerValue<__goscript_trace.MessageValue>(tick.Message).Name === completion.Message.Name && $.pointerValue<__goscript_trace.MessageValue>(tick.Message).Arg === completion.Message.Arg))) {
				add("trace.effect-completion-envelope", (fmt.Sprintf("tick %d completion %d does not match its delivered message", $.basicInterfaceValue(i, "int"), $.basicInterfaceValue(j, "int")) as string), $.uint64(i))
			}
			if (!$.stringEqual(request.Effect.Reply, completion.Message.Name)) {
				add("trace.effect-reply", (fmt.Sprintf("tick %d completion %d has message %q, want %q", $.basicInterfaceValue(i, "int"), $.basicInterfaceValue(j, "int"), completion.Message.Name, request.Effect.Reply) as string), $.uint64(i))
			}
			$.mapSet(completed, key, true)
		}
		if ((tick.Message != null) && ((($.stringEqual($.pointerValue<__goscript_trace.MessageValue>(tick.Message).Name, "")) || !validUTF8String($.pointerValue<__goscript_trace.MessageValue>(tick.Message).Name)) || !validUTF8String($.pointerValue<__goscript_trace.MessageValue>(tick.Message).Arg))) {
			add("trace.message", (fmt.Sprintf("tick %d has invalid message", $.basicInterfaceValue(i, "int")) as string), $.uint64(i))
		}
	}
	for (let __goscriptRangeTarget17 = requestOrder, __goscriptRangeWindow17 = $.sliceRange(__goscriptRangeTarget17), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow17.length; __rangeIndex++) {
		let key = $.markAsStructValue($.cloneStructValue((__goscriptRangeWindow17.backing[__goscriptRangeWindow17.offset + __rangeIndex] as requestKey)))
		let request = ($.mapGet<requestKey, __goscript_trace.EffectRequest, __goscript_trace.EffectRequest>(requests, key, new __goscript_trace.EffectRequest(true))[0]).clone()
		if ((!$.stringEqual(request.Effect.Reply, "")) && !$.mapGet<requestKey, boolean, boolean>(completed, key, false)[0]) {
			add("trace.effect-incomplete", (fmt.Sprintf("request %s/%d has no completion", key.dispatch, $.basicInterfaceValue(key.index, "uint64")) as string), $.uint64($.sliceLen(trace.Ticks) - 1))
		}
	}
	return out
}

export async function validateNode(node: __goscript_trace.NodeRecord, depth: number): globalThis.Promise<$.GoError> {
	if (depth > 256) {
		return fmt.Errorf("tree depth exceeds %d", $.basicInterfaceValue(256, "int"))
	}
	switch (node.Kind) {
		case gobi.Text:
		{
			if (((((!$.stringEqual(node.Tag, "")) || (!$.stringEqual(node.Key, ""))) || ($.sliceLen(node.Attrs) != 0)) || ($.sliceLen(node.On) != 0)) || ($.sliceLen(node.Kids) != 0)) {
				return fmt.Errorf("text node contains element fields")
			}
			if (!validUTF8String(node.Text)) {
				return fmt.Errorf("text node contains invalid UTF-8")
			}
			return null
			break
		}
		case gobi.Fragment:
		{
			if (((((!$.stringEqual(node.Tag, "")) || (!$.stringEqual(node.Key, ""))) || (!$.stringEqual(node.Text, ""))) || ($.sliceLen(node.Attrs) != 0)) || ($.sliceLen(node.On) != 0)) {
				return fmt.Errorf("fragment node contains non-child fields")
			}
			break
		}
		case gobi.Element:
		{
			if (!await (htmlTagPattern !== null && (htmlTagPattern as any).__isVarRef !== true && (htmlTagPattern as any).__goValue === undefined ? ((htmlTagPattern as any) as regexp.Regexp).MatchString(node.Tag) : regexp.Regexp.prototype.MatchString.call(htmlTagPattern, node.Tag)) || (!$.stringEqual(node.Text, ""))) {
				return fmt.Errorf("invalid element tag or text")
			}
			let seen = $.makeMap<string, boolean>([])
			for (let __goscriptRangeTarget19 = node.Attrs, __goscriptRangeWindow18 = $.sliceRange(__goscriptRangeTarget19), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow18.length; __rangeIndex++) {
				let attr = ((__goscriptRangeWindow18.backing[__goscriptRangeWindow18.offset + __rangeIndex] as __goscript_trace.AttrRecord)).clone()
				if ((((((!await (attrPattern !== null && (attrPattern as any).__isVarRef !== true && (attrPattern as any).__goValue === undefined ? ((attrPattern as any) as regexp.Regexp).MatchString(attr.Name) : regexp.Regexp.prototype.MatchString.call(attrPattern, attr.Name)) || strings.HasPrefix(strings.ToLower(attr.Name), "on")) || ($.stringEqual(attr.Name, "children"))) || ($.stringEqual(attr.Name, "dangerouslysetinnerhtml"))) || ($.stringEqual(attr.Name, "key"))) || ($.stringEqual(attr.Name, "ref"))) || $.mapGet<string, boolean, boolean>(seen, attr.Name, false)[0]) {
					return fmt.Errorf("invalid or duplicate attribute %q", attr.Name)
				}
				$.mapSet(seen, attr.Name, true)
				if (!validUTF8String(attr.Value)) {
					return fmt.Errorf("attribute %q contains invalid UTF-8", attr.Name)
				}
				if ((!$.stringEqual(attr.Name, "style")) && ($.sliceLen(attr.Style) != 0)) {
					return fmt.Errorf("style declarations are only valid on style attribute")
				}
				for (let __goscriptRangeTarget18 = attr.Style, __goscriptRangeWindow19 = $.sliceRange(__goscriptRangeTarget18), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow19.length; __rangeIndex++) {
					let style = ((__goscriptRangeWindow19.backing[__goscriptRangeWindow19.offset + __rangeIndex] as __goscript_trace.StyleRecord)).clone()
					if ((($.stringEqual(style.Property, "")) || !validUTF8String(style.Property)) || !validUTF8String(style.Value)) {
						return fmt.Errorf("style declaration has invalid fields")
					}
				}
				if (($.stringEqual(attr.Name, "style")) && (attr.Flag || (!$.stringEqual(attr.Value, "")))) {
					return fmt.Errorf("style attribute must use style declarations")
				}
			}
			let seenEvents = $.makeMap<string, boolean>([])
			for (let __goscriptRangeTarget20 = node.On, __goscriptRangeWindow20 = $.sliceRange(__goscriptRangeTarget20), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow20.length; __rangeIndex++) {
				let handler = ((__goscriptRangeWindow20.backing[__goscriptRangeWindow20.offset + __rangeIndex] as __goscript_trace.HandlerRecord)).clone()
				if ((((!$.mapGet<string, boolean, boolean>(supportedEvents, handler.Event, false)[0] || ($.stringEqual(handler.Message, ""))) || !validUTF8String(handler.Message)) || !validUTF8String(handler.Arg)) || $.mapGet<string, boolean, boolean>(seenEvents, handler.Event, false)[0]) {
					return fmt.Errorf("invalid or duplicate event handler %q", handler.Event)
				}
				$.mapSet(seenEvents, handler.Event, true)
			}
			break
		}
		default:
		{
			return fmt.Errorf("unsupported node kind %d", $.namedValueInterfaceValue<any>(node.Kind, "gobi.Kind", {}, /* @__PURE__ */ $.basicType("uint8", "gobi.Kind")))
			break
		}
	}
	let keys = $.makeMap<string, boolean>([])
	for (let __goscriptRangeTarget21 = node.Kids, __goscriptRangeWindow21 = $.sliceRange(__goscriptRangeTarget21), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow21.length; __rangeIndex++) {
		let kid = ((__goscriptRangeWindow21.backing[__goscriptRangeWindow21.offset + __rangeIndex] as __goscript_trace.NodeRecord)).clone()
		if ((kid.Kind == 1) && (!$.stringEqual(kid.Key, ""))) {
			if ($.mapGet<string, boolean, boolean>(keys, kid.Key, false)[0]) {
				return fmt.Errorf("duplicate sibling key %q", kid.Key)
			}
			$.mapSet(keys, kid.Key, true)
		}
		{
			let err = await validateNode((kid).clone(), depth + 1)
			if (err != null) {
				return err
			}
		}
	}
	return null
}

export function validateSpan(span: __goscript_contract.Span): $.GoError {
	if ((((((($.stringEqual(span.File, "")) || path2.IsAbs(span.File)) || strings.Contains(span.File, "\\")) || (!$.stringEqual(path2.Clean(span.File), span.File))) || strings.HasPrefix(span.File, "../")) || (span.StartByte < 0)) || (span.EndByte < span.StartByte)) {
		return fmt.Errorf("invalid source span")
	}
	return null
}

export function equalTypes(left: $.Slice<__goscript_contract.TypeID>, right: $.Slice<__goscript_contract.TypeID>): boolean {
	if ($.sliceLen(left) != $.sliceLen(right)) {
		return false
	}
	for (let __goscriptRangeTarget22 = left, __goscriptRangeWindow22 = $.sliceRange(__goscriptRangeTarget22), __goscriptSliceWindow0 = $.sliceRange(right), i = 0; i < __goscriptRangeWindow22.length; i++) {
		if (!$.stringEqual(((__goscriptRangeWindow22.backing as any[])[__goscriptRangeWindow22.offset + i] as __goscript_contract.TypeID), ((__goscriptSliceWindow0.backing as any[])[$.windowSlot(__goscriptSliceWindow0, i)] as __goscript_contract.TypeID))) {
			return false
		}
	}
	return true
}

export function validUTF8String(value: string): boolean {
	return utf8.ValidString(value)
}

export function validateBinding(view: __goscript_trace.ViewRecord, binding: __goscript_contract.Binding): $.GoError {
	let __goscriptShadow3: $.Slice<string> = null! as $.Slice<string>
	if (!$.stringEqual(binding.Path, "")) {
		__goscriptShadow3 = strings.Split(binding.Path, "/")
		for (let __goscriptRangeTarget23 = __goscriptShadow3, __goscriptRangeWindow23 = $.sliceRange(__goscriptRangeTarget23), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow23.length; __rangeIndex++) {
			let part = (__goscriptRangeWindow23.backing[__goscriptRangeWindow23.offset + __rangeIndex] as string)
			if (($.stringEqual(part, "")) || (($.stringLen(part) > 1) && ($.indexString(part, 0) == 48))) {
				return fmt.Errorf("path %q is not canonical", binding.Path)
			}
			for (let __goscriptRunes0 = $.stringRunes(part); __goscriptRunes0.next(); ) {
				const char = __goscriptRunes0.rune
				if ((char < 48) || (char > 57)) {
					return fmt.Errorf("path %q is not canonical", binding.Path)
				}
			}
		}
	}
	let node = (view.Tree).clone()
	for (let __goscriptRangeTarget24 = __goscriptShadow3, __goscriptRangeWindow24 = $.sliceRange(__goscriptRangeTarget24), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow24.length; __rangeIndex++) {
		let part = (__goscriptRangeWindow24.backing[__goscriptRangeWindow24.offset + __rangeIndex] as string)
		let [index, err] = strconv.ParseUint(part, 10, 32)
		if ((err != null) || ($.int64ToNumber(index) >= $.sliceLen(node.Kids))) {
			return fmt.Errorf("path %q is outside the view tree", binding.Path)
		}
		node = node.__goscriptAssign($.plainSliceIndex(node.Kids!, $.uint64ToNumber(index)))
	}
	if ((node.Kind != 1) || (!$.stringEqual(node.Tag, "input"))) {
		return fmt.Errorf("target at %q must be an input element", binding.Path)
	}
	let attributes = $.makeMap<string, __goscript_trace.AttrRecord>()
	for (let __goscriptRangeTarget25 = node.Attrs, __goscriptRangeWindow25 = $.sliceRange(__goscriptRangeTarget25), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow25.length; __rangeIndex++) {
		let attr = ((__goscriptRangeWindow25.backing[__goscriptRangeWindow25.offset + __rangeIndex] as __goscript_trace.AttrRecord)).clone()
		$.mapSet(attributes, attr.Name, (attr).clone())
	}
	if ($.stringEqual(binding.Source, "target.value")) {
		let [typeAttr, hasType] = $.mapGet<string, __goscript_trace.AttrRecord, __goscript_trace.AttrRecord>(attributes, "type", new __goscript_trace.AttrRecord(true))
		let [valueAttr, hasValue] = $.mapGet<string, __goscript_trace.AttrRecord, __goscript_trace.AttrRecord>(attributes, "value", new __goscript_trace.AttrRecord(true))
		if ((((((!$.stringEqual(binding.Event, "input")) || !hasType) || (!$.stringEqual(typeAttr.Value, "text"))) || typeAttr.Flag) || !hasValue) || valueAttr.Flag) {
			return fmt.Errorf("target.value requires an input type=text value and input event")
		}
	} else {
		let [typeAttr, hasType] = $.mapGet<string, __goscript_trace.AttrRecord, __goscript_trace.AttrRecord>(attributes, "type", new __goscript_trace.AttrRecord(true))
		if ((((!$.stringEqual(binding.Event, "change")) || !hasType) || (!$.stringEqual(typeAttr.Value, "checkbox"))) || typeAttr.Flag) {
			return fmt.Errorf("target.checked requires an input type=checkbox and change event")
		}
		{
			let [checked, ok] = $.mapGet<string, __goscript_trace.AttrRecord, __goscript_trace.AttrRecord>(attributes, "checked", new __goscript_trace.AttrRecord(true))
			if (ok && (!checked.Flag || (!$.stringEqual(checked.Value, "")))) {
				return fmt.Errorf("target.checked state must use a checked flag")
			}
		}
	}
	for (let __goscriptRangeTarget26 = node.On, __goscriptRangeWindow26 = $.sliceRange(__goscriptRangeTarget26), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow26.length; __rangeIndex++) {
		let handler = ((__goscriptRangeWindow26.backing[__goscriptRangeWindow26.offset + __rangeIndex] as __goscript_trace.HandlerRecord)).clone()
		if ($.stringEqual(handler.Event, binding.Event)) {
			return fmt.Errorf("binding collides with literal %q handler", binding.Event)
		}
	}
	return null
}

var __goscriptAwait: any
