// Generated file based on view.go
// Updated when compliance tests are re-run, DO NOT EDIT!

import * as $ from "@goscript/builtin/index.js"
import * as strconv from "@goscript/strconv/index.js"
import * as compilercontract from "@goscript/github.com/samuelpmahan/gondola/compilercontract/index.js"
import * as gobi from "@goscript/github.com/samuelpmahan/gondola/gobi/index.js"
import type * as __goscript_app from "./app.gs.ts"

export function View(state: __goscript_app.State): compilercontract.View {
	let input = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("input", null))).Keyed("effect-input"))).Set("type", "text"))).Set("value", state.Input))).Set("aria-label", "Request value")
	let request = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("button", $.arrayToSlice<gobi.Node>([gobi.Txt("Request")])))).Keyed("effect-request"))).Handle("click", "request", "")
	if (state.Pending || ($.stringEqual(state.Input, ""))) {
		request = request.__goscriptAssign($.markAsStructValue($.cloneStructValue(request)).Flag("disabled"))
	}
	let tree = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("div", $.arrayToSlice<gobi.Node>([input, request, gobi.El("p", $.arrayToSlice<gobi.Node>([gobi.Txt("Status: "), gobi.Txt(state.Status)])), gobi.El("p", $.arrayToSlice<gobi.Node>([gobi.Txt("Value: "), gobi.Txt(state.Value)])), gobi.El("p", $.arrayToSlice<gobi.Node>([gobi.Txt("Requests: "), gobi.Txt(strconv.Itoa(state.Requests))])), gobi.El("p", $.arrayToSlice<gobi.Node>([gobi.Txt("Completions: "), gobi.Txt(strconv.Itoa(state.Completions))]))])))).Keyed("effect"))).Set("class", "compiled-effect")
	return compilercontract.NewView(tree, $.arrayToSlice<compilercontract.Binding>([new compilercontract.Binding(true, "0", "input", "edit", compilercontract.TargetValue)]))
}
