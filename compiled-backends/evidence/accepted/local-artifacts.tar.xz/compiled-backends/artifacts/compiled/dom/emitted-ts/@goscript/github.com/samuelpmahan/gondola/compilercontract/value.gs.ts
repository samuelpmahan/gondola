// Generated file based on value.go
// Updated when compliance tests are re-run, DO NOT EDIT!

import * as $ from "@goscript/builtin/index.js"
import * as bytes from "@goscript/bytes/index.js"
import * as hex from "@goscript/encoding/hex/index.js"
import * as json from "@goscript/encoding/json/index.js"
import * as fmt from "@goscript/fmt/index.js"
import * as io from "@goscript/io/index.js"
import * as math from "@goscript/math/index.js"
import * as reflect from "@goscript/reflect/index.js"
import * as strconv from "@goscript/strconv/index.js"
import * as strings from "@goscript/strings/index.js"
import * as utf8 from "@goscript/unicode/utf8/index.js"
import * as __goscript_contract from "./contract.gs.ts"
import * as __goscript_json from "./json.gs.ts"
import "@goscript/io/index.js"

$.registerTypePackagePath("github.com/samuelpmahan/gondola/compilercontract", ["compilercontract.Value", "compilercontract.FieldValue"])

export class Value {
	public declare TypeID: __goscript_contract.TypeID

	public declare Kind: __goscript_contract.TypeKind

	public declare Bool: $.VarRef<boolean> | null

	public declare String: $.VarRef<string> | null

	public declare Integer: $.VarRef<string> | null

	public declare Float64Bits: $.VarRef<string> | null

	public declare IsNil: $.VarRef<boolean> | null

	public declare Items: $.VarRef<$.Slice<Value>> | null

	public declare Fields: $.VarRef<$.Slice<FieldValue>> | null

	constructor(__goscriptValue?: boolean, TypeID$?: __goscript_contract.TypeID, Kind$?: __goscript_contract.TypeKind, Bool$?: $.VarRef<boolean> | null, String$?: $.VarRef<string> | null, Integer$?: $.VarRef<string> | null, Float64Bits$?: $.VarRef<string> | null, IsNil$?: $.VarRef<boolean> | null, Items$?: $.VarRef<$.Slice<Value>> | null, Fields$?: $.VarRef<$.Slice<FieldValue>> | null) {
		this.TypeID = TypeID$ ?? ""
		this.Kind = Kind$ ?? ""
		this.Bool = Bool$ ?? (null! as $.VarRef<boolean> | null)
		this.String = String$ ?? (null! as $.VarRef<string> | null)
		this.Integer = Integer$ ?? (null! as $.VarRef<string> | null)
		this.Float64Bits = Float64Bits$ ?? (null! as $.VarRef<string> | null)
		this.IsNil = IsNil$ ?? (null! as $.VarRef<boolean> | null)
		this.Items = Items$ ?? (null! as $.VarRef<$.Slice<Value>> | null)
		this.Fields = Fields$ ?? (null! as $.VarRef<$.Slice<FieldValue>> | null)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): Value {
		return new Value(true, this.TypeID, this.Kind, this.Bool, this.String, this.Integer, this.Float64Bits, this.IsNil, this.Items, this.Fields)
	}

	public __goscriptAssign(source: Value): this {
		this.TypeID = source.TypeID
		this.Kind = source.Kind
		this.Bool = source.Bool
		this.String = source.String
		this.Integer = source.Integer
		this.Float64Bits = source.Float64Bits
		this.IsNil = source.IsNil
		this.Items = source.Items
		this.Fields = source.Fields
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.Value",
		() => new Value(),
		() => [],
		Value,
		() => [/* @__PURE__ */ $.structField("TypeID", /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID"), [0], 0, true, { tag: "json:\"typeId\"" }), /* @__PURE__ */ $.structField("Kind", /* @__PURE__ */ $.basicType("string", "compilercontract.TypeKind"), [1], 16, true, { tag: "json:\"kind\"" }), /* @__PURE__ */ $.structField("Bool", /* @__PURE__ */ $.pointerType(/* @__PURE__ */ $.basicType("bool")), [2], 32, true, { tag: "json:\"bool,omitempty\"" }), /* @__PURE__ */ $.structField("String", /* @__PURE__ */ $.pointerType(/* @__PURE__ */ $.basicType("string")), [3], 40, true, { tag: "json:\"string,omitempty\"" }), /* @__PURE__ */ $.structField("Integer", /* @__PURE__ */ $.pointerType(/* @__PURE__ */ $.basicType("string")), [4], 48, true, { tag: "json:\"integer,omitempty\"" }), /* @__PURE__ */ $.structField("Float64Bits", /* @__PURE__ */ $.pointerType(/* @__PURE__ */ $.basicType("string")), [5], 56, true, { tag: "json:\"float64Bits,omitempty\"" }), /* @__PURE__ */ $.structField("IsNil", /* @__PURE__ */ $.pointerType(/* @__PURE__ */ $.basicType("bool")), [6], 64, true, { tag: "json:\"isNil,omitempty\"" }), /* @__PURE__ */ $.structField("Items", /* @__PURE__ */ $.pointerType(/* @__PURE__ */ $.sliceType("compilercontract.Value")), [7], 72, true, { tag: "json:\"items,omitempty\"" }), /* @__PURE__ */ $.structField("Fields", /* @__PURE__ */ $.pointerType(/* @__PURE__ */ $.sliceType("compilercontract.FieldValue")), [8], 80, true, { tag: "json:\"fields,omitempty\"" })]
	)
}

export class FieldValue {
	public declare Name: string

	public declare Value: Value

	constructor(__goscriptValue?: boolean, Name$?: string, Value$?: Value) {
		this.Name = Name$ ?? ""
		this.Value = Value$ ?? new Value(true)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): FieldValue {
		return new FieldValue(true, this.Name, this.Value.clone())
	}

	public __goscriptAssign(source: FieldValue): this {
		this.Name = source.Name
		this.Value.__goscriptAssign(source.Value)
		return this
	}

	static __typeInfo = $.registerStructType(
		"compilercontract.FieldValue",
		() => new FieldValue(),
		() => [],
		FieldValue,
		() => [/* @__PURE__ */ $.structField("Name", /* @__PURE__ */ $.basicType("string"), [0], 0, true, { tag: "json:\"name\"" }), /* @__PURE__ */ $.structField("Value", "compilercontract.Value", [1], 16, true, { tag: "json:\"value\"" })]
	)
}

export const maxValueDepth: number = 256

export const maxSafeNumberInteger: bigint = 9007199254740991n

export async function EncodeValue(value: any, typeID: __goscript_contract.TypeID, types: $.Slice<__goscript_contract.TypeInfo>): globalThis.Promise<[Value, $.GoError]> {
	let __goscriptTuple0: any = indexTypes(types)
	let typeMap: globalThis.Map<__goscript_contract.TypeID, __goscript_contract.TypeInfo> | null = __goscriptTuple0[0]
	let err: $.GoError = __goscriptTuple0[1]
	if (err != null) {
		return [new Value(true), err]
	}
	let __goscriptTuple1: any = await encodeReflect(reflect.ValueOf(value), typeID, typeMap, 0)
	let result: Value = __goscriptTuple1[0]
	err = __goscriptTuple1[1]
	if (err != null) {
		return [new Value(true), err]
	}
	{
		let __goscriptShadow0 = ValidateValue(result, types)
		if (__goscriptShadow0 != null) {
			return [new Value(true), __goscriptShadow0]
		}
	}
	return [result, null]
}

export async function encodeReflect(value: reflect.Value, typeID: __goscript_contract.TypeID, types: globalThis.Map<__goscript_contract.TypeID, __goscript_contract.TypeInfo> | null, depth: number): globalThis.Promise<[Value, $.GoError]> {
	if (depth > 256) {
		return [new Value(true), fmt.Errorf("value nesting exceeds %d", $.basicInterfaceValue(256, "int"))]
	}
	let [info, ok] = $.mapGet<__goscript_contract.TypeID, __goscript_contract.TypeInfo, __goscript_contract.TypeInfo>(types, typeID, new __goscript_contract.TypeInfo(true))
	if (!ok) {
		return [new Value(true), fmt.Errorf("unknown typeId %q", $.namedValueInterfaceValue<any>(typeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))]
	}
	if (!value.IsValid()) {
		return [new Value(true), fmt.Errorf("invalid Go value for type %q", $.namedValueInterfaceValue<any>(typeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))]
	}
	let out = new Value(true, typeID, info.Kind)
	switch (info.Kind) {
		case "bool":
		{
			if (value.Kind() != 1) {
				return [new Value(true), typeMismatch(typeID, value)]
			}
			let v = $.varRef(value.Bool())
			out.Bool = v
			break
		}
		case "string":
		{
			if (value.Kind() != 24) {
				return [new Value(true), typeMismatch(typeID, value)]
			}
			let v = $.varRef(value.String())
			if (!utf8.ValidString(v.value)) {
				return [new Value(true), fmt.Errorf("string value for type %q is not valid UTF-8", $.namedValueInterfaceValue<any>(typeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))]
			}
			out.String = v
			break
		}
		case "int":
		{
			if (((value.Kind() < 2) || (value.Kind() > 6)) || ($.uint((__goscriptAwait = $.pointerValue<Exclude<reflect.Type, null>>(value.Type()).Bits(), __goscriptAwait instanceof Promise ? await __goscriptAwait : __goscriptAwait), 8) != info.Bits)) {
				return [new Value(true), typeMismatch(typeID, value)]
			}
			let n = value.Int()
			let v = $.varRef(strconv.FormatInt(n, 10))
			out.Integer = v
			break
		}
		case "uint":
		{
			if (((value.Kind() < 7) || (value.Kind() > 11)) || ($.uint((__goscriptAwait = $.pointerValue<Exclude<reflect.Type, null>>(value.Type()).Bits(), __goscriptAwait instanceof Promise ? await __goscriptAwait : __goscriptAwait), 8) != info.Bits)) {
				return [new Value(true), typeMismatch(typeID, value)]
			}
			let n = value.Uint()
			let v = $.varRef(strconv.FormatUint(n, 10))
			out.Integer = v
			break
		}
		case "float64":
		{
			if (value.Kind() != 14) {
				return [new Value(true), typeMismatch(typeID, value)]
			}
			let f = value.Float()
			if (math.IsNaN(f) || math.IsInf(f, 0)) {
				return [new Value(true), fmt.Errorf("non-finite float64 value is unsupported")]
			}
			let v = $.varRef((fmt.Sprintf("%016x", $.basicInterfaceValue(math.Float64bits(f), "uint64")) as string))
			out.Float64Bits = v
			break
		}
		case "slice":
		case "array":
		{
			if (($.stringEqual(info.Kind, "slice")) && (value.Kind() != 23)) {
				return [new Value(true), typeMismatch(typeID, value)]
			}
			if (($.stringEqual(info.Kind, "array")) && (value.Kind() != 17)) {
				return [new Value(true), typeMismatch(typeID, value)]
			}
			if (($.stringEqual(info.Kind, "array")) && ((info.Length == null) || (value.Len() != $.pointerValue<number>(info.Length)))) {
				return [new Value(true), fmt.Errorf("array length does not match type %q", $.namedValueInterfaceValue<any>(typeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))]
			}
			let isNil = $.varRef(false)
			if ($.stringEqual(info.Kind, "slice")) {
				isNil.value = value.IsNil()
				out.IsNil = isNil
			}
			let items: $.VarRef<$.Slice<Value>> = $.varRef($.makeSlice<Value>(value.Len(), undefined, undefined, () => new Value(true)))
			for (let i = 0; i < value.Len(); i++) {
				let [item, err] = await encodeReflect(value.Index(i), info.ElemType, types, depth + 1)
				if (err != null) {
					return [new Value(true), fmt.Errorf("%s[%d]: %w", $.namedValueInterfaceValue<any>(typeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), $.basicInterfaceValue(i, "int"), (err as any))]
				}
				$.sliceElems(items.value!)[$.sliceSlot(items.value!, i)].__goscriptAssign(item)
			}
			out.Items = items
			break
		}
		case "struct":
		{
			if (value.Kind() != 25) {
				return [new Value(true), typeMismatch(typeID, value)]
			}
			if ($.sliceLen(info.Fields) == 0) {
				return [new Value(true), fmt.Errorf("empty structs are unsupported for type %q", $.namedValueInterfaceValue<any>(typeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))]
			}
			if (value.NumField() != $.sliceLen(info.Fields)) {
				return [new Value(true), fmt.Errorf("struct %q has %d Go fields, type metadata declares %d", $.namedValueInterfaceValue<any>(typeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), $.basicInterfaceValue(value.NumField(), "int"), $.basicInterfaceValue($.sliceLen(info.Fields), "int"))]
			}
			let fields: $.VarRef<$.Slice<FieldValue>> = $.varRef($.makeSlice<FieldValue>($.sliceLen(info.Fields), undefined, undefined, () => new FieldValue(true)))
			for (let __goscriptRangeTarget0 = info.Fields, __goscriptRangeWindow0 = $.sliceRange(__goscriptRangeTarget0), i = 0; i < __goscriptRangeWindow0.length; i++) {
				let field = ((__goscriptRangeWindow0.backing[__goscriptRangeWindow0.offset + i] as __goscript_contract.TypeField)).clone()
				let goField = $.markAsStructValue($.cloneStructValue(((__goscriptAwait = $.pointerValue<Exclude<reflect.Type, null>>(value.Type()).Field(i), __goscriptAwait instanceof Promise ? await __goscriptAwait : __goscriptAwait) as reflect.StructField)))
				if (!$.stringEqual(goField.Name, field.Name)) {
					return [new Value(true), fmt.Errorf("struct %q field %d is %q, metadata declares %q", $.namedValueInterfaceValue<any>(typeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), $.basicInterfaceValue(i, "int"), goField.Name, field.Name)]
				}
				if (!value.Field(i).CanInterface()) {
					return [new Value(true), fmt.Errorf("struct %q field %q is not exported", $.namedValueInterfaceValue<any>(typeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), field.Name)]
				}
				let [encoded, err] = await encodeReflect(value.Field(i), field.Type, types, depth + 1)
				if (err != null) {
					return [new Value(true), fmt.Errorf("%s.%s: %w", $.namedValueInterfaceValue<any>(typeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), field.Name, (err as any))]
				}
				$.sliceElems(fields.value!)[$.sliceSlot(fields.value!, i)].__goscriptAssign(new FieldValue(true, field.Name, encoded))
			}
			out.Fields = fields
			break
		}
		default:
		{
			return [new Value(true), fmt.Errorf("unsupported kind %q for type %q", $.namedValueInterfaceValue<any>(info.Kind, "compilercontract.TypeKind", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeKind")), $.namedValueInterfaceValue<any>(typeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))]
			break
		}
	}
	return [out, null]
}

export function typeMismatch(typeID: __goscript_contract.TypeID, value: reflect.Value): $.GoError {
	return fmt.Errorf("Go value %s does not match type %q", (value.Type() as any), $.namedValueInterfaceValue<any>(typeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))
}

export async function DecodeValueJSON(data: $.Slice<number>, types: $.Slice<__goscript_contract.TypeInfo>): globalThis.Promise<[Value, $.GoError]> {
	{
		let err = __goscript_json.validateJSONUnicode(data)
		if (err != null) {
			return [new Value(true), err]
		}
	}
	let decoder = json.NewDecoder($.pointerValueOrNil($.interfaceValue<io.Reader | null>(bytes.NewReader(data), "*bytes.Reader", __goscriptStatic0()))!)
	void (decoder !== null && (decoder as any).__isVarRef !== true && (decoder as any).__goValue === undefined ? ((decoder as any) as json.Decoder).DisallowUnknownFields() : json.Decoder.prototype.DisallowUnknownFields.call($.pointerValue<json.Decoder>(decoder)))
	let value: $.VarRef<Value> = $.varRef(new Value(true))
	{
		let err = await (decoder !== null && (decoder as any).__isVarRef !== true && (decoder as any).__goValue === undefined ? ((decoder as any) as json.Decoder).Decode($.interfaceValue(value, "*compilercontract.Value", /* @__PURE__ */ $.pointerType("compilercontract.Value"))) : json.Decoder.prototype.Decode.call($.pointerValue<json.Decoder>(decoder), $.interfaceValue(value, "*compilercontract.Value", /* @__PURE__ */ $.pointerType("compilercontract.Value"))))
		if (err != null) {
			return [new Value(true), err]
		}
	}
	let extra: $.VarRef<any> = $.varRef(null! as any)
	{
		let err = await (decoder !== null && (decoder as any).__isVarRef !== true && (decoder as any).__goValue === undefined ? ((decoder as any) as json.Decoder).Decode($.interfaceValue(extra, "*interface{}", /* @__PURE__ */ $.pointerType({ kind: $.TypeKind.Interface, methods: [] }))) : json.Decoder.prototype.Decode.call($.pointerValue<json.Decoder>(decoder), $.interfaceValue(extra, "*interface{}", /* @__PURE__ */ $.pointerType({ kind: $.TypeKind.Interface, methods: [] }))))
		if (!$.comparableEqual(err, io.EOF)) {
			if (err == null) {
				return [new Value(true), fmt.Errorf("trailing JSON value")]
			}
			return [new Value(true), err]
		}
	}
	{
		let err = ValidateValue((value.value).clone(), types)
		if (err != null) {
			return [new Value(true), err]
		}
	}
	return [(value.value).clone(), null]
}

export function ValidateValue(value: Value, types: $.Slice<__goscript_contract.TypeInfo>): $.GoError {
	let __goscriptTuple2: any = indexTypes(types)
	let typeMap: globalThis.Map<__goscript_contract.TypeID, __goscript_contract.TypeInfo> | null = __goscriptTuple2[0]
	let err: $.GoError = __goscriptTuple2[1]
	if (err != null) {
		return err
	}
	return validateValue(value, typeMap, 0)
}

export function validateValue(value: Value, types: globalThis.Map<__goscript_contract.TypeID, __goscript_contract.TypeInfo> | null, depth: number): $.GoError {
	if (depth > 256) {
		return fmt.Errorf("value nesting exceeds %d", $.basicInterfaceValue(256, "int"))
	}
	let [info, ok] = $.mapGet<__goscript_contract.TypeID, __goscript_contract.TypeInfo, __goscript_contract.TypeInfo>(types, value.TypeID, new __goscript_contract.TypeInfo(true))
	if (!ok) {
		return fmt.Errorf("unknown typeId %q", $.namedValueInterfaceValue<any>(value.TypeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))
	}
	if (!$.stringEqual(value.Kind, info.Kind)) {
		return fmt.Errorf("value kind %q does not match type %q kind %q", $.namedValueInterfaceValue<any>(value.Kind, "compilercontract.TypeKind", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeKind")), $.namedValueInterfaceValue<any>(value.TypeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), $.namedValueInterfaceValue<any>(info.Kind, "compilercontract.TypeKind", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeKind")))
	}
	let payloads = 0
	if (value.Bool != null) {
		payloads++
	}
	if (value.String != null) {
		payloads++
	}
	if (value.Integer != null) {
		payloads++
	}
	if (value.Float64Bits != null) {
		payloads++
	}
	if (value.Items != null) {
		payloads++
	}
	if (value.Fields != null) {
		payloads++
	}
	if ((value.IsNil != null) && (!$.stringEqual(info.Kind, "slice"))) {
		return fmt.Errorf("isNil is only valid for slices")
	}
	switch (info.Kind) {
		case "bool":
		{
			if ((payloads != 1) || (value.Bool == null)) {
				return fmt.Errorf("bool value must contain only bool payload")
			}
			break
		}
		case "string":
		{
			if ((payloads != 1) || (value.String == null)) {
				return fmt.Errorf("string value must contain only string payload")
			}
			if (!utf8.ValidString($.pointerValue<string>(value.String))) {
				return fmt.Errorf("string payload is not valid UTF-8")
			}
			break
		}
		case "int":
		case "uint":
		{
			if ((payloads != 1) || (value.Integer == null)) {
				return fmt.Errorf("integer value must contain only integer payload")
			}
			{
				let err = validateInteger($.pointerValue<string>(value.Integer), info)
				if (err != null) {
					return err
				}
			}
			break
		}
		case "float64":
		{
			if ((payloads != 1) || (value.Float64Bits == null)) {
				return fmt.Errorf("float64 value must contain only float64Bits payload")
			}
			{
				let err = validateFloatBits($.pointerValue<string>(value.Float64Bits))
				if (err != null) {
					return err
				}
			}
			break
		}
		case "slice":
		case "array":
		{
			if ((payloads != 1) || (value.Items == null)) {
				return fmt.Errorf("slice or array value must contain only items payload")
			}
			if (($.stringEqual(info.Kind, "slice")) && (value.IsNil == null)) {
				return fmt.Errorf("slice value must include isNil")
			}
			if (($.stringEqual(info.Kind, "array")) && (value.IsNil != null)) {
				return fmt.Errorf("array value cannot include isNil")
			}
			if ((($.stringEqual(info.Kind, "slice")) && $.pointerValue<boolean>(value.IsNil)) && ($.sliceLen($.pointerValue<$.Slice<Value>>(value.Items)) != 0)) {
				return fmt.Errorf("nil slice must have no items")
			}
			if (($.stringEqual(info.Kind, "array")) && ((info.Length == null) || ($.sliceLen($.pointerValue<$.Slice<Value>>(value.Items)) != $.pointerValue<number>(info.Length)))) {
				return fmt.Errorf("array length does not match type %q", $.namedValueInterfaceValue<any>(value.TypeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))
			}
			for (let __goscriptRangeTarget1 = $.pointerValue<$.Slice<Value>>(value.Items), __goscriptRangeWindow1 = $.sliceRange(__goscriptRangeTarget1), i = 0; i < __goscriptRangeWindow1.length; i++) {
				let item = ((__goscriptRangeWindow1.backing[__goscriptRangeWindow1.offset + i] as Value)).clone()
				{
					let err = validateValue((item).clone(), types, depth + 1)
					if (err != null) {
						return fmt.Errorf("%s[%d]: %w", $.namedValueInterfaceValue<any>(value.TypeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), $.basicInterfaceValue(i, "int"), (err as any))
					}
				}
				if (!$.stringEqual(item.TypeID, info.ElemType)) {
					return fmt.Errorf("%s[%d] has type %q, want %q", $.namedValueInterfaceValue<any>(value.TypeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), $.basicInterfaceValue(i, "int"), $.namedValueInterfaceValue<any>(item.TypeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), $.namedValueInterfaceValue<any>(info.ElemType, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))
				}
			}
			break
		}
		case "struct":
		{
			if ((payloads != 1) || (value.Fields == null)) {
				return fmt.Errorf("struct value must contain only fields payload")
			}
			if ($.sliceLen($.pointerValue<$.Slice<FieldValue>>(value.Fields)) != $.sliceLen(info.Fields)) {
				return fmt.Errorf("struct %q has %d values, want %d", $.namedValueInterfaceValue<any>(value.TypeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), $.basicInterfaceValue($.sliceLen($.pointerValue<$.Slice<FieldValue>>(value.Fields)), "int"), $.basicInterfaceValue($.sliceLen(info.Fields), "int"))
			}
			for (let __goscriptRangeTarget2 = info.Fields, __goscriptRangeWindow2 = $.sliceRange(__goscriptRangeTarget2), i = 0; i < __goscriptRangeWindow2.length; i++) {
				let field = ((__goscriptRangeWindow2.backing[__goscriptRangeWindow2.offset + i] as __goscript_contract.TypeField)).clone()
				let got = ($.plainSliceIndex(($.pointerValue<$.Slice<FieldValue>>(value.Fields))!, i)).clone()
				if (!$.stringEqual(got.Name, field.Name)) {
					return fmt.Errorf("struct %q field %d is %q, want %q", $.namedValueInterfaceValue<any>(value.TypeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), $.basicInterfaceValue(i, "int"), got.Name, field.Name)
				}
				{
					let err = validateValue(got.Value, types, depth + 1)
					if (err != null) {
						return fmt.Errorf("%s.%s: %w", $.namedValueInterfaceValue<any>(value.TypeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), field.Name, (err as any))
					}
				}
				if (!$.stringEqual(got.Value.TypeID, field.Type)) {
					return fmt.Errorf("%s.%s has type %q, want %q", $.namedValueInterfaceValue<any>(value.TypeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), field.Name, $.namedValueInterfaceValue<any>(got.Value.TypeID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), $.namedValueInterfaceValue<any>(field.Type, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))
				}
			}
			break
		}
		default:
		{
			return fmt.Errorf("unsupported type kind %q", $.namedValueInterfaceValue<any>(info.Kind, "compilercontract.TypeKind", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeKind")))
			break
		}
	}
	return null
}

export function validateInteger(text: string, info: __goscript_contract.TypeInfo): $.GoError {
	if ((((info.Bits != 8) && (info.Bits != 16)) && (info.Bits != 32)) && (info.Bits != 64)) {
		return fmt.Errorf("invalid integer bit width %d", $.basicInterfaceValue(info.Bits, "uint8"))
	}
	if ($.stringEqual(info.Kind, "int")) {
		let [n, err] = strconv.ParseInt(text, 10, info.Bits)
		if (err != null) {
			return fmt.Errorf("invalid %d-bit integer %q: %w", $.basicInterfaceValue(info.Bits, "uint8"), text, (err as any))
		}
		if (!$.stringEqual(strconv.FormatInt(n, 10), text)) {
			return fmt.Errorf("integer %q is not canonical decimal", text)
		}
		if (($.stringEqual(info.JSRepresentation, "number")) && ((n > 9007199254740991n) || (n < -9007199254740991n))) {
			return fmt.Errorf("integer %q is outside the safe Number range for type %q", text, $.namedValueInterfaceValue<any>(info.ID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))
		}
	} else {
		let [n, err] = strconv.ParseUint(text, 10, info.Bits)
		if (err != null) {
			return fmt.Errorf("invalid %d-bit unsigned integer %q: %w", $.basicInterfaceValue(info.Bits, "uint8"), text, (err as any))
		}
		if (!$.stringEqual(strconv.FormatUint(n, 10), text)) {
			return fmt.Errorf("integer %q is not canonical decimal", text)
		}
		if (($.stringEqual(info.JSRepresentation, "number")) && (n > 9007199254740991n)) {
			return fmt.Errorf("integer %q is outside the safe Number range for type %q", text, $.namedValueInterfaceValue<any>(info.ID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))
		}
	}
	if ((!$.stringEqual(info.JSRepresentation, "number")) && (!$.stringEqual(info.JSRepresentation, "bigint"))) {
		return fmt.Errorf("integer type %q has unsupported JavaScript representation %q", $.namedValueInterfaceValue<any>(info.ID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), $.namedValueInterfaceValue<any>(info.JSRepresentation, "compilercontract.JSRepresentation", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.JSRepresentation")))
	}
	return null
}

export function validateFloatBits(text: string): $.GoError {
	if (($.stringLen(text) != 16) || (!$.stringEqual(strings.ToLower(text), text))) {
		return fmt.Errorf("float64Bits must be 16 lowercase hexadecimal digits")
	}
	let __goscriptTuple3: any = hex.DecodeString(text)
	let raw: $.Slice<number> = __goscriptTuple3[0]
	let err: $.GoError = __goscriptTuple3[1]
	if (err != null) {
		return fmt.Errorf("invalid float64Bits: %w", (err as any))
	}
	let bits = 0n
	for (let __goscriptRangeTarget3 = raw, __goscriptRangeWindow3 = $.sliceRange(__goscriptRangeTarget3), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow3.length; __rangeIndex++) {
		let b = $.uint((__goscriptRangeWindow3.backing[__goscriptRangeWindow3.offset + __rangeIndex] as number), 8)
		bits = $.uint64Or(($.uint64Shl(bits, 8)), $.uint64(b))
	}
	let f = math.Float64frombits(bits)
	if (math.IsNaN(f) || math.IsInf(f, 0)) {
		return fmt.Errorf("non-finite float64 is unsupported")
	}
	return null
}

export function indexTypes(types: $.Slice<__goscript_contract.TypeInfo>): [globalThis.Map<__goscript_contract.TypeID, __goscript_contract.TypeInfo> | null, $.GoError] {
	let index = $.makeMap<__goscript_contract.TypeID, __goscript_contract.TypeInfo>()
	for (let __goscriptRangeTarget4 = types, __goscriptRangeWindow4 = $.sliceRange(__goscriptRangeTarget4), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow4.length; __rangeIndex++) {
		let info = ((__goscriptRangeWindow4.backing[__goscriptRangeWindow4.offset + __rangeIndex] as __goscript_contract.TypeInfo)).clone()
		if ($.stringEqual(info.ID, "")) {
			return [null, fmt.Errorf("typeId is empty")]
		}
		{
			let [, exists] = $.mapGet<__goscript_contract.TypeID, __goscript_contract.TypeInfo, __goscript_contract.TypeInfo>(index, info.ID, new __goscript_contract.TypeInfo(true))
			if (exists) {
				return [null, fmt.Errorf("duplicate typeId %q", $.namedValueInterfaceValue<any>(info.ID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))]
			}
		}
		$.mapSet(index, info.ID, (info).clone())
	}
	for (let __goscriptRangeTarget6 = types, __goscriptRangeWindow5 = $.sliceRange(__goscriptRangeTarget6), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow5.length; __rangeIndex++) {
		let info = ((__goscriptRangeWindow5.backing[__goscriptRangeWindow5.offset + __rangeIndex] as __goscript_contract.TypeInfo)).clone()
		switch (info.Kind) {
			case "bool":
			case "string":
			case "float64":
			{
				if ((((info.Bits != 0) || (!$.stringEqual(info.ElemType, ""))) || (info.Length != null)) || ($.sliceLen(info.Fields) != 0)) {
					return [null, fmt.Errorf("type %q has fields unused by kind %q", $.namedValueInterfaceValue<any>(info.ID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), $.namedValueInterfaceValue<any>(info.Kind, "compilercontract.TypeKind", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeKind")))]
				}
				break
			}
			case "int":
			case "uint":
			{
				if ((((info.Bits != 8) && (info.Bits != 16)) && (info.Bits != 32)) && (info.Bits != 64)) {
					return [null, fmt.Errorf("type %q has invalid integer bits %d", $.namedValueInterfaceValue<any>(info.ID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), $.basicInterfaceValue(info.Bits, "uint8"))]
				}
				if (((!$.stringEqual(info.ElemType, "")) || (info.Length != null)) || ($.sliceLen(info.Fields) != 0)) {
					return [null, fmt.Errorf("integer type %q has unrelated metadata", $.namedValueInterfaceValue<any>(info.ID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))]
				}
				break
			}
			case "slice":
			case "array":
			{
				if ($.stringEqual(info.ElemType, "")) {
					return [null, fmt.Errorf("type %q is missing elemType", $.namedValueInterfaceValue<any>(info.ID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))]
				}
				{
					let [, ok] = $.mapGet<__goscript_contract.TypeID, __goscript_contract.TypeInfo, __goscript_contract.TypeInfo>(index, info.ElemType, new __goscript_contract.TypeInfo(true))
					if (!ok) {
						return [null, fmt.Errorf("type %q refers to unknown element type %q", $.namedValueInterfaceValue<any>(info.ID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), $.namedValueInterfaceValue<any>(info.ElemType, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))]
					}
				}
				if (($.stringEqual(info.Kind, "array")) && ((info.Length == null) || ($.pointerValue<number>(info.Length) < 0))) {
					return [null, fmt.Errorf("array type %q has invalid length", $.namedValueInterfaceValue<any>(info.ID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))]
				}
				if (($.stringEqual(info.Kind, "slice")) && (info.Length != null)) {
					return [null, fmt.Errorf("slice type %q cannot declare length", $.namedValueInterfaceValue<any>(info.ID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))]
				}
				if ((info.Bits != 0) || ($.sliceLen(info.Fields) != 0)) {
					return [null, fmt.Errorf("sequence type %q has unrelated metadata", $.namedValueInterfaceValue<any>(info.ID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))]
				}
				break
			}
			case "struct":
			{
				if (((info.Bits != 0) || (!$.stringEqual(info.ElemType, ""))) || (info.Length != null)) {
					return [null, fmt.Errorf("struct type %q has unrelated metadata", $.namedValueInterfaceValue<any>(info.ID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))]
				}
				if ($.sliceLen(info.Fields) == 0) {
					return [null, fmt.Errorf("empty structs are unsupported for type %q", $.namedValueInterfaceValue<any>(info.ID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))]
				}
				let seen = $.makeMap<string, boolean>([])
				for (let __goscriptRangeTarget5 = info.Fields, __goscriptRangeWindow6 = $.sliceRange(__goscriptRangeTarget5), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow6.length; __rangeIndex++) {
					let field = ((__goscriptRangeWindow6.backing[__goscriptRangeWindow6.offset + __rangeIndex] as __goscript_contract.TypeField)).clone()
					if (($.stringEqual(field.Name, "")) || $.mapGet<string, boolean, boolean>(seen, field.Name, false)[0]) {
						return [null, fmt.Errorf("struct type %q has empty or duplicate field %q", $.namedValueInterfaceValue<any>(info.ID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), field.Name)]
					}
					$.mapSet(seen, field.Name, true)
					{
						let [, ok] = $.mapGet<__goscript_contract.TypeID, __goscript_contract.TypeInfo, __goscript_contract.TypeInfo>(index, field.Type, new __goscript_contract.TypeInfo(true))
						if (!ok) {
							return [null, fmt.Errorf("struct type %q field %q refers to unknown type %q", $.namedValueInterfaceValue<any>(info.ID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")), field.Name, $.namedValueInterfaceValue<any>(field.Type, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))]
						}
					}
				}
				break
			}
			default:
			{
				return [null, fmt.Errorf("unsupported type kind %q for %q", $.namedValueInterfaceValue<any>(info.Kind, "compilercontract.TypeKind", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeKind")), $.namedValueInterfaceValue<any>(info.ID, "compilercontract.TypeID", {}, /* @__PURE__ */ $.basicType("string", "compilercontract.TypeID")))]
				break
			}
		}
	}
	return [index, null]
}

var __goscriptStatic0$value: any
function __goscriptStatic0(): any {
	return __goscriptStatic0$value ??= ($.overrideTypeMethods(/* @__PURE__ */ $.pointerType("bytes.Reader"), "bytes.Reader", () => [$.methodSignature("Len", [], [/* @__PURE__ */ $.basicType("int")], true), $.methodSignature("Read", [["b", /* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("uint8"))]], [["n", /* @__PURE__ */ $.basicType("int")], ["err", "error"]], true), $.methodSignature("ReadAt", [["b", /* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("uint8"))], ["off", /* @__PURE__ */ $.basicType("int64")]], [["n", /* @__PURE__ */ $.basicType("int")], ["err", "error"]], true), $.methodSignature("ReadByte", [], [/* @__PURE__ */ $.basicType("uint8"), "error"], true), $.methodSignature("ReadRune", [], [["ch", /* @__PURE__ */ $.basicType("int32")], ["size", /* @__PURE__ */ $.basicType("int")], ["err", "error"]], true), $.methodSignature("Reset", [["b", /* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("uint8"))]], [], true), $.methodSignature("Seek", [["offset", /* @__PURE__ */ $.basicType("int64")], ["whence", /* @__PURE__ */ $.basicType("int")]], [/* @__PURE__ */ $.basicType("int64"), "error"], true), $.methodSignature("Size", [], [/* @__PURE__ */ $.basicType("int64")], true), $.methodSignature("UnreadByte", [], ["error"], true), $.methodSignature("UnreadRune", [], ["error"], true), $.methodSignature("WriteTo", [["w", "io.Writer"]], [["n", /* @__PURE__ */ $.basicType("int64")], ["err", "error"]], true)]))
}

var __goscriptAwait: any
