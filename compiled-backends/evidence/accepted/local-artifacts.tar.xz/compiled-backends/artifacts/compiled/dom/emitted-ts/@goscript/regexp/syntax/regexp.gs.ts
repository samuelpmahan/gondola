// Generated file based on regexp.go
// Updated when compliance tests are re-run, DO NOT EDIT!

import * as $ from "@goscript/builtin/index.js"
import * as strconv from "@goscript/strconv/index.js"
import * as slices from "@goscript/slices/index.js"
import * as strings from "@goscript/strings/index.js"
import * as unicode from "@goscript/unicode/index.js"
import * as __goscript_op_string from "./op_string.gs.ts"
import * as __goscript_parse from "./parse.gs.ts"
import * as __goscript_simplify from "./simplify.gs.ts"
import "./op_string.gs.ts"

$.registerTypePackagePath("regexp/syntax", ["syntax.Regexp", "syntax.Op", "syntax.printFlags"])

export type Op = number

$.registerNamedValueType(
	"syntax.Op",
	{String: (receiver: any) => (__goscript_op_string.Op_String as any)(($.isVarRef(receiver) ? receiver.value : receiver))},
	[$.methodSignature("String", [], [/* @__PURE__ */ $.basicType("string")])]
);

$.registerNamedValueType(
	"*syntax.Op",
	{String: (receiver: any) => (__goscript_op_string.Op_String as any)($.pointerValue(receiver))},
	[$.methodSignature("String", [], [/* @__PURE__ */ $.basicType("string")])]
);

export type printFlags = number

export class Regexp {
	public declare Op: Op

	public declare Flags: __goscript_parse.Flags

	public declare Sub: $.Slice<Regexp | $.VarRef<Regexp> | null>

	public declare Sub0: (Regexp | $.VarRef<Regexp> | null)[]

	public declare Rune: $.Slice<number>

	public declare Rune0: number[]

	public declare Min: number

	public declare Max: number

	public declare Cap: number

	public declare Name: string

	constructor(__goscriptValue?: boolean, Op$?: Op, Flags$?: __goscript_parse.Flags, Sub$?: $.Slice<Regexp | $.VarRef<Regexp> | null>, Sub0$?: (Regexp | $.VarRef<Regexp> | null)[], Rune$?: $.Slice<number>, Rune0$?: number[], Min$?: number, Max$?: number, Cap$?: number, Name$?: string) {
		this.Op = Op$ ?? 0
		this.Flags = Flags$ ?? 0
		this.Sub = Sub$ ?? (null! as $.Slice<Regexp | $.VarRef<Regexp> | null>)
		this.Sub0 = Sub0$ ?? $.arrayValue(globalThis.Array.from({ length: 1 }, () => null))
		this.Rune = Rune$ ?? (null! as $.Slice<number>)
		this.Rune0 = Rune0$ ?? $.arrayValue(globalThis.Array.from({ length: 2 }, () => 0))
		this.Min = Min$ ?? 0
		this.Max = Max$ ?? 0
		this.Cap = Cap$ ?? 0
		this.Name = Name$ ?? ""
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): Regexp {
		return new Regexp(true, this.Op, this.Flags, this.Sub, $.cloneArrayValue(this.Sub0, __goscriptStatic0()), this.Rune, $.cloneArrayValue(this.Rune0, __goscriptStatic1()), this.Min, this.Max, this.Cap, this.Name)
	}

	public __goscriptAssign(source: Regexp): this {
		this.Op = source.Op
		this.Flags = source.Flags
		this.Sub = source.Sub
		this.Sub0 = $.assignFieldValue(this.Sub0, source.Sub0, __goscriptStatic0())
		this.Rune = source.Rune
		this.Rune0 = $.assignFieldValue(this.Rune0, source.Rune0, __goscriptStatic1())
		this.Min = source.Min
		this.Max = source.Max
		this.Cap = source.Cap
		this.Name = source.Name
		return this
	}

	public CapNames(): $.Slice<string> {
		const re: Regexp | $.VarRef<Regexp> | null = this;
		let names = $.makeSlice<string>((re !== null && (re as any).__isVarRef !== true && (re as any).__goValue === undefined ? ((re as any) as Regexp).MaxCap() : Regexp.prototype.MaxCap.call(re)) + 1, undefined, "string")
		void (re !== null && (re as any).__isVarRef !== true && (re as any).__goValue === undefined ? ((re as any) as Regexp).capNames(names) : Regexp.prototype.capNames.call(re, names))
		return names
	}

	public Equal(y: Regexp | $.VarRef<Regexp> | null): boolean {
		const x: Regexp | $.VarRef<Regexp> | null = this;
		const x$: Regexp = x == null ? $.pointerTarget<Regexp>(x) : (x as any).__isVarRef === true ? (x as any).value : (x as any).__goValue === undefined ? (x as any) : $.pointerTarget<Regexp>(x)
		const y$: Regexp = y == null ? $.pointerTarget<Regexp>(y) : (y as any).__isVarRef === true ? (y as any).value : (y as any).__goValue === undefined ? (y as any) : $.pointerTarget<Regexp>(y)
		if ((x == null) || (y == null)) {
			return (x === y || ($.pointerAliasesMade || (x as any)?.__goElementBacking !== undefined) && $.pointerEqual(x, y))
		}
		if ((x$ as Regexp).Op != (y$ as Regexp).Op) {
			return false
		}
		switch ((x$ as Regexp).Op) {
			case 10:
			{
				if ($.uint(((x$ as Regexp).Flags & 256), 16) != $.uint(((y$ as Regexp).Flags & 256), 16)) {
					return false
				}
				break
			}
			case 3:
			case 4:
			{
				return ($.uint(((x$ as Regexp).Flags & 1), 16) == $.uint(((y$ as Regexp).Flags & 1), 16)) && slices.Equal((x$ as Regexp).Rune, (y$ as Regexp).Rune)
				break
			}
			case 19:
			case 18:
			{
				return slices.EqualFunc((x$ as Regexp).Sub, (y$ as Regexp).Sub, $.functionValue((x: Regexp | $.VarRef<Regexp> | null, y: Regexp | $.VarRef<Regexp> | null): boolean => $.pointerValue<Regexp>(x).Equal(y), ({ kind: $.TypeKind.Function, params: [/* @__PURE__ */ $.pointerType("syntax.Regexp"), /* @__PURE__ */ $.pointerType("syntax.Regexp")], results: [/* @__PURE__ */ $.basicType("bool")] } as $.FunctionTypeInfo)))
				break
			}
			case 14:
			case 15:
			case 16:
			{
				if (($.uint(((x$ as Regexp).Flags & 32), 16) != $.uint(((y$ as Regexp).Flags & 32), 16)) || !Regexp.prototype.Equal.call($.plainSliceIndex((x$ as Regexp).Sub!, 0), $.plainSliceIndex((y$ as Regexp).Sub!, 0))) {
					return false
				}
				break
			}
			case 17:
			{
				if (((($.uint(((x$ as Regexp).Flags & 32), 16) != $.uint(((y$ as Regexp).Flags & 32), 16)) || ((x$ as Regexp).Min != (y$ as Regexp).Min)) || ((x$ as Regexp).Max != (y$ as Regexp).Max)) || !Regexp.prototype.Equal.call($.plainSliceIndex((x$ as Regexp).Sub!, 0), $.plainSliceIndex((y$ as Regexp).Sub!, 0))) {
					return false
				}
				break
			}
			case 13:
			{
				if ((((x$ as Regexp).Cap != (y$ as Regexp).Cap) || (!$.stringEqual((x$ as Regexp).Name, (y$ as Regexp).Name))) || !Regexp.prototype.Equal.call($.plainSliceIndex((x$ as Regexp).Sub!, 0), $.plainSliceIndex((y$ as Regexp).Sub!, 0))) {
					return false
				}
				break
			}
		}
		return true
	}

	public MaxCap(): number {
		const re: Regexp | $.VarRef<Regexp> | null = this;
		const re$: Regexp = re == null ? $.pointerTarget<Regexp>(re) : (re as any).__isVarRef === true ? (re as any).value : (re as any).__goValue === undefined ? (re as any) : $.pointerTarget<Regexp>(re)
		let m = 0
		if ((re$ as Regexp).Op == 13) {
			m = (re$ as Regexp).Cap
		}
		for (let __goscriptRangeTarget0 = (re$ as Regexp).Sub, __goscriptRangeWindow0 = $.sliceRange(__goscriptRangeTarget0), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow0.length; __rangeIndex++) {
			let sub = (__goscriptRangeWindow0.backing[__goscriptRangeWindow0.offset + __rangeIndex] as Regexp | $.VarRef<Regexp> | null)
			{
				let n = (sub !== null && (sub as any).__isVarRef !== true && (sub as any).__goValue === undefined ? ((sub as any) as Regexp).MaxCap() : Regexp.prototype.MaxCap.call(sub))
				if (m < n) {
					m = n
				}
			}
		}
		return m
	}

	public Simplify(): Regexp | $.VarRef<Regexp> | null {
		const re: Regexp | $.VarRef<Regexp> | null = this;
		const re$: Regexp = re == null ? $.pointerTarget<Regexp>(re) : (re as any).__isVarRef === true ? (re as any).value : (re as any).__goValue === undefined ? (re as any) : $.pointerTarget<Regexp>(re)
		if (re == null) {
			return null
		}
		switch ((re$ as Regexp).Op) {
			case 13:
			case 18:
			case 19:
			{
				let nre: Regexp | $.VarRef<Regexp> | null = re
				for (let __goscriptRangeTarget1 = (re$ as Regexp).Sub, __goscriptRangeWindow1 = $.sliceRange(__goscriptRangeTarget1), i = 0; i < __goscriptRangeWindow1.length; i++) {
					let sub = (__goscriptRangeWindow1.backing[__goscriptRangeWindow1.offset + i] as Regexp | $.VarRef<Regexp> | null)
					let nsub = (sub !== null && (sub as any).__isVarRef !== true && (sub as any).__goValue === undefined ? ((sub as any) as Regexp).Simplify() : Regexp.prototype.Simplify.call(sub))
					if (((nre === re || ($.pointerAliasesMade || (nre as any)?.__goElementBacking !== undefined) && $.pointerEqual(nre, re))) && ((nsub !== sub && !(($.pointerAliasesMade || (nsub as any)?.__goElementBacking !== undefined) && $.pointerEqual(nsub, sub))))) {
						// Start a copy.
						nre = new Regexp()
						$.pointerValue<Regexp>(nre).__goscriptAssign((re$ as Regexp))
						$.pointerValue<Regexp>(nre).Rune = null
						$.pointerValue<Regexp>(nre).Sub = $.appendSlice($.goSlice($.pointerValue<Regexp>(nre).Sub0, undefined, 0), $.goSlice((re$ as Regexp).Sub, undefined, i), $.appendZeros.nil)
					}
					if ((nre !== re && !(($.pointerAliasesMade || (nre as any)?.__goElementBacking !== undefined) && $.pointerEqual(nre, re)))) {
						$.pointerValue<Regexp>(nre).Sub = $.appendOne($.pointerValue<Regexp>(nre).Sub, nsub, $.appendZeros.nil)
					}
				}
				return nre
				break
			}
			case 14:
			case 15:
			case 16:
			{
				let sub = Regexp.prototype.Simplify.call($.plainSliceIndex((re$ as Regexp).Sub!, 0))
				return __goscript_simplify.simplify1((re$ as Regexp).Op, (re$ as Regexp).Flags, sub, re)
				break
			}
			case 17:
			{
				if (((re$ as Regexp).Min == 0) && ((re$ as Regexp).Max == 0)) {
					return new Regexp(false, 2)
				}

				// The fun begins.
				let sub = Regexp.prototype.Simplify.call($.plainSliceIndex((re$ as Regexp).Sub!, 0))

				// x{n,} means at least n matches of x.
				if ((re$ as Regexp).Max == -1) {
					// Special case: x{0,} is x*.
					if ((re$ as Regexp).Min == 0) {
						return __goscript_simplify.simplify1(14, (re$ as Regexp).Flags, sub, null)
					}

					// Special case: x{1,} is x+.
					if ((re$ as Regexp).Min == 1) {
						return __goscript_simplify.simplify1(15, (re$ as Regexp).Flags, sub, null)
					}

					// General case: x{4,} is xxxx+.
					let nre = new Regexp(false, 18)
					let nre$: Regexp = nre == null ? $.pointerTarget<Regexp>(nre) : (nre as any).__isVarRef === true ? (nre as any).value : (nre as any).__goValue === undefined ? (nre as any) : $.pointerTarget<Regexp>(nre);
					;(nre$ as Regexp).Sub = $.goSlice((nre$ as Regexp).Sub0, undefined, 0)
					for (let i = 0; i < ((re$ as Regexp).Min - 1); i++) {
						;(nre$ as Regexp).Sub = $.appendOne((nre$ as Regexp).Sub, sub, $.appendZeros.nil)
					}
					;(nre$ as Regexp).Sub = $.appendOne((nre$ as Regexp).Sub, __goscript_simplify.simplify1(15, (re$ as Regexp).Flags, sub, null), $.appendZeros.nil)
					return nre
				}

				// Special case x{0} handled above.

				// Special case: x{1} is just x.
				if (((re$ as Regexp).Min == 1) && ((re$ as Regexp).Max == 1)) {
					return sub
				}

				// General case: x{n,m} means n copies of x and m copies of x?
				// The machine will do less work if we nest the final m copies,
				// so that x{2,5} = xx(x(x(x)?)?)?

				// Build leading prefix: xx.
				let prefix: Regexp | $.VarRef<Regexp> | null = null! as Regexp | $.VarRef<Regexp> | null
				if ((re$ as Regexp).Min > 0) {
					prefix = new Regexp(false, 18)
					$.pointerValue<Regexp>(prefix).Sub = $.goSlice($.pointerValue<Regexp>(prefix).Sub0, undefined, 0)
					for (let i = 0; i < (re$ as Regexp).Min; i++) {
						$.pointerValue<Regexp>(prefix).Sub = $.appendOne($.pointerValue<Regexp>(prefix).Sub, sub, $.appendZeros.nil)
					}
				}

				// Build and attach suffix: (x(x(x)?)?)?
				if ((re$ as Regexp).Max > (re$ as Regexp).Min) {
					let suffix: Regexp | $.VarRef<Regexp> | null = __goscript_simplify.simplify1(16, (re$ as Regexp).Flags, sub, null)
					for (let i = (re$ as Regexp).Min + 1; i < (re$ as Regexp).Max; i++) {
						let nre2 = new Regexp(false, 18)
						let nre2$: Regexp = nre2 == null ? $.pointerTarget<Regexp>(nre2) : (nre2 as any).__isVarRef === true ? (nre2 as any).value : (nre2 as any).__goValue === undefined ? (nre2 as any) : $.pointerTarget<Regexp>(nre2);
						;(nre2$ as Regexp).Sub = $.appendValues($.goSlice((nre2$ as Regexp).Sub0, undefined, 0), $.appendZeros.nil, sub, suffix)
						suffix = __goscript_simplify.simplify1(16, (re$ as Regexp).Flags, nre2, null)
					}
					if (prefix == null) {
						return suffix
					}
					$.pointerValue<Regexp>(prefix).Sub = $.appendOne($.pointerValue<Regexp>(prefix).Sub, suffix, $.appendZeros.nil)
				}
				if (prefix != null) {
					return prefix
				}

				// Some degenerate case like min > max or min < max < 0.
				// Handle as impossible match.
				return new Regexp(false, 1)
				break
			}
		}

		return re
	}

	public String(): string {
		const re: Regexp | $.VarRef<Regexp> | null = this;
		let b = $.varRef($.markAsStructValue(new strings.Builder()))
		let flags: $.VarRef<globalThis.Map<Regexp | $.VarRef<Regexp> | null, printFlags> | null> = $.varRef(null! as globalThis.Map<Regexp | $.VarRef<Regexp> | null, printFlags> | null)
		let [must, cant] = calcFlags(re, flags)
		must |= $.uint((((cant & ~(1)) << 5) & 0xff), 8)
		if (must != 0) {
			must |= 8
		}
		writeRegexp(b, re, must, flags.value)
		return b.value.String()
	}

	public capNames(names: $.Slice<string>): void {
		const re: Regexp | $.VarRef<Regexp> | null = this;
		const re$: Regexp = re == null ? $.pointerTarget<Regexp>(re) : (re as any).__isVarRef === true ? (re as any).value : (re as any).__goValue === undefined ? (re as any) : $.pointerTarget<Regexp>(re)
		if ((re$ as Regexp).Op == 13) {
			$.sliceElems(names!)[$.sliceSlot(names!, (re$ as Regexp).Cap)] = (re$ as Regexp).Name
		}
		for (let __goscriptRangeTarget2 = (re$ as Regexp).Sub, __goscriptRangeWindow2 = $.sliceRange(__goscriptRangeTarget2), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow2.length; __rangeIndex++) {
			let sub = (__goscriptRangeWindow2.backing[__goscriptRangeWindow2.offset + __rangeIndex] as Regexp | $.VarRef<Regexp> | null)
			void (sub !== null && (sub as any).__isVarRef !== true && (sub as any).__goValue === undefined ? ((sub as any) as Regexp).capNames(names) : Regexp.prototype.capNames.call(sub, names))
		}
	}

	static __typeInfo = $.registerStructType(
		"syntax.Regexp",
		() => new Regexp(),
		() => [$.methodSignature("CapNames", [], [/* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("string"))], true), $.methodSignature("Equal", [["y", /* @__PURE__ */ $.pointerType("syntax.Regexp")]], [/* @__PURE__ */ $.basicType("bool")], true), $.methodSignature("MaxCap", [], [/* @__PURE__ */ $.basicType("int")], true), $.methodSignature("Simplify", [], [/* @__PURE__ */ $.pointerType("syntax.Regexp")], true), $.methodSignature("String", [], [/* @__PURE__ */ $.basicType("string")], true), $.methodSignature("capNames", [["names", /* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("string"))]], [], true)],
		Regexp,
		() => [/* @__PURE__ */ $.structField("Op", /* @__PURE__ */ $.basicType("uint8", "syntax.Op"), [0], 0, true), /* @__PURE__ */ $.structField("Flags", /* @__PURE__ */ $.basicType("uint16", "syntax.Flags"), [1], 2, true), /* @__PURE__ */ $.structField("Sub", /* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.pointerType("syntax.Regexp")), [2], 8, true), /* @__PURE__ */ $.structField("Sub0", /* @__PURE__ */ $.arrayType(/* @__PURE__ */ $.pointerType("syntax.Regexp"), 1), [3], 32, true), /* @__PURE__ */ $.structField("Rune", /* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("int32")), [4], 40, true), /* @__PURE__ */ $.structField("Rune0", /* @__PURE__ */ $.arrayType(/* @__PURE__ */ $.basicType("int32"), 2), [5], 64, true), /* @__PURE__ */ $.structField("Min", /* @__PURE__ */ $.basicType("int"), [6], 72, true), /* @__PURE__ */ $.structField("Max", /* @__PURE__ */ $.basicType("int"), [7], 80, true), /* @__PURE__ */ $.structField("Cap", /* @__PURE__ */ $.basicType("int"), [8], 88, true), /* @__PURE__ */ $.structField("Name", /* @__PURE__ */ $.basicType("string"), [9], 96, true)]
	)
}

export const OpNoMatch: Op = 1

export const OpEmptyMatch: Op = 2

export const OpLiteral: Op = 3

export const OpCharClass: Op = 4

export const OpAnyCharNotNL: Op = 5

export const OpAnyChar: Op = 6

export const OpBeginLine: Op = 7

export const OpEndLine: Op = 8

export const OpBeginText: Op = 9

export const OpEndText: Op = 10

export const OpWordBoundary: Op = 11

export const OpNoWordBoundary: Op = 12

export const OpCapture: Op = 13

export const OpStar: Op = 14

export const OpPlus: Op = 15

export const OpQuest: Op = 16

export const OpRepeat: Op = 17

export const OpConcat: Op = 18

export const OpAlternate: Op = 19

export const opPseudo: Op = 128

export const flagI: printFlags = 1

export const flagM: printFlags = 2

export const flagS: printFlags = 4

export const flagOff: printFlags = 8

export const flagPrec: printFlags = 16

export const negShift: number = 5

export const meta: string = "\\.+*?()|[]{}^$"

export function addSpan(start: Regexp | $.VarRef<Regexp> | null, last: Regexp | $.VarRef<Regexp> | null, f: printFlags, flags: $.VarRef<globalThis.Map<Regexp | $.VarRef<Regexp> | null, printFlags> | null> | null): void {
	if ($.pointerValue<globalThis.Map<Regexp | $.VarRef<Regexp> | null, printFlags> | null>(flags) == null) {
		flags!.value = $.makeMap<Regexp | $.VarRef<Regexp> | null, printFlags>(undefined, /* @__PURE__ */ $.pointerType("syntax.Regexp"))
	}
	$.mapSet(($.pointerValue<globalThis.Map<Regexp | $.VarRef<Regexp> | null, printFlags> | null>(flags)), start, f)
	const __goscriptMap0 = ($.pointerValue<globalThis.Map<Regexp | $.VarRef<Regexp> | null, printFlags> | null>(flags))
	const __goscriptMapKey0 = last
	$.mapSet(__goscriptMap0, __goscriptMapKey0, $.mapGet<Regexp | $.VarRef<Regexp> | null, printFlags, printFlags>(__goscriptMap0, __goscriptMapKey0, 0)[0] | (8))
}

export function calcFlags(re: Regexp | $.VarRef<Regexp> | null, flags: $.VarRef<globalThis.Map<Regexp | $.VarRef<Regexp> | null, printFlags> | null> | null): [printFlags, printFlags] {
	let must: printFlags = 0
	let cant: printFlags = 0
	const re$: Regexp = re == null ? $.pointerTarget<Regexp>(re) : (re as any).__isVarRef === true ? (re as any).value : (re as any).__goValue === undefined ? (re as any) : $.pointerTarget<Regexp>(re)
	switch ((re$ as Regexp).Op) {
		default:
		{
			return [0, 0]
			break
		}
		case 3:
		{
			for (let __goscriptRangeTarget3 = (re$ as Regexp).Rune, __goscriptRangeWindow3 = $.sliceRange(__goscriptRangeTarget3), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow3.length; __rangeIndex++) {
				let r = $.int((__goscriptRangeWindow3.backing[__goscriptRangeWindow3.offset + __rangeIndex] as number), 32)
				if (((65 <= r) && (r <= 125251)) && (unicode.SimpleFold(r) != r)) {
					if ($.uint(((re$ as Regexp).Flags & 1), 16) != 0) {
						return [1, 0]
					} else {
						return [0, 1]
					}
				}
			}
			return [0, 0]
			break
		}
		case 4:
		{
			for (let i = 0; i < $.sliceLen((re$ as Regexp).Rune); i += 2) {
				let lo = $.max(65, $.typedSliceIndex((re$ as Regexp).Rune!, i))
				let hi = $.min(125251, $.typedSliceIndex((re$ as Regexp).Rune!, i + 1))
				for (let r = lo; r <= hi; r = ((r + 1) | 0)) {
					for (let f = unicode.SimpleFold(r); f != r; f = unicode.SimpleFold(f)) {
						if (!((lo <= f) && (f <= hi)) && !__goscript_parse.inCharClass(f, (re$ as Regexp).Rune)) {
							return [0, 1]
						}
					}
				}
			}
			return [0, 0]
			break
		}
		case 5:
		{
			return [0, 4]
			break
		}
		case 6:
		{
			return [4, 0]
			break
		}
		case 7:
		case 8:
		{
			return [2, 0]
			break
		}
		case 10:
		{
			if ($.uint(((re$ as Regexp).Flags & 256), 16) != 0) {
				return [0, 2]
			}
			return [0, 0]
			break
		}
		case 13:
		case 14:
		case 15:
		case 16:
		case 17:
		{
			return calcFlags($.plainSliceIndex((re$ as Regexp).Sub!, 0), flags)
			break
		}
		case 18:
		case 19:
		{
			let __goscriptShadow0: printFlags = 0
			let __goscriptShadow1: printFlags = 0
			let allCant: printFlags = 0
			let start = 0
			let last = 0
			let did = false
			for (let __goscriptRangeTarget4 = (re$ as Regexp).Sub, __goscriptRangeWindow4 = $.sliceRange(__goscriptRangeTarget4), i = 0; i < __goscriptRangeWindow4.length; i++) {
				let sub = (__goscriptRangeWindow4.backing[__goscriptRangeWindow4.offset + i] as Regexp | $.VarRef<Regexp> | null)
				let [subMust, subCant] = calcFlags(sub, flags)
				if (($.uint((__goscriptShadow0 & subCant), 8) != 0) || ($.uint((subMust & __goscriptShadow1), 8) != 0)) {
					if (__goscriptShadow0 != 0) {
						addSpan($.plainSliceIndex((re$ as Regexp).Sub!, start), $.plainSliceIndex((re$ as Regexp).Sub!, last), __goscriptShadow0, flags)
					}
					__goscriptShadow0 = 0
					__goscriptShadow1 = 0
					start = i
					did = true
				}
				__goscriptShadow0 |= subMust
				__goscriptShadow1 |= subCant
				allCant |= subCant
				if (subMust != 0) {
					last = i
				}
				if ((__goscriptShadow0 == 0) && (start == i)) {
					start++
				}
			}
			if (!did) {
				// No conflicts: pass the accumulated must and cant upward.
				return [__goscriptShadow0, __goscriptShadow1]
			}
			if (__goscriptShadow0 != 0) {
				// Conflicts found; need to finish final span.
				addSpan($.plainSliceIndex((re$ as Regexp).Sub!, start), $.plainSliceIndex((re$ as Regexp).Sub!, last), __goscriptShadow0, flags)
			}
			return [0, allCant]
			break
		}
	}
	throw new globalThis.Error("goscript: unreachable return")
}

export function writeRegexp(b: strings.Builder | $.VarRef<strings.Builder> | null, re: Regexp | $.VarRef<Regexp> | null, f: printFlags, flags: globalThis.Map<Regexp | $.VarRef<Regexp> | null, printFlags> | null): void {
	using __defer = new $.DisposableStack()
	const re$: Regexp = re == null ? $.pointerTarget<Regexp>(re) : (re as any).__isVarRef === true ? (re as any).value : (re as any).__goValue === undefined ? (re as any) : $.pointerTarget<Regexp>(re)
	f |= $.mapGet<Regexp | $.VarRef<Regexp> | null, printFlags, printFlags>(flags, re, 0)[0]
	if ((($.uint((f & 16), 8) != 0) && ($.uint((f & ~((8 | 16))), 8) != 0)) && ($.uint((f & 8), 8) != 0)) {
		// flagPrec is redundant with other flags being added and terminated
		f = f & ~((16))
	}
	if ($.uint((f & ~((8 | 16))), 8) != 0) {
		void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("(?") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "(?"))
		if ($.uint((f & 1), 8) != 0) {
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("i") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "i"))
		}
		if ($.uint((f & 2), 8) != 0) {
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("m") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "m"))
		}
		if ($.uint((f & 4), 8) != 0) {
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("s") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "s"))
		}
		if ($.uint((f & (192)), 8) != 0) {
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("-") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "-"))
			if ($.uint((f & (64)), 8) != 0) {
				void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("m") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "m"))
			}
			if ($.uint((f & (128)), 8) != 0) {
				void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("s") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "s"))
			}
		}
		void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString(":") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), ":"))
	}
	if ($.uint((f & 8), 8) != 0) {
		const __goscriptDeferCallee0 = $.functionValue(((__receiver) => (s: string) => __receiver.WriteString(s))($.pointerValue<strings.Builder>(b)), ({ kind: $.TypeKind.Function, params: [/* @__PURE__ */ $.basicType("string")], results: [/* @__PURE__ */ $.basicType("int"), "error"] } as $.FunctionTypeInfo), "strings.(*Builder).WriteString-fm")
		__defer.defer(() => { __goscriptDeferCallee0(")") })
	}
	if ($.uint((f & 16), 8) != 0) {
		void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("(?:") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "(?:"))
		const __goscriptDeferCallee1 = $.functionValue(((__receiver) => (s: string) => __receiver.WriteString(s))($.pointerValue<strings.Builder>(b)), ({ kind: $.TypeKind.Function, params: [/* @__PURE__ */ $.basicType("string")], results: [/* @__PURE__ */ $.basicType("int"), "error"] } as $.FunctionTypeInfo), "strings.(*Builder).WriteString-fm")
		__defer.defer(() => { __goscriptDeferCallee1(")") })
	}

	switch ((re$ as Regexp).Op) {
		default:
		{
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("<invalid op" + strconv.Itoa((re$ as Regexp).Op) + ">") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "<invalid op" + strconv.Itoa((re$ as Regexp).Op) + ">"))
			break
		}
		case 1:
		{
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("[^\\x00-\\x{10FFFF}]") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "[^\\x00-\\x{10FFFF}]"))
			break
		}
		case 2:
		{
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("(?:)") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "(?:)"))
			break
		}
		case 3:
		{
			for (let __goscriptRangeTarget5 = (re$ as Regexp).Rune, __goscriptRangeWindow5 = $.sliceRange(__goscriptRangeTarget5), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow5.length; __rangeIndex++) {
				let r = $.int((__goscriptRangeWindow5.backing[__goscriptRangeWindow5.offset + __rangeIndex] as number), 32)
				escape(b, r, false)
			}
			break
		}
		case 4:
		{
			if (($.sliceLen((re$ as Regexp).Rune) % 2) != 0) {
				void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("[invalid char class]") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "[invalid char class]"))
				break
			}
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteRune(91) : strings.Builder.prototype.WriteRune.call($.pointerValue<strings.Builder>(b), 91))
			if ($.sliceLen((re$ as Regexp).Rune) == 0) {
				void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("^\\x00-\\x{10FFFF}") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "^\\x00-\\x{10FFFF}"))
			} else {
				if ((($.typedSliceIndex((re$ as Regexp).Rune!, 0) == 0) && ($.typedSliceIndex((re$ as Regexp).Rune!, $.sliceLen((re$ as Regexp).Rune) - 1) == 1114111)) && ($.sliceLen((re$ as Regexp).Rune) > 2)) {
					// Contains 0 and MaxRune. Probably a negated class.
					// Print the gaps.
					void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteRune(94) : strings.Builder.prototype.WriteRune.call($.pointerValue<strings.Builder>(b), 94))
					for (let i = 1; i < ($.sliceLen((re$ as Regexp).Rune) - 1); i += 2) {
						let lo = $.int((($.typedSliceIndex((re$ as Regexp).Rune!, i) + 1) | 0), 32)
						let hi = $.int((($.typedSliceIndex((re$ as Regexp).Rune!, i + 1) - 1) | 0), 32)
						escape(b, lo, lo == 45)
						if (lo != hi) {
							if (hi != $.int((((lo + 1) | 0)), 32)) {
								void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteRune(45) : strings.Builder.prototype.WriteRune.call($.pointerValue<strings.Builder>(b), 45))
							}
							escape(b, hi, hi == 45)
						}
					}
				} else {
					for (let i = 0; i < $.sliceLen((re$ as Regexp).Rune); i += 2) {
						let lo = $.typedSliceIndex((re$ as Regexp).Rune!, i)
						let hi = $.typedSliceIndex((re$ as Regexp).Rune!, i + 1)
						escape(b, lo, lo == 45)
						if (lo != hi) {
							if (hi != $.int((((lo + 1) | 0)), 32)) {
								void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteRune(45) : strings.Builder.prototype.WriteRune.call($.pointerValue<strings.Builder>(b), 45))
							}
							escape(b, hi, hi == 45)
						}
					}
				}
			}
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteRune(93) : strings.Builder.prototype.WriteRune.call($.pointerValue<strings.Builder>(b), 93))
			break
		}
		case 5:
		case 6:
		{
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString(".") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "."))
			break
		}
		case 7:
		{
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("^") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "^"))
			break
		}
		case 8:
		{
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("$") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "$"))
			break
		}
		case 9:
		{
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("\\A") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "\\A"))
			break
		}
		case 10:
		{
			if ($.uint(((re$ as Regexp).Flags & 256), 16) != 0) {
				void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("$") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "$"))
			} else {
				void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("\\z") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "\\z"))
			}
			break
		}
		case 11:
		{
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("\\b") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "\\b"))
			break
		}
		case 12:
		{
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("\\B") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "\\B"))
			break
		}
		case 13:
		{
			if (!$.stringEqual((re$ as Regexp).Name, "")) {
				void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("(?P<") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "(?P<"))
				void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString((re$ as Regexp).Name) : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), (re$ as Regexp).Name))
				void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteRune(62) : strings.Builder.prototype.WriteRune.call($.pointerValue<strings.Builder>(b), 62))
			} else {
				void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteRune(40) : strings.Builder.prototype.WriteRune.call($.pointerValue<strings.Builder>(b), 40))
			}
			if ($.pointerValue<Regexp>($.plainSliceIndex((re$ as Regexp).Sub!, 0)).Op != 2) {
				writeRegexp(b, $.plainSliceIndex((re$ as Regexp).Sub!, 0), $.mapGet<Regexp | $.VarRef<Regexp> | null, printFlags, printFlags>(flags, $.plainSliceIndex((re$ as Regexp).Sub!, 0), 0)[0], flags)
			}
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteRune(41) : strings.Builder.prototype.WriteRune.call($.pointerValue<strings.Builder>(b), 41))
			break
		}
		case 14:
		case 15:
		case 16:
		case 17:
		{
			let p = 0
			let sub = $.plainSliceIndex((re$ as Regexp).Sub!, 0)
			let sub$: Regexp = sub == null ? $.pointerTarget<Regexp>(sub) : (sub as any).__isVarRef === true ? (sub as any).value : (sub as any).__goValue === undefined ? (sub as any) : $.pointerTarget<Regexp>(sub)
			if (((sub$ as Regexp).Op > 13) || (((sub$ as Regexp).Op == 3) && ($.sliceLen((sub$ as Regexp).Rune) > 1))) {
				p = 16
			}
			writeRegexp(b, sub, p, flags)

			switch ((re$ as Regexp).Op) {
				case 14:
				{
					void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteRune(42) : strings.Builder.prototype.WriteRune.call($.pointerValue<strings.Builder>(b), 42))
					break
				}
				case 15:
				{
					void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteRune(43) : strings.Builder.prototype.WriteRune.call($.pointerValue<strings.Builder>(b), 43))
					break
				}
				case 16:
				{
					void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteRune(63) : strings.Builder.prototype.WriteRune.call($.pointerValue<strings.Builder>(b), 63))
					break
				}
				case 17:
				{
					void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteRune(123) : strings.Builder.prototype.WriteRune.call($.pointerValue<strings.Builder>(b), 123))
					void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString(strconv.Itoa((re$ as Regexp).Min)) : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), strconv.Itoa((re$ as Regexp).Min)))
					if ((re$ as Regexp).Max != (re$ as Regexp).Min) {
						void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteRune(44) : strings.Builder.prototype.WriteRune.call($.pointerValue<strings.Builder>(b), 44))
						if ((re$ as Regexp).Max >= 0) {
							void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString(strconv.Itoa((re$ as Regexp).Max)) : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), strconv.Itoa((re$ as Regexp).Max)))
						}
					}
					void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteRune(125) : strings.Builder.prototype.WriteRune.call($.pointerValue<strings.Builder>(b), 125))
					break
				}
			}
			if ($.uint(((re$ as Regexp).Flags & 32), 16) != 0) {
				void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteRune(63) : strings.Builder.prototype.WriteRune.call($.pointerValue<strings.Builder>(b), 63))
			}
			break
		}
		case 18:
		{
			for (let __goscriptRangeTarget6 = (re$ as Regexp).Sub, __goscriptRangeWindow6 = $.sliceRange(__goscriptRangeTarget6), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow6.length; __rangeIndex++) {
				let sub = (__goscriptRangeWindow6.backing[__goscriptRangeWindow6.offset + __rangeIndex] as Regexp | $.VarRef<Regexp> | null)
				let p = 0
				if ($.pointerValue<Regexp>(sub).Op == 19) {
					p = 16
				}
				writeRegexp(b, sub, p, flags)
			}
			break
		}
		case 19:
		{
			for (let __goscriptRangeTarget7 = (re$ as Regexp).Sub, __goscriptRangeWindow7 = $.sliceRange(__goscriptRangeTarget7), i = 0; i < __goscriptRangeWindow7.length; i++) {
				let sub = (__goscriptRangeWindow7.backing[__goscriptRangeWindow7.offset + i] as Regexp | $.VarRef<Regexp> | null)
				if (i > 0) {
					void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteRune(124) : strings.Builder.prototype.WriteRune.call($.pointerValue<strings.Builder>(b), 124))
				}
				writeRegexp(b, sub, 0, flags)
			}
			break
		}
	}
}

export function escape(b: strings.Builder | $.VarRef<strings.Builder> | null, r: number, force: boolean): void {
	if (unicode.IsPrint(r)) {
		if (strings.ContainsRune("\\.+*?()|[]{}^$", r) || force) {
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteRune(92) : strings.Builder.prototype.WriteRune.call($.pointerValue<strings.Builder>(b), 92))
		}
		void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteRune(r) : strings.Builder.prototype.WriteRune.call($.pointerValue<strings.Builder>(b), r))
		return
	}

	switch (r) {
		case 7:
		{
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("\\a") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "\\a"))
			break
		}
		case 12:
		{
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("\\f") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "\\f"))
			break
		}
		case 10:
		{
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("\\n") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "\\n"))
			break
		}
		case 13:
		{
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("\\r") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "\\r"))
			break
		}
		case 9:
		{
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("\\t") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "\\t"))
			break
		}
		case 11:
		{
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("\\v") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "\\v"))
			break
		}
		default:
		{
			if (r < 0x100) {
				void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("\\x") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "\\x"))
				let s = strconv.FormatInt($.int64(r), 16)
				if ($.stringLen(s) == 1) {
					void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteRune(48) : strings.Builder.prototype.WriteRune.call($.pointerValue<strings.Builder>(b), 48))
				}
				void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString(s) : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), s))
				break
			}
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("\\x{") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "\\x{"))
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString(strconv.FormatInt($.int64(r), 16)) : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), strconv.FormatInt($.int64(r), 16)))
			void (b !== null && (b as any).__isVarRef !== true && (b as any).__goValue === undefined ? ((b as any) as strings.Builder).WriteString("}") : strings.Builder.prototype.WriteString.call($.pointerValue<strings.Builder>(b), "}"))
			break
		}
	}
}

var __goscriptStatic0$value: any
function __goscriptStatic0(): any {
	return __goscriptStatic0$value ??= (/* @__PURE__ */ $.arrayType(/* @__PURE__ */ $.pointerType("syntax.Regexp"), 1))
}

var __goscriptStatic1$value: any
function __goscriptStatic1(): any {
	return __goscriptStatic1$value ??= (/* @__PURE__ */ $.arrayType(/* @__PURE__ */ $.basicType("int32"), 2))
}
