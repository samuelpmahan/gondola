// Generated file based on node.go
// Updated when compliance tests are re-run, DO NOT EDIT!

import * as $ from "@goscript/builtin/index.js"

$.registerTypePackagePath("github.com/samuelpmahan/gondola/gobi", ["gobi.Kind", "gobi.Node", "gobi.Attr", "gobi.Style", "gobi.On", "gobi.Message", "gobi.Effect"])

export type Kind = number

export class Node {
	public declare Kind: Kind

	public declare Tag: string

	public declare Key: string

	public declare Attrs: $.Slice<Attr>

	public declare On: $.Slice<On>

	public declare Kids: $.Slice<Node>

	public declare Text: string

	constructor(__goscriptValue?: boolean, Kind$?: Kind, Tag$?: string, Key$?: string, Attrs$?: $.Slice<Attr>, On$?: $.Slice<On>, Kids$?: $.Slice<Node>, Text$?: string) {
		this.Kind = Kind$ ?? 0
		this.Tag = Tag$ ?? ""
		this.Key = Key$ ?? ""
		this.Attrs = Attrs$ ?? (null! as $.Slice<Attr>)
		this.On = On$ ?? (null! as $.Slice<On>)
		this.Kids = Kids$ ?? (null! as $.Slice<Node>)
		this.Text = Text$ ?? ""
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): Node {
		return new Node(true, this.Kind, this.Tag, this.Key, this.Attrs, this.On, this.Kids, this.Text)
	}

	public __goscriptAssign(source: Node): this {
		this.Kind = source.Kind
		this.Tag = source.Tag
		this.Key = source.Key
		this.Attrs = source.Attrs
		this.On = source.On
		this.Kids = source.Kids
		this.Text = source.Text
		return this
	}

	public Css(styles: $.Slice<Style>): Node {
		const n = this;
		n.Attrs = $.appendOne($.goSlice(n.Attrs, undefined, $.sliceLen(n.Attrs), $.sliceLen(n.Attrs)), new Attr(true, "style", undefined, undefined, styles))
		return (n).clone()
	}

	public Flag(name: string): Node {
		const n = this;
		n.Attrs = $.appendOne($.goSlice(n.Attrs, undefined, $.sliceLen(n.Attrs), $.sliceLen(n.Attrs)), new Attr(true, name, undefined, true))
		return (n).clone()
	}

	public Handle(event: string, message: string, arg: string): Node {
		const n = this;
		n.On = $.appendOne($.goSlice(n.On, undefined, $.sliceLen(n.On), $.sliceLen(n.On)), new On(true, event, message, arg))
		return (n).clone()
	}

	public Keyed(key: string): Node {
		const n = this;
		n.Key = key
		return (n).clone()
	}

	public Set(name: string, value: string): Node {
		const n = this;
		n.Attrs = $.appendOne($.goSlice(n.Attrs, undefined, $.sliceLen(n.Attrs), $.sliceLen(n.Attrs)), new Attr(true, name, value))
		return (n).clone()
	}

	static __typeInfo = $.registerStructType(
		"gobi.Node",
		() => new Node(),
		() => [$.methodSignature("Css", [["styles", /* @__PURE__ */ $.sliceType("gobi.Style")]], ["gobi.Node"], false, true), $.methodSignature("Flag", [["name", /* @__PURE__ */ $.basicType("string")]], ["gobi.Node"]), $.methodSignature("Handle", [["event", /* @__PURE__ */ $.basicType("string")], ["message", /* @__PURE__ */ $.basicType("string")], ["arg", /* @__PURE__ */ $.basicType("string")]], ["gobi.Node"]), $.methodSignature("Keyed", [["key", /* @__PURE__ */ $.basicType("string")]], ["gobi.Node"]), $.methodSignature("Set", [["name", /* @__PURE__ */ $.basicType("string")], ["value", /* @__PURE__ */ $.basicType("string")]], ["gobi.Node"])],
		Node,
		() => [/* @__PURE__ */ $.structField("Kind", /* @__PURE__ */ $.basicType("uint8", "gobi.Kind"), [0], 0, true), /* @__PURE__ */ $.structField("Tag", /* @__PURE__ */ $.basicType("string"), [1], 8, true), /* @__PURE__ */ $.structField("Key", /* @__PURE__ */ $.basicType("string"), [2], 24, true), /* @__PURE__ */ $.structField("Attrs", /* @__PURE__ */ $.sliceType("gobi.Attr"), [3], 40, true), /* @__PURE__ */ $.structField("On", /* @__PURE__ */ $.sliceType("gobi.On"), [4], 64, true), /* @__PURE__ */ $.structField("Kids", /* @__PURE__ */ $.sliceType("gobi.Node"), [5], 88, true), /* @__PURE__ */ $.structField("Text", /* @__PURE__ */ $.basicType("string"), [6], 112, true)]
	)
}

export class Attr {
	public declare Name: string

	public declare Value: string

	public declare Flag: boolean

	public declare Style: $.Slice<Style>

	constructor(__goscriptValue?: boolean, Name$?: string, Value$?: string, Flag$?: boolean, Style$?: $.Slice<Style>) {
		this.Name = Name$ ?? ""
		this.Value = Value$ ?? ""
		this.Flag = Flag$ ?? false
		this.Style = Style$ ?? (null! as $.Slice<Style>)
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): Attr {
		return new Attr(true, this.Name, this.Value, this.Flag, this.Style)
	}

	public __goscriptAssign(source: Attr): this {
		this.Name = source.Name
		this.Value = source.Value
		this.Flag = source.Flag
		this.Style = source.Style
		return this
	}

	static __typeInfo = $.registerStructType(
		"gobi.Attr",
		() => new Attr(),
		() => [],
		Attr,
		() => [/* @__PURE__ */ $.structField("Name", /* @__PURE__ */ $.basicType("string"), [0], 0, true), /* @__PURE__ */ $.structField("Value", /* @__PURE__ */ $.basicType("string"), [1], 16, true), /* @__PURE__ */ $.structField("Flag", /* @__PURE__ */ $.basicType("bool"), [2], 32, true), /* @__PURE__ */ $.structField("Style", /* @__PURE__ */ $.sliceType("gobi.Style"), [3], 40, true)]
	)
}

export class Style {
	public declare Property: string

	public declare Value: string

	constructor(__goscriptValue?: boolean, Property$?: string, Value$?: string) {
		this.Property = Property$ ?? ""
		this.Value = Value$ ?? ""
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): Style {
		return new Style(true, this.Property, this.Value)
	}

	public __goscriptAssign(source: Style): this {
		this.Property = source.Property
		this.Value = source.Value
		return this
	}

	static __typeInfo = $.registerStructType(
		"gobi.Style",
		() => new Style(),
		() => [],
		Style,
		() => [/* @__PURE__ */ $.structField("Property", /* @__PURE__ */ $.basicType("string"), [0], 0, true), /* @__PURE__ */ $.structField("Value", /* @__PURE__ */ $.basicType("string"), [1], 16, true)]
	)
}

export class On {
	public declare Event: string

	public declare Message: string

	public declare Arg: string

	constructor(__goscriptValue?: boolean, Event$?: string, Message$?: string, Arg$?: string) {
		this.Event = Event$ ?? ""
		this.Message = Message$ ?? ""
		this.Arg = Arg$ ?? ""
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): On {
		return new On(true, this.Event, this.Message, this.Arg)
	}

	public __goscriptAssign(source: On): this {
		this.Event = source.Event
		this.Message = source.Message
		this.Arg = source.Arg
		return this
	}

	static __typeInfo = $.registerStructType(
		"gobi.On",
		() => new On(),
		() => [],
		On,
		() => [/* @__PURE__ */ $.structField("Event", /* @__PURE__ */ $.basicType("string"), [0], 0, true), /* @__PURE__ */ $.structField("Message", /* @__PURE__ */ $.basicType("string"), [1], 16, true), /* @__PURE__ */ $.structField("Arg", /* @__PURE__ */ $.basicType("string"), [2], 32, true)]
	)
}

export class Message {
	public declare Name: string

	public declare Arg: string

	constructor(__goscriptValue?: boolean, Name$?: string, Arg$?: string) {
		this.Name = Name$ ?? ""
		this.Arg = Arg$ ?? ""
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): Message {
		return new Message(true, this.Name, this.Arg)
	}

	public __goscriptAssign(source: Message): this {
		this.Name = source.Name
		this.Arg = source.Arg
		return this
	}

	static __typeInfo = $.registerStructType(
		"gobi.Message",
		() => new Message(),
		() => [],
		Message,
		() => [/* @__PURE__ */ $.structField("Name", /* @__PURE__ */ $.basicType("string"), [0], 0, true), /* @__PURE__ */ $.structField("Arg", /* @__PURE__ */ $.basicType("string"), [1], 16, true)]
	)
}

export class Effect {
	public declare Kind: string

	public declare Name: string

	public declare Arg: string

	public declare Reply: string

	constructor(__goscriptValue?: boolean, Kind$?: string, Name$?: string, Arg$?: string, Reply$?: string) {
		this.Kind = Kind$ ?? ""
		this.Name = Name$ ?? ""
		this.Arg = Arg$ ?? ""
		this.Reply = Reply$ ?? ""
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): Effect {
		return new Effect(true, this.Kind, this.Name, this.Arg, this.Reply)
	}

	public __goscriptAssign(source: Effect): this {
		this.Kind = source.Kind
		this.Name = source.Name
		this.Arg = source.Arg
		this.Reply = source.Reply
		return this
	}

	static __typeInfo = $.registerStructType(
		"gobi.Effect",
		() => new Effect(),
		() => [],
		Effect,
		() => [/* @__PURE__ */ $.structField("Kind", /* @__PURE__ */ $.basicType("string"), [0], 0, true), /* @__PURE__ */ $.structField("Name", /* @__PURE__ */ $.basicType("string"), [1], 16, true), /* @__PURE__ */ $.structField("Arg", /* @__PURE__ */ $.basicType("string"), [2], 32, true), /* @__PURE__ */ $.structField("Reply", /* @__PURE__ */ $.basicType("string"), [3], 48, true)]
	)
}

export const Element: Kind = 1

export const Text: Kind = 2

export const Fragment: Kind = 3

export function El(tag: string, kids: $.Slice<Node>): Node {
	return new Node(true, 1, tag, undefined, undefined, undefined, kids)
}

export function Txt(text: string): Node {
	return new Node(true, 2, undefined, undefined, undefined, undefined, undefined, text)
}

export function Frag(kids: $.Slice<Node>): Node {
	return new Node(true, 3, undefined, undefined, undefined, undefined, kids)
}

export function S(property: string, value: string): Style {
	return new Style(true, property, value)
}
