// Generated file based on app.go
// Updated when compliance tests are re-run, DO NOT EDIT!

import * as $ from "@goscript/builtin/index.js"
import * as gobi from "@goscript/github.com/samuelpmahan/gondola/gobi/index.js"
import "@goscript/github.com/samuelpmahan/gondola/gobi/index.js"

$.registerTypePackagePath("github.com/samuelpmahan/gondola/fixtures/compiled/form", ["form.State"])

export class State {
	public declare Draft: string

	public declare Checked: boolean

	public declare Saved: string

	public declare Saves: number

	public declare Literal: string

	constructor(__goscriptValue?: boolean, Draft$?: string, Checked$?: boolean, Saved$?: string, Saves$?: number, Literal$?: string) {
		this.Draft = Draft$ ?? ""
		this.Checked = Checked$ ?? false
		this.Saved = Saved$ ?? ""
		this.Saves = Saves$ ?? 0
		this.Literal = Literal$ ?? ""
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): State {
		return new State(true, this.Draft, this.Checked, this.Saved, this.Saves, this.Literal)
	}

	public __goscriptAssign(source: State): this {
		this.Draft = source.Draft
		this.Checked = source.Checked
		this.Saved = source.Saved
		this.Saves = source.Saves
		this.Literal = source.Literal
		return this
	}

	static __typeInfo = $.registerStructType(
		"form.State",
		() => new State(),
		() => [],
		State,
		() => [/* @__PURE__ */ $.structField("Draft", /* @__PURE__ */ $.basicType("string"), [0], 0, true), /* @__PURE__ */ $.structField("Checked", /* @__PURE__ */ $.basicType("bool"), [1], 16, true), /* @__PURE__ */ $.structField("Saved", /* @__PURE__ */ $.basicType("string"), [2], 24, true), /* @__PURE__ */ $.structField("Saves", /* @__PURE__ */ $.basicType("int"), [3], 40, true), /* @__PURE__ */ $.structField("Literal", /* @__PURE__ */ $.basicType("string"), [4], 48, true)]
	)
}

export function Init(): State {
	return new State(true)
}

export function Update(state: State, message: gobi.Message): [State, $.Slice<gobi.Effect>] {
	switch (message.Name) {
		case "edit":
		{
			state.Draft = message.Arg
			break
		}
		case "checked":
		{
			state.Checked = $.stringEqual(message.Arg, "true")
			break
		}
		case "literal":
		{
			state.Literal = message.Arg
			break
		}
		case "boundary":
		{
			state.Saves = 9007199254740990
			break
		}
		case "save":
		{
			if (!$.stringEqual(state.Draft, "")) {
				state.Saved = state.Draft
				if (state.Saves < 9007199254740991) {
					state.Saves++
				}
			}
			break
		}
		case "reset":
		{
			state = state.__goscriptAssign(new State(true))
			break
		}
	}
	return [state, null]
}
