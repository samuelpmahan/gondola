package facade

import (
	gobiType0 "github.com/samuelpmahan/gondola/compilercontract"
	gobiApp "github.com/samuelpmahan/gondola/fixtures/compiled/list"
	gobiType1 "github.com/samuelpmahan/gondola/gobi"
)

func GobiCompiledInit() gobiApp.State {
	return gobiApp.Init()
}

func GobiCompiledUpdate(state gobiApp.State, message gobiType1.Message) (gobiApp.State, []gobiType1.Effect) {
	return gobiApp.Update(state, message)
}

func GobiCompiledView(state gobiApp.State) gobiType0.View {
	return gobiApp.View(state)
}
