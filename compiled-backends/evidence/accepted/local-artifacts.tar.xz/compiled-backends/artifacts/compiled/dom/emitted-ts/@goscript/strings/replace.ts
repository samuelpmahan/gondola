import * as $ from '@goscript/builtin/index.js'
import { makeStringFinder, stringFinder } from './search.js'
import { Count, HasPrefix } from './strings.js'
import { Builder } from './builder.js'
import * as io from '@goscript/io/index.js'

export class Replacer {
  // guards buildOnce method
  declare public built: boolean

  declare public r: replacer

  declare public oldnew: $.Slice<string>

  constructor(
    init?: Partial<{
      oldnew?: $.Slice<string>
      built?: boolean
      r?: replacer
    }>,
  ) {
    this.built = init?.built ?? false
    this.r = init?.r ?? null
    this.oldnew = init?.oldnew ?? null
  }

  public clone(): Replacer {
    const cloned = new Replacer()
    cloned.built = this.built
    cloned.r = this.r
    cloned.oldnew = this.oldnew
    return cloned
  }

  public buildOnce(): void {
    if (this.built) {
      return
    }
    const r = this
    const built = r.build()
    r.r = built
    r.oldnew = null
    r.built = true
  }

  public build(): replacer {
    const b = this
    let oldnew = b!.oldnew

    // Handle empty case - no replacements to do
    if ($.len(oldnew) == 0) {
      return {
        Replace: (s: string): string => s,
        WriteString: (w: io.Writer, s: string): io.Awaitable<io.IOResult> => {
          const bytes = $.stringToBytes(s)
          return w.Write(bytes)
        },
      }
    }

    if ($.len(oldnew) == 2 && $.len($.arrayIndex(oldnew!, 0)) > 1) {
      return makeSingleStringReplacer(
        $.arrayIndex(oldnew!, 0),
        $.arrayIndex(oldnew!, 1),
      )
    }
    let allNewBytes = true
    for (let i = 0; i < $.len(oldnew); i += 2) {
      if ($.len($.arrayIndex(oldnew!, i)) != 1) {
        return makeGenericReplacer(oldnew)
      }
      if ($.len($.arrayIndex(oldnew!, i + 1)) != 1) {
        allNewBytes = false
      }
    }
    if (allNewBytes) {
      let r: number[] = new Array(256)
      for (let i = 0; i < r.length; i++) {
        r[i] = i
      }
      // The first occurrence of old->new map takes precedence
      // over the others with the same old string.
      for (let i = $.len(oldnew) - 2; i >= 0; i -= 2) {
        let o = $.indexString($.arrayIndex(oldnew!, i), 0)
        let n = $.indexString($.arrayIndex(oldnew!, i + 1), 0)
        r[o] = n
      }
      return {
        Replace: (s: string): string => {
          let result = ''
          for (let i = 0; i < s.length; i++) {
            const charCode = s.charCodeAt(i)
            if (charCode < 256) {
              result += String.fromCharCode(r[charCode])
            } else {
              result += s[i]
            }
          }
          return result
        },
        WriteString: (w: io.Writer, s: string): io.Awaitable<io.IOResult> => {
          const replaced = this.Replace(s)
          const bytes = $.stringToBytes(replaced)
          return w.Write(bytes)
        },
      }
    }
    let r = new byteStringReplacer({
      toReplace: $.makeSlice<string>(0, $.len(oldnew) / 2),
    })
    for (let i = $.len(oldnew) - 2; i >= 0; i -= 2) {
      let o = $.indexString($.arrayIndex(oldnew!, i), 0)
      let n = $.arrayIndex(oldnew!, i + 1)
      // To avoid counting repetitions multiple times.

      // We need to use string([]byte{o}) instead of string(o),
      // to avoid utf8 encoding of o.
      // E. g. byte(150) produces string of length 2.
      if (r.replacements![o] == null) {
        // We need to use string([]byte{o}) instead of string(o),
        // to avoid utf8 encoding of o.
        // E. g. byte(150) produces string of length 2.
        r.toReplace = $.append(
          r.toReplace,
          $.bytesToString(new Uint8Array([o])),
        )
      }
      r.replacements![o] = $.stringToBytes(n)
    }
    return r
  }

  // Replace returns a copy of s with all replacements performed.
  public Replace(s: string): string {
    const r = this
    r.buildOnce()
    return r.r!.Replace(s)
  }

  // WriteString writes s to w with all replacements performed.
  public WriteString(w: io.Writer, s: string): io.Awaitable<io.IOResult> {
    const r = this
    r.buildOnce()
    return r.r!.WriteString(w, s)
  }

  // Register this type with the runtime type system
  static __typeInfo = $.registerStructType(
    'strings.Replacer',
    new Replacer(),
    [
      { name: 'buildOnce', args: [], returns: [] },
      { name: 'build', args: [], returns: [{ type: 'replacer' }] },
      {
        name: 'Replace',
        args: [{ name: 's', type: { kind: $.TypeKind.Basic, name: 'string' } }],
        returns: [{ type: { kind: $.TypeKind.Basic, name: 'string' } }],
      },
      {
        name: 'WriteString',
        args: [
          { name: 'w', type: 'Writer' },
          { name: 's', type: { kind: $.TypeKind.Basic, name: 'string' } },
        ],
        returns: [
          { type: { kind: $.TypeKind.Basic, name: 'number' } },
          {
            type: {
              kind: $.TypeKind.Interface,
              name: 'GoError',
              methods: [
                {
                  name: 'Error',
                  args: [],
                  returns: [
                    { type: { kind: $.TypeKind.Basic, name: 'string' } },
                  ],
                },
              ],
            },
          },
        ],
      },
    ],
    Replacer,
    [
      {
        name: 'built',
        key: 'built',
        type: { kind: $.TypeKind.Basic, name: 'boolean' },
      },
      { name: 'r', key: 'r', type: 'replacer' },
      {
        name: 'oldnew',
        key: 'oldnew',
        type: {
          kind: $.TypeKind.Slice,
          elemType: { kind: $.TypeKind.Basic, name: 'string' },
        },
      },
    ],
  )
}

type replacer = null | {
  Replace(s: string): string
  WriteString(w: io.Writer, s: string): io.Awaitable<io.IOResult>
}

$.registerInterfaceType(
  'replacer',
  null, // Zero value for interface is null
  [
    {
      name: 'Replace',
      args: [{ name: 's', type: { kind: $.TypeKind.Basic, name: 'string' } }],
      returns: [{ type: { kind: $.TypeKind.Basic, name: 'string' } }],
    },
    {
      name: 'WriteString',
      args: [
        { name: 'w', type: 'Writer' },
        { name: 's', type: { kind: $.TypeKind.Basic, name: 'string' } },
      ],
      returns: [
        { type: { kind: $.TypeKind.Basic, name: 'number' } },
        {
          type: {
            kind: $.TypeKind.Interface,
            name: 'GoError',
            methods: [
              {
                name: 'Error',
                args: [],
                returns: [{ type: { kind: $.TypeKind.Basic, name: 'string' } }],
              },
            ],
          },
        },
      ],
    },
  ],
)

// NewReplacer returns a new [Replacer] from a list of old, new string
// pairs. Replacements are performed in the order they appear in the
// target string, without overlapping matches. The old string
// comparisons are done in argument order.
//
// NewReplacer panics if given an odd number of arguments.
export function NewReplacer(...oldnew: string[]): Replacer | null {
  if ($.len(oldnew) % 2 == 1) {
    $.panic('strings.NewReplacer: odd argument count')
  }
  return new Replacer({ oldnew: $.append(null, ...oldnew) })
}

class trieNode {
  // value is the value of the trie node's key/value pair. It is empty if
  // this node is not a complete key.
  declare public value: string

  // priority is the priority (higher is more important) of the trie node's
  // key/value pair; keys are not necessarily matched shortest- or longest-
  // first. Priority is positive if this node is a complete key, and zero
  // otherwise. In the example above, positive/zero priorities are marked
  // with a trailing "+" or "-".
  declare public priority: number

  // prefix is the difference in keys between this trie node and the next.
  // In the example above, node n4 has prefix "cbc" and n4's next node is n5.
  // Node n5 has no children and so has zero prefix, next and table fields.
  declare public prefix: string

  declare public next: trieNode | null

  // table is a lookup table indexed by the next byte in the key, after
  // remapping that byte through genericReplacer.mapping to create a dense
  // index. In the example above, the keys only use 'a', 'b', 'c', 'x' and
  // 'y', which remap to 0, 1, 2, 3 and 4. All other bytes remap to 5, and
  // genericReplacer.tableSize will be 5. Node n0's table will be
  // []*trieNode{ 0:n1, 1:n4, 3:n6 }, where the 0, 1 and 3 are the remapped
  // 'a', 'b' and 'x'.
  declare public table: $.Slice<trieNode | null>

  constructor(
    init?: Partial<{
      next?: trieNode | null
      prefix?: string
      priority?: number
      table?: $.Slice<trieNode | null>
      value?: string
    }>,
  ) {
    this.value = init?.value ?? ''
    this.priority = init?.priority ?? 0
    this.prefix = init?.prefix ?? ''
    this.next = init?.next ?? null
    this.table = init?.table ?? null
  }

  public clone(): trieNode {
    const cloned = new trieNode()
    cloned.value = this.value
    cloned.priority = this.priority
    cloned.prefix = this.prefix
    cloned.next = this.next
    cloned.table = this.table
    return cloned
  }

  public add(
    key: string,
    val: string,
    priority: number,
    r: genericReplacer | null,
  ): void {
    const t = this
    if (key == '') {
      if (t!.priority == 0) {
        t!.value = val
        t!.priority = priority
      }
      return
    }
    if (t!.prefix != '') {
      // Need to split the prefix among multiple nodes.
      // length of the longest common prefix
      let n: number = 0
      for (; n < $.len(t!.prefix) && n < $.len(key); n++) {
        if ($.indexString(t!.prefix, n) != $.indexString(key, n)) {
          break
        }
      }

      // First byte differs, start a new lookup table here. Looking up
      // what is currently t.prefix[0] will lead to prefixNode, and
      // looking up key[0] will lead to keyNode.

      // Insert new node after the common section of the prefix.
      if (n == $.len(t!.prefix)) {
        t!.next!.add($.sliceString(key, n, undefined), val, priority, r)
      } else if (n == 0) {
        // First byte differs, start a new lookup table here. Looking up
        // what is currently t.prefix[0] will lead to prefixNode, and
        // looking up key[0] will lead to keyNode.
        const prefixNode =
          $.len(t!.prefix) == 1 ?
            t!.next
          : new trieNode({
              next: t!.next,
              prefix: $.sliceString(t!.prefix, 1, undefined),
            })
        let keyNode = new trieNode()
        t!.table = $.makeSlice<trieNode | null>(r!.tableSize)
        $.sliceElems(t!.table!)[
          $.sliceSlot(t!.table!, r!.mapping![$.indexString(t!.prefix, 0)])
        ] = prefixNode
        $.sliceElems(t!.table!)[
          $.sliceSlot(t!.table!, r!.mapping![$.indexString(key, 0)])
        ] = keyNode
        t!.prefix = ''
        t!.next = null
        keyNode!.add($.sliceString(key, 1, undefined), val, priority, r)
      } else {
        // Insert new node after the common section of the prefix.
        let next = new trieNode({
          next: t!.next,
          prefix: $.sliceString(t!.prefix, n, undefined),
        })
        t!.prefix = $.sliceString(t!.prefix, undefined, n)
        t!.next = next
        next!.add($.sliceString(key, n, undefined), val, priority, r)
      }
    } else if (t!.table != null) {
      // Insert into existing table.
      let m = r!.mapping![$.indexString(key, 0)]
      if ($.arrayIndex(t!.table!, m) == null) {
        $.sliceElems(t!.table!)[$.sliceSlot(t!.table!, m)] = new trieNode()
      }
      $.arrayIndex(t!.table!, m)!.add(
        $.sliceString(key, 1, undefined),
        val,
        priority,
        r,
      )
    } else {
      t!.prefix = key
      t!.next = new trieNode()
      t!.next!.add('', val, priority, r)
    }
  }
}

class genericReplacer {
  declare public root: trieNode

  // tableSize is the size of a trie node's lookup table. It is the number
  // of unique key bytes.
  declare public tableSize: number

  // mapping maps from key bytes to a dense index for trieNode.table.
  declare public mapping: number[]

  constructor(
    init?: Partial<{ mapping?: number[]; root?: trieNode; tableSize?: number }>,
  ) {
    this.root = init?.root?.clone() ?? new trieNode()
    this.tableSize = init?.tableSize ?? 0
    this.mapping = init?.mapping ?? [
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0,
    ]
  }

  public clone(): genericReplacer {
    const cloned = new genericReplacer()
    cloned.root = this.root?.clone() ?? null
    cloned.tableSize = this.tableSize
    cloned.mapping = this.mapping
    return cloned
  }

  public lookup(s: string, ignoreRoot: boolean): [string, number, boolean] {
    const r = this
    let bestPriority = 0
    let node = r!.root
    let n = 0
    let val: string = ''
    let keylen: number = 0
    let found: boolean = false
    for (; node != null; ) {
      if (node!.priority > bestPriority && !(ignoreRoot && node === r!.root)) {
        bestPriority = node!.priority
        val = node!.value
        keylen = n
        found = true
      }

      if (s == '') {
        break
      }
      if (node!.table != null) {
        let index = r!.mapping![$.indexString(s, 0)]
        if ((index as number) == r!.tableSize) {
          break
        }
        node = $.arrayIndex(node!.table!, index)!
        s = $.sliceString(s, 1, undefined)
        n++
      } else if (node!.prefix != '' && HasPrefix(s, node!.prefix)) {
        n += $.len(node!.prefix)
        s = $.sliceString(s, $.len(node!.prefix), undefined)
        node = node!.next!
      } else {
        break
      }
    }
    return [val, keylen, found]
  }

  public Replace(s: string): string {
    const r = this
    let result = ''
    let last = 0
    for (let i = 0; i <= $.len(s); ) {
      // Fast path: s[i] is not a prefix of any pattern.
      if (i != $.len(s) && r!.root.priority == 0) {
        let index = r!.mapping![$.indexString(s, i)] as number
        if (
          index == r!.tableSize ||
          $.arrayIndex(r!.root.table!, index) == null
        ) {
          i++
          continue
        }
      }

      // Ignore the empty match iff the previous loop found the empty match.
      let [val, keylen, match] = r!.lookup(
        $.sliceString(s, i, undefined),
        false,
      )
      if (match) {
        result += $.sliceString(s, last, i)
        result += val
        i += keylen
        last = i
        continue
      }
      i++
    }
    if (last != $.len(s)) {
      result += $.sliceString(s, last, undefined)
    }
    return result
  }

  public WriteString(w: io.Writer, s: string): io.Awaitable<io.IOResult> {
    const self = this
    return io.runIO(
      (function* (): Generator<
        io.Awaitable<io.IOResult>,
        io.IOResult,
        io.IOResult
      > {
        const r = self
        let sw = getStringWriter(w)
        let last: number = 0
        let n: number = 0
        let prevMatchEmpty: boolean = false
        for (let i = 0; i <= $.len(s); ) {
          // Fast path: s[i] is not a prefix of any pattern.
          if (i != $.len(s) && r!.root.priority == 0) {
            let index = r!.mapping![$.indexString(s, i)] as number
            if (
              index == r!.tableSize ||
              $.arrayIndex(r!.root.table!, index) == null
            ) {
              i++
              continue
            }
          }

          // Ignore the empty match iff the previous loop found the empty match.
          let [val, keylen, match] = r!.lookup(
            $.sliceString(s, i, undefined),
            prevMatchEmpty,
          )
          prevMatchEmpty = match && keylen == 0
          if (match) {
            let [wn, err] = yield sw!.WriteString($.sliceString(s, last, i))
            n += wn
            if (err != null) {
              return [n, err]
            }
            ;[wn, err] = yield sw!.WriteString(val)
            n += wn
            if (err != null) {
              return [n, err]
            }
            i += keylen
            last = i
            continue
          }
          i++
        }
        if (last != $.len(s)) {
          const [wn, err] = yield sw!.WriteString(
            $.sliceString(s, last, undefined),
          )
          n += wn
          return [n, err]
        }
        return [n, null]
      })(),
    )
  }
}

function makeGenericReplacer(oldnew: $.Slice<string>): genericReplacer | null {
  let r = new genericReplacer()
  // Find each byte used, then assign them each an index.
  for (let i = 0; i < $.len(oldnew); i += 2) {
    let key = $.arrayIndex(oldnew!, i)
    for (let j = 0; j < $.len(key); j++) {
      r!.mapping![$.indexString(key, j)] = 1
    }
  }

  for (let _i = 0; _i < $.len(r!.mapping); _i++) {
    const b = r!.mapping![_i]
    {
      r!.tableSize += b as number
    }
  }

  let index: number = 0
  for (let i = 0; i < $.len(r!.mapping); i++) {
    const b = r!.mapping![i]
    {
      if (b == 0) {
        r!.mapping![i] = $.byte(r!.tableSize)
      } else {
        r!.mapping![i] = index
        index++
      }
    }
  }
  // Ensure root node uses a lookup table (for performance).
  r!.root.table = $.makeSlice<trieNode | null>(r!.tableSize)

  for (let i = 0; i < $.len(oldnew); i += 2) {
    r!.root.add(
      $.arrayIndex(oldnew!, i),
      $.arrayIndex(oldnew!, i + 1),
      $.len(oldnew) - i,
      r,
    )
  }
  return r
}

class stringWriter {
  declare public w: io.Writer

  constructor(w: io.Writer) {
    this.w = w
  }

  public WriteString(s: string): io.Awaitable<io.IOResult> {
    const w = this
    return w.w!.Write($.stringToBytes(s))
  }
}

function getStringWriter(w: io.Writer): io.StringWriter {
  let { value: sw, ok: ok } = $.typeAssert<io.StringWriter>(
    w,
    'io.StringWriter',
  )
  if (!ok) {
    sw = new stringWriter(w)
  }
  return sw
}

class singleStringReplacer {
  declare public finder: stringFinder | null

  // value is the new string that replaces that pattern when it's found.
  declare public value: string

  constructor(
    init?: Partial<{ finder?: stringFinder | null; value?: string }>,
  ) {
    this.finder = init?.finder ?? null
    this.value = init?.value ?? ''
  }

  public clone(): singleStringReplacer {
    const cloned = new singleStringReplacer()
    cloned.finder = this.finder
    cloned.value = this.value
    return cloned
  }

  public Replace(s: string): string {
    const r = this
    let buf: Builder = new Builder()
    let [i, matched] = [0, false]
    for (;;) {
      let match = r!.finder!.next($.sliceString(s, i, undefined))
      if (match == -1) {
        break
      }
      matched = true
      buf.Grow(match + $.len(r!.value))
      buf.WriteString($.sliceString(s, i, i + match))
      buf.WriteString(r!.value)
      i += match + $.len(r!.finder!.pattern)
    }
    if (!matched) {
      return s
    }
    buf.WriteString($.sliceString(s, i, undefined))
    return buf.String()
  }

  public WriteString(w: io.Writer, s: string): io.Awaitable<io.IOResult> {
    const self = this
    return io.runIO(
      (function* (): Generator<
        io.Awaitable<io.IOResult>,
        io.IOResult,
        io.IOResult
      > {
        const r = self
        let sw = getStringWriter(w)
        let i: number = 0
        let n: number = 0
        for (;;) {
          let match = r!.finder!.next($.sliceString(s, i, undefined))
          if (match == -1) {
            break
          }
          let [wn, err] = yield sw!.WriteString($.sliceString(s, i, i + match))
          n += wn
          if (err != null) {
            return [n, err]
          }
          ;[wn, err] = yield sw!.WriteString(r!.value)
          n += wn
          if (err != null) {
            return [n, err]
          }
          i += match + $.len(r!.finder!.pattern)
        }
        const [wn, err] = yield sw!.WriteString($.sliceString(s, i, undefined))
        n += wn
        return [n, err]
      })(),
    )
  }
}

function makeSingleStringReplacer(
  pattern: string,
  value: string,
): singleStringReplacer | null {
  return new singleStringReplacer({
    finder: makeStringFinder(pattern),
    value: value,
  })
}

class byteStringReplacer {
  // replacements contains replacement byte slices indexed by old byte.
  // A nil []byte means that the old byte should not be replaced.
  declare public replacements: Uint8Array[]

  // toReplace keeps a list of bytes to replace. Depending on length of toReplace
  // and length of target string it may be faster to use Count, or a plain loop.
  // We store single byte as a string, because Count takes a string.
  declare public toReplace: $.Slice<string>

  constructor(
    init?: Partial<{
      replacements?: Uint8Array[]
      toReplace?: $.Slice<string>
    }>,
  ) {
    this.replacements = init?.replacements ?? [
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
      new Uint8Array(0),
    ]
    this.toReplace = init?.toReplace ?? null
  }

  public clone(): byteStringReplacer {
    const cloned = new byteStringReplacer()
    cloned.replacements = this.replacements
    cloned.toReplace = this.toReplace
    return cloned
  }

  public Replace(s: string): string {
    const r = this
    let newSize = $.len(s)
    let anyChanges = false
    if ($.len(r!.toReplace) * 8 <= $.len(s)) {
      // The -1 is because we are replacing 1 byte with len(replacements[b]) bytes.
      for (let _i = 0; _i < $.len(r!.toReplace); _i++) {
        const x = $.arrayIndex(r!.toReplace!, _i)
        {
          // The -1 is because we are replacing 1 byte with len(replacements[b]) bytes.
          {
            let c = Count(s, x)
            if (c != 0) {
              // The -1 is because we are replacing 1 byte with len(replacements[b]) bytes.
              newSize += c * ($.len(r!.replacements![$.indexString(x, 0)]) - 1)
              anyChanges = true
            }
          }
        }
      }
    } else {
      // See above for explanation of -1
      for (let i = 0; i < $.len(s); i++) {
        let b = $.indexString(s, i)

        // See above for explanation of -1
        if (r!.replacements![b] != null) {
          // See above for explanation of -1
          newSize += $.len(r!.replacements![b]) - 1
          anyChanges = true
        }
      }
    }
    if (!anyChanges) {
      return s
    }
    let buf = new Uint8Array(newSize)
    let j = 0
    for (let i = 0; i < $.len(s); i++) {
      let b = $.indexString(s, i)
      if (r!.replacements![b] != null) {
        j += copy(buf.subarray(j), r!.replacements![b])
      } else {
        buf![j] = b
        j++
      }
    }
    return $.bytesToString(buf)
  }

  public WriteString(w: io.Writer, s: string): io.Awaitable<io.IOResult> {
    const self = this
    return io.runIO(
      (function* (): Generator<
        io.Awaitable<io.IOResult>,
        io.IOResult,
        io.IOResult
      > {
        const r = self
        let sw = getStringWriter(w)
        let last = 0
        let n: number = 0
        let err: $.GoError | null = null
        for (let i = 0; i < $.len(s); i++) {
          let b = $.indexString(s, i)
          if (r!.replacements![b] == null) {
            continue
          }
          if (last != i) {
            let [nw, err] = yield sw!.WriteString($.sliceString(s, last, i))
            n += nw
            if (err != null) {
              return [n, err]
            }
          }
          last = i + 1
          let [nw, err] = yield w!.Write(r!.replacements![b])
          n += nw
          if (err != null) {
            return [n, err]
          }
        }
        if (last != $.len(s)) {
          let [nw, err] = yield sw!.WriteString(
            $.sliceString(s, last, undefined),
          )
          n += nw
          if (err != null) {
            return [n, err]
          }
        }
        return [n, err]
      })(),
    )
  }
}

// Helper function to copy bytes
function copy(dst: Uint8Array, src: Uint8Array): number {
  const n = Math.min(dst.length, src.length)
  for (let i = 0; i < n; i++) {
    dst[i] = src[i]
  }
  return n
}
