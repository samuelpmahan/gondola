// Generated file based on view.go
// Updated when compliance tests are re-run, DO NOT EDIT!

import * as $ from "@goscript/builtin/index.js"
import * as strconv from "@goscript/strconv/index.js"
import * as compilercontract from "@goscript/github.com/samuelpmahan/gondola/compilercontract/index.js"
import * as gobi from "@goscript/github.com/samuelpmahan/gondola/gobi/index.js"
import * as __goscript_app from "./app.gs.ts"
import "./app.gs.ts"

export function View(state: __goscript_app.State): compilercontract.View {
	let bindings: $.Slice<compilercontract.Binding> = $.makeSlice<compilercontract.Binding>(0, $.sliceLen(state.Rows) * 2, undefined, () => new compilercontract.Binding(true))
	let rows = $.makeSlice<gobi.Node>($.sliceLen(state.Rows), undefined, undefined, () => new gobi.Node(true))
	for (let __goscriptRangeTarget0 = state.Rows, __goscriptRangeWindow0 = $.sliceRange(__goscriptRangeTarget0), __goscriptSliceWindow0 = $.sliceRange(rows), index = 0; index < __goscriptRangeWindow0.length; index++) {
		let row = ((__goscriptRangeWindow0.backing[__goscriptRangeWindow0.offset + index] as __goscript_app.Row)).clone()
		let id = strconv.FormatUint(row.ID, 10)
		let input = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("input", null))).Keyed("row-" + id + "-label"))).Set("type", "text"))).Set("value", row.Label))).Set("aria-label", "Row " + id)
		let checked = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("input", null))).Keyed("row-" + id + "-checked"))).Set("type", "checkbox"))).Set("aria-label", "Done " + id)
		if (row.Checked) {
			checked = checked.__goscriptAssign($.markAsStructValue($.cloneStructValue(checked)).Flag("checked"))
		}
		let moveUp = button("row-" + id + "-up", "Up", "move-up/" + id, index == 0)
		let remove = button("row-" + id + "-remove", "Remove", "remove/" + id, false);
		;(__goscriptSliceWindow0.backing as any[])[$.windowSlot(__goscriptSliceWindow0, index)].__goscriptAssign($.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("div", $.arrayToSlice<gobi.Node>([input, checked, moveUp, remove])))).Keyed("row-" + id))).Set("class", "row"))
		bindings = $.appendValues(bindings, undefined, (() => { const __goscriptLiteralField0 = "2/" + strconv.Itoa(index) + "/0"; return new compilercontract.Binding(true, __goscriptLiteralField0, "input", "edit/" + id, compilercontract.TargetValue) })(), (() => { const __goscriptLiteralField1 = "2/" + strconv.Itoa(index) + "/1"; return new compilercontract.Binding(true, __goscriptLiteralField1, "change", "check/" + id, compilercontract.TargetChecked) })())
	}
	let add = button("list-add", "Add", "add", false)
	let reset = button("list-reset", "Reset", "reset", $.sliceLen(state.Rows) == 0)
	let rowList = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("div", rows))).Keyed("rows"))).Set("class", "rows")
	let tree = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("div", $.arrayToSlice<gobi.Node>([add, reset, rowList])))).Keyed("list"))).Set("class", "compiled-list")
	return compilercontract.NewView(tree, bindings)
}

export function button(key: string, label: string, message: string, disabled: boolean): gobi.Node {
	let result = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("button", $.arrayToSlice<gobi.Node>([gobi.Txt(label)])))).Keyed(key))).Handle("click", message, "")
	if (disabled) {
		result = result.__goscriptAssign($.markAsStructValue($.cloneStructValue(result)).Flag("disabled"))
	}
	return result
}
