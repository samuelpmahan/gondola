// Generated file based on json.go
// Updated when compliance tests are re-run, DO NOT EDIT!

import * as $ from "@goscript/builtin/index.js"
import * as bytes from "@goscript/bytes/index.js"
import * as json from "@goscript/encoding/json/index.js"
import * as fmt from "@goscript/fmt/index.js"
import * as io from "@goscript/io/index.js"
import * as reflect from "@goscript/reflect/index.js"
import * as strings from "@goscript/strings/index.js"
import * as utf8 from "@goscript/unicode/utf8/index.js"
import "@goscript/io/index.js"

export async function decodeClosed(data: $.Slice<number>, destination: any): globalThis.Promise<$.GoError> {
	if (((destination == null) || (reflect.ValueOf(destination).Kind() != 22)) || reflect.ValueOf(destination).IsNil()) {
		return fmt.Errorf("destination must be a non-nil pointer")
	}
	{
		let err = validateJSONUnicode(data)
		if (err != null) {
			return err
		}
	}
	let raw: $.VarRef<any> = $.varRef(null! as any)
	let shapeDecoder = json.NewDecoder($.pointerValueOrNil($.interfaceValue<io.Reader | null>(bytes.NewReader(data), "*bytes.Reader", __goscriptStatic0()))!)
	void (shapeDecoder !== null && (shapeDecoder as any).__isVarRef !== true && (shapeDecoder as any).__goValue === undefined ? ((shapeDecoder as any) as json.Decoder).UseNumber() : json.Decoder.prototype.UseNumber.call($.pointerValue<json.Decoder>(shapeDecoder)))
	{
		let err = await (shapeDecoder !== null && (shapeDecoder as any).__isVarRef !== true && (shapeDecoder as any).__goValue === undefined ? ((shapeDecoder as any) as json.Decoder).Decode($.interfaceValue(raw, "*interface{}", /* @__PURE__ */ $.pointerType({ kind: $.TypeKind.Interface, methods: [] }))) : json.Decoder.prototype.Decode.call($.pointerValue<json.Decoder>(shapeDecoder), $.interfaceValue(raw, "*interface{}", /* @__PURE__ */ $.pointerType({ kind: $.TypeKind.Interface, methods: [] }))))
		if (err != null) {
			return err
		}
	}
	let extra: $.VarRef<any> = $.varRef(null! as any)
	{
		let err = await (shapeDecoder !== null && (shapeDecoder as any).__isVarRef !== true && (shapeDecoder as any).__goValue === undefined ? ((shapeDecoder as any) as json.Decoder).Decode($.interfaceValue(extra, "*interface{}", /* @__PURE__ */ $.pointerType({ kind: $.TypeKind.Interface, methods: [] }))) : json.Decoder.prototype.Decode.call($.pointerValue<json.Decoder>(shapeDecoder), $.interfaceValue(extra, "*interface{}", /* @__PURE__ */ $.pointerType({ kind: $.TypeKind.Interface, methods: [] }))))
		if (!$.comparableEqual(err, io.EOF)) {
			if (err == null) {
				return fmt.Errorf("trailing JSON value")
			}
			return err
		}
	}
	{
		let err = await checkJSONShape((__goscriptAwait = $.pointerValue<Exclude<reflect.Type, null>>(reflect.TypeOf(destination)).Elem(), __goscriptAwait instanceof Promise ? await __goscriptAwait : __goscriptAwait), raw.value, "$")
		if (err != null) {
			return err
		}
	}
	let decoder = json.NewDecoder($.pointerValueOrNil($.interfaceValue<io.Reader | null>(bytes.NewReader(data), "*bytes.Reader", __goscriptStatic0()))!)
	void (decoder !== null && (decoder as any).__isVarRef !== true && (decoder as any).__goValue === undefined ? ((decoder as any) as json.Decoder).DisallowUnknownFields() : json.Decoder.prototype.DisallowUnknownFields.call($.pointerValue<json.Decoder>(decoder)))
	{
		let err = await (decoder !== null && (decoder as any).__isVarRef !== true && (decoder as any).__goValue === undefined ? ((decoder as any) as json.Decoder).Decode(destination) : json.Decoder.prototype.Decode.call($.pointerValue<json.Decoder>(decoder), destination))
		if (err != null) {
			return err
		}
	}
	return null
}

export function validateJSONUnicode(data: $.Slice<number>): $.GoError {
	if (!utf8.Valid(data)) {
		return fmt.Errorf("JSON input is not valid UTF-8")
	}
	for (let __goscriptSliceWindow0 = $.sliceRange(data), i = 0; i < __goscriptSliceWindow0.length; i++) {
		if (((__goscriptSliceWindow0.backing as any[])[$.windowSlot(__goscriptSliceWindow0, i)] as number) != 34) {
			continue
		}
		for (i++; (i < __goscriptSliceWindow0.length) && (((__goscriptSliceWindow0.backing as any[])[$.windowSlot(__goscriptSliceWindow0, i)] as number) != 34); i++) {
			if (((__goscriptSliceWindow0.backing as any[])[$.windowSlot(__goscriptSliceWindow0, i)] as number) != 92) {
				continue
			}
			i++
			if (i >= __goscriptSliceWindow0.length) {
				return fmt.Errorf("truncated JSON escape")
			}
			if (((__goscriptSliceWindow0.backing as any[])[$.windowSlot(__goscriptSliceWindow0, i)] as number) != 117) {
				continue
			}
			let [unit, next, err] = readJSONHexUnit(data, i + 1)
			if (err != null) {
				return err
			}
			i = next - 1
			if ((unit >= 0xdc00) && (unit <= 0xdfff)) {
				return fmt.Errorf("JSON contains an unpaired low surrogate")
			}
			if ((unit >= 0xd800) && (unit <= 0xdbff)) {
				if ((((i + 6) >= __goscriptSliceWindow0.length) || (((__goscriptSliceWindow0.backing as any[])[$.windowSlot(__goscriptSliceWindow0, i + 1)] as number) != 92)) || (((__goscriptSliceWindow0.backing as any[])[$.windowSlot(__goscriptSliceWindow0, i + 2)] as number) != 117)) {
					return fmt.Errorf("JSON contains an unpaired high surrogate")
				}
				let [low, end, __goscriptShadow0] = readJSONHexUnit(data, i + 3)
				if (__goscriptShadow0 != null) {
					return __goscriptShadow0
				}
				if ((low < 0xdc00) || (low > 0xdfff)) {
					return fmt.Errorf("JSON contains an unpaired high surrogate")
				}
				i = end - 1
			}
		}
	}
	return null
}

export function readJSONHexUnit(data: $.Slice<number>, start: number): [number, number, $.GoError] {
	if ((start + 4) > $.sliceLen(data)) {
		return [0, start, fmt.Errorf("truncated JSON unicode escape")]
	}
	let value = 0
	for (let __goscriptRangeTarget0 = $.goSlice(data, start, start + 4), __goscriptRangeWindow0 = $.sliceRange(__goscriptRangeTarget0), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow0.length; __rangeIndex++) {
		let char = $.uint((__goscriptRangeWindow0.backing[__goscriptRangeWindow0.offset + __rangeIndex] as number), 8)
		value = $.uint(value << (4), 16)
		switch ((true as boolean)) {
			case (char >= 48) && (char <= 57):
			{
				value |= ($.uint(((char - 48) & 0xff), 8))
				break
			}
			case (char >= 97) && (char <= 102):
			{
				value |= $.uint(((($.uint(((char - 97) & 0xff), 8)) + 10) & 0xffff), 16)
				break
			}
			case (char >= 65) && (char <= 70):
			{
				value |= $.uint(((($.uint(((char - 65) & 0xff), 8)) + 10) & 0xffff), 16)
				break
			}
			default:
			{
				return [0, start, fmt.Errorf("invalid JSON unicode escape")]
				break
			}
		}
	}
	return [value, start + 4, null]
}

export async function checkJSONShape(target: reflect.Type | null, raw: any, path: string): globalThis.Promise<$.GoError> {
	while ((__goscriptAwait = (target !== null && (target as any).__isVarRef !== true && ((target as any).__goValue === undefined || (target as any).__goType?.charCodeAt(0) !== 42) ? (target as Exclude<reflect.Type, null>) : $.pointerValue<Exclude<reflect.Type, null>>(target)).Kind(), __goscriptAwait instanceof Promise ? await __goscriptAwait : __goscriptAwait) == 22) {
		if (raw == null) {
			return null
		}
		target = (__goscriptAwait = (target !== null && (target as any).__isVarRef !== true && ((target as any).__goValue === undefined || (target as any).__goType?.charCodeAt(0) !== 42) ? (target as Exclude<reflect.Type, null>) : $.pointerValue<Exclude<reflect.Type, null>>(target)).Elem(), __goscriptAwait instanceof Promise ? await __goscriptAwait : __goscriptAwait)
	}
	switch ((__goscriptAwait = (target !== null && (target as any).__isVarRef !== true && ((target as any).__goValue === undefined || (target as any).__goType?.charCodeAt(0) !== 42) ? (target as Exclude<reflect.Type, null>) : $.pointerValue<Exclude<reflect.Type, null>>(target)).Kind(), __goscriptAwait instanceof Promise ? await __goscriptAwait : __goscriptAwait)) {
		case reflect.Struct:
		{
			let __goscriptTuple0: any = $.typeAssertTuple<globalThis.Map<string, any> | null>(raw, /* @__PURE__ */ $.mapType(/* @__PURE__ */ $.basicType("string"), { kind: $.TypeKind.Interface, methods: [] }))
			let _object: globalThis.Map<string, any> | null = __goscriptTuple0[0]
			let ok: boolean = __goscriptTuple0[1]
			if (!ok) {
				return fmt.Errorf("%s must be an object", path)
			}
			let known = $.makeMap<string, reflect.StructField>()
			for (let i = 0; i < (__goscriptAwait = (target !== null && (target as any).__isVarRef !== true && ((target as any).__goValue === undefined || (target as any).__goType?.charCodeAt(0) !== 42) ? (target as Exclude<reflect.Type, null>) : $.pointerValue<Exclude<reflect.Type, null>>(target)).NumField(), __goscriptAwait instanceof Promise ? await __goscriptAwait : __goscriptAwait); i++) {
				let field = $.markAsStructValue($.cloneStructValue(((__goscriptAwait = (target !== null && (target as any).__isVarRef !== true && ((target as any).__goValue === undefined || (target as any).__goType?.charCodeAt(0) !== 42) ? (target as Exclude<reflect.Type, null>) : $.pointerValue<Exclude<reflect.Type, null>>(target)).Field(i), __goscriptAwait instanceof Promise ? await __goscriptAwait : __goscriptAwait) as reflect.StructField)))
				if (!$.stringEqual(field.PkgPath, "")) {
					continue
				}
				let [name, options, skip] = jsonFieldName(field)
				if (skip) {
					continue
				}
				$.mapSet(known, name, $.markAsStructValue($.cloneStructValue(field)))
				let [value, exists] = $.mapGet<string, any, any>(_object, name, null)
				if (!exists && !strings.Contains(options, "omitempty")) {
					return fmt.Errorf("%s.%s is required", path, name)
				}
				if (exists) {
					{
						let err = await checkJSONShape(field.Type, value, path + "." + name)
						if (err != null) {
							return err
						}
					}
				}
			}
			for (const [name, __rangeValue] of _object?.entries() ?? []) {
				{
					let [, __goscriptShadow1] = $.mapGet<string, reflect.StructField, reflect.StructField>(known, name, $.markAsStructValue(new reflect.StructField()))
					if (!__goscriptShadow1) {
						return fmt.Errorf("%s has unknown field %q", path, name)
					}
				}
			}
			break
		}
		case reflect.Slice:
		case reflect.Array:
		{
			if ((raw == null) && ((__goscriptAwait = (target !== null && (target as any).__isVarRef !== true && ((target as any).__goValue === undefined || (target as any).__goType?.charCodeAt(0) !== 42) ? (target as Exclude<reflect.Type, null>) : $.pointerValue<Exclude<reflect.Type, null>>(target)).Kind(), __goscriptAwait instanceof Promise ? await __goscriptAwait : __goscriptAwait) == 23)) {
				return null
			}
			let __goscriptTuple1: any = $.typeAssertTuple<$.Slice<any>>(raw, /* @__PURE__ */ $.sliceType({ kind: $.TypeKind.Interface, methods: [] }))
			let items: $.Slice<any> = __goscriptTuple1[0]
			let ok: boolean = __goscriptTuple1[1]
			if (!ok) {
				return fmt.Errorf("%s must be an array", path)
			}
			if (((__goscriptAwait = (target !== null && (target as any).__isVarRef !== true && ((target as any).__goValue === undefined || (target as any).__goType?.charCodeAt(0) !== 42) ? (target as Exclude<reflect.Type, null>) : $.pointerValue<Exclude<reflect.Type, null>>(target)).Kind(), __goscriptAwait instanceof Promise ? await __goscriptAwait : __goscriptAwait) == 17) && ($.sliceLen(items) != (__goscriptAwait = (target !== null && (target as any).__isVarRef !== true && ((target as any).__goValue === undefined || (target as any).__goType?.charCodeAt(0) !== 42) ? (target as Exclude<reflect.Type, null>) : $.pointerValue<Exclude<reflect.Type, null>>(target)).Len(), __goscriptAwait instanceof Promise ? await __goscriptAwait : __goscriptAwait))) {
				return fmt.Errorf("%s must have %d items", path, $.basicInterfaceValue((__goscriptAwait = (target !== null && (target as any).__isVarRef !== true && ((target as any).__goValue === undefined || (target as any).__goType?.charCodeAt(0) !== 42) ? (target as Exclude<reflect.Type, null>) : $.pointerValue<Exclude<reflect.Type, null>>(target)).Len(), __goscriptAwait instanceof Promise ? await __goscriptAwait : __goscriptAwait), "int"))
			}
			for (let __goscriptRangeTarget1 = items, __goscriptRangeWindow1 = $.sliceRange(__goscriptRangeTarget1), i = 0; i < __goscriptRangeWindow1.length; i++) {
				let item = (__goscriptRangeWindow1.backing[__goscriptRangeWindow1.offset + i] as any)
				{
					let err = await checkJSONShape((__goscriptAwait = (target !== null && (target as any).__isVarRef !== true && ((target as any).__goValue === undefined || (target as any).__goType?.charCodeAt(0) !== 42) ? (target as Exclude<reflect.Type, null>) : $.pointerValue<Exclude<reflect.Type, null>>(target)).Elem(), __goscriptAwait instanceof Promise ? await __goscriptAwait : __goscriptAwait), item, (fmt.Sprintf("%s[%d]", path, $.basicInterfaceValue(i, "int")) as string))
					if (err != null) {
						return err
					}
				}
			}
			break
		}
		case reflect.Map:
		{
			if (raw == null) {
				return null
			}
			let __goscriptTuple2: any = $.typeAssertTuple<globalThis.Map<string, any> | null>(raw, /* @__PURE__ */ $.mapType(/* @__PURE__ */ $.basicType("string"), { kind: $.TypeKind.Interface, methods: [] }))
			let _object: globalThis.Map<string, any> | null = __goscriptTuple2[0]
			let ok: boolean = __goscriptTuple2[1]
			if (!ok) {
				return fmt.Errorf("%s must be an object", path)
			}
			for (const [key, item] of _object?.entries() ?? []) {
				{
					let err = await checkJSONShape((__goscriptAwait = (target !== null && (target as any).__isVarRef !== true && ((target as any).__goValue === undefined || (target as any).__goType?.charCodeAt(0) !== 42) ? (target as Exclude<reflect.Type, null>) : $.pointerValue<Exclude<reflect.Type, null>>(target)).Elem(), __goscriptAwait instanceof Promise ? await __goscriptAwait : __goscriptAwait), item, path + "." + key)
					if (err != null) {
						return err
					}
				}
			}
			break
		}
	}
	return null
}

export function jsonFieldName(field: reflect.StructField): [string, string, boolean] {
	let name = ""
	let options = ""
	let skip = false
	let tag = reflect.StructTag_Get(field.Tag, "json")
	if ($.stringEqual(tag, "-")) {
		return ["", "", true]
	}
	let parts = strings.Split(tag, ",")
	name = $.plainSliceIndex(parts!, 0)
	if ($.stringEqual(name, "")) {
		name = field.Name
	}
	if ($.sliceLen(parts) > 1) {
		options = "," + strings.Join($.goSlice(parts, 1, undefined), ",")
	}
	return [name, options, false]
}

var __goscriptStatic0$value: any
function __goscriptStatic0(): any {
	return __goscriptStatic0$value ??= ($.overrideTypeMethods(/* @__PURE__ */ $.pointerType("bytes.Reader"), "bytes.Reader", () => [$.methodSignature("Len", [], [/* @__PURE__ */ $.basicType("int")], true), $.methodSignature("Read", [["b", /* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("uint8"))]], [["n", /* @__PURE__ */ $.basicType("int")], ["err", "error"]], true), $.methodSignature("ReadAt", [["b", /* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("uint8"))], ["off", /* @__PURE__ */ $.basicType("int64")]], [["n", /* @__PURE__ */ $.basicType("int")], ["err", "error"]], true), $.methodSignature("ReadByte", [], [/* @__PURE__ */ $.basicType("uint8"), "error"], true), $.methodSignature("ReadRune", [], [["ch", /* @__PURE__ */ $.basicType("int32")], ["size", /* @__PURE__ */ $.basicType("int")], ["err", "error"]], true), $.methodSignature("Reset", [["b", /* @__PURE__ */ $.sliceType(/* @__PURE__ */ $.basicType("uint8"))]], [], true), $.methodSignature("Seek", [["offset", /* @__PURE__ */ $.basicType("int64")], ["whence", /* @__PURE__ */ $.basicType("int")]], [/* @__PURE__ */ $.basicType("int64"), "error"], true), $.methodSignature("Size", [], [/* @__PURE__ */ $.basicType("int64")], true), $.methodSignature("UnreadByte", [], ["error"], true), $.methodSignature("UnreadRune", [], ["error"], true), $.methodSignature("WriteTo", [["w", "io.Writer"]], [["n", /* @__PURE__ */ $.basicType("int64")], ["err", "error"]], true)]))
}

var __goscriptAwait: any
