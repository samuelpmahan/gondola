// Generated file based on forwarder.go
// Updated when compliance tests are re-run, DO NOT EDIT!

import * as $ from "@goscript/builtin/index.js"
import * as gobiType0 from "@goscript/github.com/samuelpmahan/gondola/compilercontract/index.js"
import * as gobiApp from "@goscript/github.com/samuelpmahan/gondola/fixtures/compiled/form/index.js"
import * as gobiType1 from "@goscript/github.com/samuelpmahan/gondola/gobi/index.js"
import "@goscript/github.com/samuelpmahan/gondola/compilercontract/index.js"
import "@goscript/github.com/samuelpmahan/gondola/gobi/index.js"

export function GobiCompiledInit(): gobiApp.State {
	return gobiApp.Init()
}

export function GobiCompiledUpdate(state: gobiApp.State, message: gobiType1.Message): [gobiApp.State, $.Slice<gobiType1.Effect>] {
	return gobiApp.Update((state).clone(), message)
}

export function GobiCompiledView(state: gobiApp.State): gobiType0.View {
	return gobiApp.View(state)
}
