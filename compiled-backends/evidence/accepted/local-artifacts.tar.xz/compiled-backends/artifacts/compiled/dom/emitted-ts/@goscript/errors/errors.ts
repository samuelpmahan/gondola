import * as $ from '@goscript/builtin/index.js'

// New returns an error that formats as the given text.
// Each call to New returns a distinct error value even if the text is identical.
export function New(text: string): $.GoError {
  return $.newError(text)
}

export function Errorf(format: string, ...args: any[]): $.GoError {
  return New(formatText(format, args))
}

export function Wrap(err: $.GoError, message: string): $.GoError {
  if (err === null) {
    return null
  }
  return wrapError(err, message)
}

export function Wrapf(
  err: $.GoError,
  format: string,
  ...args: any[]
): $.GoError {
  if (err === null) {
    return null
  }
  return wrapError(err, formatText(format, args))
}

function wrapError(err: Exclude<$.GoError, null>, message: string): $.GoError {
  // err.Error() may be async, so the wrapper resolves it lazily instead of
  // interpolating a possible Promise into the message.
  const wrapped: Exclude<$.GoError, null> = {
    Error: (): string | PromiseLike<string> => {
      const inner = err.Error()
      if (typeof inner === 'string') {
        return `${message}: ${inner}`
      }
      return Promise.resolve(inner).then((text) => `${message}: ${text}`)
    },
  }
  ;(wrapped as any).Unwrap = function (): $.GoError {
    return err
  }
  return wrapped
}

function formatText(format: string, args: any[]): string {
  let argIndex = 0
  return format.replace(/%[sdqv%]/g, (match) => {
    if (match === '%%') {
      return '%'
    }
    if (argIndex >= args.length) {
      return match
    }
    const arg = args[argIndex++]
    switch (match) {
      case '%d':
        return String(Number(arg))
      case '%q':
        return JSON.stringify(String(arg))
      default:
        return String(arg)
    }
  })
}

// ErrUnsupported indicates that a requested operation cannot be performed,
// because it is unsupported. For example, a call to os.Link when using a
// file system that does not support hard links.
//
// Functions and methods should not return this error but should instead
// return an error including appropriate context that satisfies
//
//	errors.Is(err, errors.ErrUnsupported)
//
// either by directly wrapping ErrUnsupported or by implementing an Is method.
export const ErrUnsupported = New('unsupported operation')

// Unwrap returns the result of calling the Unwrap method on err, if err's
// type contains an Unwrap method returning error.
// Otherwise, Unwrap returns nil.
export function Unwrap(err: $.GoError): $.GoError {
  if (err === null) {
    return null
  }

  // Check if the error has an Unwrap method
  if (typeof (err as any).Unwrap === 'function') {
    const result = (err as any).Unwrap()
    if (result && typeof result.Error === 'function') {
      return result
    }
    // Handle case where Unwrap returns []error
    if ($.isArrayOrGoSlice(result) && $.len(result) > 0) {
      const first = $.arrayIndex(result, 0) as $.GoError
      if (first && typeof (first as { Error?: unknown }).Error === 'function') {
        return first
      }
    }
  }

  return null
}

// Is reports whether any error in err's tree matches target.
//
// The tree consists of err itself, followed by the errors obtained by repeatedly
// calling Unwrap. When err wraps multiple errors, Is examines err followed by a
// depth-first traversal of its children.
//
// An error is considered to match a target if it is equal to that target or if
// it implements a method Is(error) bool such that Is(target) returns true.
//
// An error type might provide an Is method so it can be treated as equivalent
// to an existing error. For example, if MyError defines
//
//	func (m MyError) Is(target error) bool { return target == fs.ErrExist }
//
// then Is(MyError{}, fs.ErrExist) returns true. See syscall.Errno.Is for
// an example in the standard library. An Is method should only shallowly
// compare err and the target and not call Unwrap on either.
export function Is(err: $.GoError, target: $.GoError): boolean {
  if (target === null) {
    return err === null
  }

  if (err === null) {
    return false
  }

  return isInTree(err, target, isTargetComparable(target))
}

// isTargetComparable reports whether target's dynamic type supports ==, matching
// the standard library's reflectlite.TypeOf(target).Comparable() gate. A boxed
// named value carries its dynamic type descriptor; errors.New pointers and other
// untyped error objects carry none and are comparable by identity.
function isTargetComparable(target: Exclude<$.GoError, null>): boolean {
  const typeInfo =
    (
      typeof target === 'object' &&
      target !== null &&
      '__goTypeInfo' in target &&
      (typeof target.__goTypeInfo === 'string' ||
        isTypeInfo(target.__goTypeInfo))
    ) ?
      target.__goTypeInfo
    : undefined
  if (typeInfo === undefined) {
    return !$.isNamedValueBox(target) && !$.isTypedNilValue(target)
  }
  if (typeof typeInfo === 'string' && $.getTypeByName(typeInfo) === undefined) {
    return false
  }
  return $.isTypeInfoComparable(typeInfo)
}

function isTypeInfo(value: unknown): value is $.TypeInfo {
  if (typeof value !== 'object' || value === null || !('kind' in value)) {
    return false
  }
  switch (value.kind) {
    case $.TypeKind.Basic:
    case $.TypeKind.Map:
    case $.TypeKind.Slice:
    case $.TypeKind.Pointer:
    case $.TypeKind.Function:
    case $.TypeKind.Channel:
      return true
    case $.TypeKind.Struct:
      return 'fields' in value && $.isArrayOrGoSlice(value.fields)
    case $.TypeKind.Interface:
      return 'methods' in value && $.isArrayOrGoSlice(value.methods)
    default:
      return false
  }
}

// isInTree walks err's tree looking for target, carrying target's precomputed
// comparability so it is decided once, as in the standard library's
// is(err, target, targetComparable).
function isInTree(
  err: Exclude<$.GoError, null>,
  target: Exclude<$.GoError, null>,
  targetComparable: boolean,
): boolean {
  // Go compares err against target with == only when target's dynamic type is
  // comparable, then matches on equal dynamic type and equal underlying value.
  // comparableEqual is the runtime's interface-== implementation: two distinct
  // errors.New values stay unequal *errorString pointers, while two separately
  // boxed comparable named values (e.g. a named string error) with the same
  // dynamic type and value compare equal. Uncomparable targets are never
  // compared, matching the standard library and never risking a panic.
  if (targetComparable && $.comparableEqual(err, target)) {
    return true
  }

  // An error may declare equivalence to target via an Is method.
  if (typeof (err as any).Is === 'function') {
    if ((err as any).Is(target)) {
      return true
    }
  }

  // Depth-first traversal of the wrap tree. A single-error Unwrap recurses into
  // its child; an Unwrap returning []error (errors.Join) visits every child, so
  // a target in any position matches, not just the first.
  if (typeof (err as any).Unwrap === 'function') {
    const result = (err as any).Unwrap()
    if ($.isArrayOrGoSlice(result)) {
      for (const wrappedErr of result) {
        if (
          wrappedErr !== null &&
          isInTree(wrappedErr, target, targetComparable)
        ) {
          return true
        }
      }
    } else if (result !== null && typeof result?.Error === 'function') {
      return isInTree(result, target, targetComparable)
    }
  }

  return false
}

// As finds the first error in err's tree that matches target, and if one is found,
// sets target to that error value and returns true. Otherwise, it returns false.
//
// The tree consists of err itself, followed by the errors obtained by repeatedly
// calling Unwrap. When err wraps multiple errors, As examines err followed by a
// depth-first traversal of its children.
//
// An error matches target if the error's concrete value is assignable to the value
// pointed to by target, or if the error has a method As(interface{}) bool such that
// As(target) returns true. In the latter case, the As method is responsible for
// setting target.
//
// An error type might provide an As method so it can be treated as if it were a
// different error type.
//
// As panics if target is not a non-nil pointer to either a type that implements
// error, or to any interface type.
export function As(err: $.GoError, target: any): boolean {
  if (err === null) {
    return false
  }

  if (target === null || typeof target !== 'object') {
    throw new Error('errors: target cannot be nil')
  }

  if (assignAsTarget(err, target)) {
    return true
  }

  // Check if err has an As method
  if (typeof (err as any).As === 'function') {
    if ((err as any).As(target)) {
      return true
    }
  }

  // Depth-first traversal of the wrap tree, matching errors.Is: a single-error
  // Unwrap recurses into its child; an Unwrap returning []error visits every
  // child so a match in any position is found.
  if (typeof (err as any).Unwrap === 'function') {
    const result = (err as any).Unwrap()
    if ($.isArrayOrGoSlice(result)) {
      for (const wrappedErr of result) {
        if (wrappedErr !== null && As(wrappedErr, target)) {
          return true
        }
      }
    } else if (result !== null && typeof result?.Error === 'function') {
      return As(result, target)
    }
  }

  return false
}

function assignAsTarget(err: Exclude<$.GoError, null>, target: any): boolean {
  const targetType = asTargetType(target)
  if (targetType !== undefined) {
    const [matched, ok] = $.typeAssertTuple<any>(err, targetType)
    if (!ok) {
      return false
    }
    const destination = $.isNamedValueBox(target) ? target.__goValue : target
    if ($.isVarRef(destination)) {
      destination.value = matched
      return true
    }
    Object.assign(destination, matched)
    return true
  }

  if (err.constructor === target.constructor) {
    Object.assign(target, err)
    return true
  }
  return false
}

// asTargetType returns the type an As target points to. The pointer's type
// info describes unnamed targets such as interface{ StatusCode() int }, whose
// type name is not registered.
function asTargetType(target: any): $.TypeInfo | string | undefined {
  const typeInfo = target?.__goTypeInfo
  if (
    typeInfo !== undefined &&
    typeof typeInfo !== 'string' &&
    $.isPointerTypeInfo(typeInfo)
  ) {
    return typeInfo.elemType
  }
  const goType = target?.__goType
  if (typeof goType !== 'string' || !goType.startsWith('*')) {
    return undefined
  }
  return goType.slice(1)
}

// AsType finds the first error in err's tree that matches the generic error
// type E, returning the matching error and true. Otherwise it returns E's zero
// value and false.
export function AsType(
  typeArgs: $.GenericTypeArgs | undefined,
  err: $.GoError,
): [any, boolean] {
  const descriptor = typeArgs?.E
  const zero = (): any => descriptor?.zero?.() ?? null
  if (err === null || descriptor?.type === undefined) {
    return [zero(), false]
  }
  return asType(err, descriptor.type, zero)
}

function asType(
  err: $.GoError,
  typeInfo: $.TypeInfo | string,
  zero: () => any,
): [any, boolean] {
  if (err === null) {
    return [zero(), false]
  }

  const [asserted, ok] = $.typeAssertTuple<any>(err, typeInfo)
  if (ok) {
    return [asserted, true]
  }

  if (typeof (err as any).Unwrap === 'function') {
    const result = (err as any).Unwrap()
    if ($.isArrayOrGoSlice(result)) {
      for (const wrappedErr of result) {
        if (wrappedErr && typeof wrappedErr.Error === 'function') {
          const [matched, matchedOK] = asType(wrappedErr, typeInfo, zero)
          if (matchedOK) {
            return [matched, true]
          }
        }
      }
      return [zero(), false]
    }
    if (result && typeof result.Error === 'function') {
      return asType(result, typeInfo, zero)
    }
  }

  return [zero(), false]
}

// Join returns an error that wraps the given errors.
// Any nil error values are discarded.
// Join returns nil if every value in errs is nil.
// The error formats as the concatenation of the strings obtained
// by calling the Error method of each element of errs, with a newline
// between each string.
//
// A non-nil error returned by Join implements the Unwrap() []error method.
export function Join(...errs: $.GoError[]): $.GoError {
  const nonNilErrs = errs.filter((err) => err !== null)

  if (nonNilErrs.length === 0) {
    return null
  }

  if (nonNilErrs.length === 1) {
    return nonNilErrs[0]
  }

  // Each element's Error() may be async, so the joined message resolves the
  // elements when Error is called instead of interpolating Promises here.
  const joinedError: Exclude<$.GoError, null> = {
    Error: (): string | PromiseLike<string> => {
      const messages = nonNilErrs.map((err) => err!.Error())
      if (messages.every((message) => typeof message === 'string')) {
        return (messages as string[]).join('\n')
      }
      return Promise.all(
        messages.map((message) => Promise.resolve(message)),
      ).then((resolved) => resolved.join('\n'))
    },
  }

  // Add Unwrap method that returns the array of errors
  ;(joinedError as any).Unwrap = function (): $.GoError[] {
    return nonNilErrs
  }

  return joinedError
}
