// Generated file based on app.go
// Updated when compliance tests are re-run, DO NOT EDIT!

import * as $ from "@goscript/builtin/index.js"
import * as gobi from "@goscript/github.com/samuelpmahan/gondola/gobi/index.js"

$.registerTypePackagePath("github.com/samuelpmahan/gondola/fixtures/compiled/effect", ["effect.State"])

export class State {
	public declare Input: string

	public declare Value: string

	public declare Status: string

	public declare Pending: boolean

	public declare Requests: number

	public declare Completions: number

	public declare NegativeZero: number

	constructor(__goscriptValue?: boolean, Input$?: string, Value$?: string, Status$?: string, Pending$?: boolean, Requests$?: number, Completions$?: number, NegativeZero$?: number) {
		this.Input = Input$ ?? ""
		this.Value = Value$ ?? ""
		this.Status = Status$ ?? ""
		this.Pending = Pending$ ?? false
		this.Requests = Requests$ ?? 0
		this.Completions = Completions$ ?? 0
		this.NegativeZero = NegativeZero$ ?? 0
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): State {
		return new State(true, this.Input, this.Value, this.Status, this.Pending, this.Requests, this.Completions, this.NegativeZero)
	}

	public __goscriptAssign(source: State): this {
		this.Input = source.Input
		this.Value = source.Value
		this.Status = source.Status
		this.Pending = source.Pending
		this.Requests = source.Requests
		this.Completions = source.Completions
		this.NegativeZero = source.NegativeZero
		return this
	}

	static __typeInfo = $.registerStructType(
		"effect.State",
		() => new State(),
		() => [],
		State,
		() => [/* @__PURE__ */ $.structField("Input", /* @__PURE__ */ $.basicType("string"), [0], 0, true), /* @__PURE__ */ $.structField("Value", /* @__PURE__ */ $.basicType("string"), [1], 16, true), /* @__PURE__ */ $.structField("Status", /* @__PURE__ */ $.basicType("string"), [2], 32, true), /* @__PURE__ */ $.structField("Pending", /* @__PURE__ */ $.basicType("bool"), [3], 48, true), /* @__PURE__ */ $.structField("Requests", /* @__PURE__ */ $.basicType("int"), [4], 56, true), /* @__PURE__ */ $.structField("Completions", /* @__PURE__ */ $.basicType("int"), [5], 64, true), /* @__PURE__ */ $.structField("NegativeZero", /* @__PURE__ */ $.basicType("float64"), [6], 72, true)]
	)
}

export function Init(): State {
	let negative = -1.0
	let zero = 0.0
	return new State(true, undefined, undefined, "idle", undefined, undefined, undefined, negative * zero)
}

export function Update(state: State, message: gobi.Message): [State, $.Slice<gobi.Effect>] {
	switch (message.Name) {
		case "edit":
		{
			state.Input = message.Arg
			break
		}
		case "request":
		{
			if ((!state.Pending && (!$.stringEqual(state.Input, ""))) && (state.Requests < 9007199254740991)) {
				state.Pending = true
				state.Status = "pending"
				state.Requests++
				return [(state).clone(), $.arrayToSlice<gobi.Effect>([new gobi.Effect(true, "fixture.request", "lookup", state.Input, "complete")])]
			}
			break
		}
		case "complete":
		{
			if (state.Pending && (state.Completions < 9007199254740991)) {
				state.Pending = false
				state.Status = "complete"
				state.Value = message.Arg
				state.Completions++
			}
			break
		}
	}
	return [state, null]
}
