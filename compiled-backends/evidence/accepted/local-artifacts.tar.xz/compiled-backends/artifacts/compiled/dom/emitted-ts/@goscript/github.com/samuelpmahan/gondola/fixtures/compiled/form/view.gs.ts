// Generated file based on view.go
// Updated when compliance tests are re-run, DO NOT EDIT!

import * as $ from "@goscript/builtin/index.js"
import * as strconv from "@goscript/strconv/index.js"
import * as compilercontract from "@goscript/github.com/samuelpmahan/gondola/compilercontract/index.js"
import * as gobi from "@goscript/github.com/samuelpmahan/gondola/gobi/index.js"
import * as __goscript_app from "./app.gs.ts"

export function View(state: __goscript_app.State): compilercontract.View {
	let text = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("input", null))).Keyed("form-draft"))).Set("type", "text"))).Set("value", state.Draft))).Set("aria-label", "Draft")
	let checked = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("input", null))).Keyed("form-checked"))).Set("type", "checkbox"))).Set("aria-label", "Checked")
	if (state.Checked) {
		checked = checked.__goscriptAssign($.markAsStructValue($.cloneStructValue(checked)).Flag("checked"))
	}
	let literal = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("button", $.arrayToSlice<gobi.Node>([gobi.Txt("Literal argument")])))).Keyed("form-literal"))).Handle("click", "literal", "target.value")
	let save = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("button", $.arrayToSlice<gobi.Node>([gobi.Txt("Save")])))).Keyed("form-save"))).Handle("click", "save", "")
	if ($.stringEqual(state.Draft, "")) {
		save = save.__goscriptAssign($.markAsStructValue($.cloneStructValue(save)).Flag("disabled"))
	}
	let reset = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("button", $.arrayToSlice<gobi.Node>([gobi.Txt("Reset")])))).Keyed("form-reset"))).Handle("click", "reset", "")
	if ($.structEqual(state, (new __goscript_app.State(true)))) {
		reset = reset.__goscriptAssign($.markAsStructValue($.cloneStructValue(reset)).Flag("disabled"))
	}
	let boundary = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("button", $.arrayToSlice<gobi.Node>([gobi.Txt("Boundary")])))).Keyed("form-boundary"))).Handle("click", "boundary", "")
	let tree = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("div", $.arrayToSlice<gobi.Node>([text, checked, literal, gobi.El("p", $.arrayToSlice<gobi.Node>([gobi.Txt("Saved: "), gobi.Txt(state.Saved)])), gobi.El("p", $.arrayToSlice<gobi.Node>([gobi.Txt("Saves: "), gobi.Txt(strconv.Itoa(state.Saves))])), gobi.El("p", $.arrayToSlice<gobi.Node>([gobi.Txt("Literal: "), gobi.Txt(state.Literal)])), save, reset, boundary])))).Keyed("form"))).Set("class", "compiled-form")
	return compilercontract.NewView(tree, $.arrayToSlice<compilercontract.Binding>([new compilercontract.Binding(true, "0", "input", "edit", compilercontract.TargetValue), new compilercontract.Binding(true, "1", "change", "checked", compilercontract.TargetChecked)]))
}
