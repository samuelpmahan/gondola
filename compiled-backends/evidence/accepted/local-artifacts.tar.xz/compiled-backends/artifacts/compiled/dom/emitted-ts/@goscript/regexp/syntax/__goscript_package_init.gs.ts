import "@goscript/unicode/index.js"
import "@goscript/strconv/index.js"
import "@goscript/sort/index.js"
import "@goscript/strings/index.js"
import "@goscript/sync/index.js"
import "@goscript/unicode/utf8/index.js"
import "@goscript/slices/index.js"
import * as __goscript_file0 from "./perl_groups.gs.ts"

let initialized = false

export async function __goscript_package_init(): globalThis.Promise<void> {
	if (initialized) {
		return
	}
	initialized = true
	__goscript_file0.__goscript_init_perlGroup()
	__goscript_file0.__goscript_init_posixGroup()
}
