
import { mountCompiledApp, createDeterministicEffectHost } from "/workspace/scratch/39a56936f173/gondola-backends/compiled-frontend/frontend/runtime/runtime.mjs";
import { createReactRenderer } from "/workspace/scratch/39a56936f173/gondola-backends/compiled-frontend/frontend/react/renderer.mjs";
import { createDOMRenderer } from "/workspace/scratch/39a56936f173/gondola-backends/compiled-frontend/frontend/dom/renderer.mjs";
import { associateObservedAction } from "/workspace/scratch/39a56936f173/gondola-backends/compiled-frontend/conformance/observed-action.mjs";
import { gobiCompiled } from "/workspace/scratch/39a56936f173/gondola-backends/compiled-backends/artifacts/compiled/react/apps/counter-b05e9eb0e4e6/gobi-compiled.mjs";
import * as encoder from "/workspace/scratch/39a56936f173/gondola-backends/compiled-backends/artifacts/compiled/react/apps/counter-b05e9eb0e4e6/encoder.mjs";

let activeIntent = null;
let instance = null;
let nextRendererId = 0;
const rendererRecords = [];
const counters = { dispatch: 0, stale: 0 };
const observations = { dispatch: [], stale: [], requests: [] };
let physicalObserverInstalled = false;

function copy(value) { return structuredClone(value); }

function associate(observed) {
  if (activeIntent === null) throw new Error("renderer callback arrived without a requested Action intent");
  return associateObservedAction(observed, activeIntent);
}

function makeRenderer(backend, strictMode = false) {
  let core;
  if (backend === "react") core = createReactRenderer({ container: document.getElementById("app"), strictMode });
  else if (backend === "dom") core = createDOMRenderer({ container: document.getElementById("app") });
  else throw new TypeError("renderer backend must be react or dom");
  const record = { id: ++nextRendererId, backend, core, hooks: [], rendererCallbacks: [], lastDispatchMessage: null };
  const renderer = {
    update(view, hooks) {
      record.hooks.push(hooks);
      const callbacks = {
        dispatch(observed, message) {
          counters.dispatch += 1;
          record.lastDispatchMessage = message;
          const action = associate(observed);
          observations.dispatch.push({ rendererId: record.id, observed: copy(observed), action, message: copy(message) });
          return hooks.dispatch(action, message);
        },
        onStaleAction(observed, renderEpoch) {
          counters.stale += 1;
          const action = associate(observed);
          observations.stale.push({ rendererId: record.id, observed: copy(observed), action, renderEpoch });
          return hooks.onStaleAction(action, renderEpoch);
        },
      };
      record.rendererCallbacks.push(callbacks);
      return core.update(view, callbacks);
    },
    viewRecord: (...args) => core.viewRecord(...args),
    domSnapshot: (...args) => core.domSnapshot(...args),
    focusState: (...args) => core.focusState?.(...args) ?? null,
    restoreFocus: (...args) => core.restoreFocus?.(...args) ?? false,
    unmount: (...args) => core.unmount(...args),
    record,
  };
  record.renderer = renderer;
  rendererRecords.push(record);
  return renderer;
}

function requireInstance() {
  if (!instance) throw new Error("conformance app has not mounted");
  return instance;
}

window.__gobiBackendConformance = {
  compiled: gobiCompiled,
  mount({ fixtureScript, componentId, backend, strictMode = false }) {
    const container = document.getElementById("app");
    if (!container) throw new Error("#app container is missing");
    if (physicalObserverInstalled) {
      counters.dispatch = 0;
      counters.stale = 0;
      for (const list of Object.values(observations)) list.length = 0;
      rendererRecords.length = 0;
      nextRendererId = 0;
    } else {
      for (const eventName of ["input", "change", "click"]) container.addEventListener(eventName, (event) => {
        if (activeIntent === null || !event.target) return;
        const target = event.target;
        observations.physical.push({ intent: copy(activeIntent), event: event.type,
          value: target.type === "checkbox" ? String(target.checked) : (typeof target.value === "string" ? target.value : ""),
          tag: target.localName ?? "" });
      }, true);
      physicalObserverInstalled = true;
      observations.physical = [];
    }
    const renderer = makeRenderer(backend, strictMode);
    let runtime = null;
    const host = createDeterministicEffectHost(fixtureScript.hostScript, {
      onRequest(request) {
        if (!runtime) throw new Error("effect requested before runtime mount completed");
        observations.requests.push({ request: copy(request), snapshot: runtime.snapshot(), tickCount: runtime.trace().ticks.length });
      },
    });
    runtime = mountCompiledApp({
      module: gobiCompiled,
      componentId,
      appId: componentId,
      encoder: { gobiEncodeState: encoder.gobiEncodeState },
      renderer,
      effectHost: host,
    });
    instance = { runtime, renderer, host, fixtureScript, componentId, strictMode };
    return { ticks: runtime.trace().ticks.length, backend, componentId };
  },
  setIntent(action) { activeIntent = copy(action); },
  clearIntent() { activeIntent = null; },
  trace() { return requireInstance().runtime.trace(); },
  snapshot() { return requireInstance().runtime.snapshot(); },
  failure() { return requireInstance().runtime.failure(); },
  dispatchSuppressed(action) { return requireInstance().runtime.dispatch(action, null); },
  deliverNext() { return requireInstance().host.deliverNext(); },
  deliver(requestKey) { return requireInstance().host.deliver(requestKey); },
  hostDone() { return requireInstance().host.assertDone(); },
  hostRequests() { return requireInstance().host.requests(); },
  hostCompletions() { return requireInstance().host.completions(); },
  duplicateCompletion(completion) { return requireInstance().runtime.complete(completion); },
  callbacks() { return copy(counters); },
  observations() { return copy(observations); },
  physicalActions() { return copy(observations.physical); },
  rendererDiagnostics() { return requireInstance().runtime.rendererDiagnostics(); },
  focusState() { return requireInstance().renderer.focusState(); },
  currentRenderer() { return { id: requireInstance().renderer.record.id, backend: requireInstance().renderer.record.backend }; },
  swap(backend) {
    const current = requireInstance();
    const previous = current.renderer;
    const before = {
      trace: current.runtime.trace(),
      snapshot: current.runtime.snapshot(),
      hostRequests: current.host.requests(),
      hostCompletions: current.host.completions(),
      diagnostics: current.runtime.rendererDiagnostics(),
      focus: previous.focusState(),
      renderer: { id: previous.record.id, backend: previous.record.backend },
    };
    const oldRoot = document.getElementById("app").firstElementChild;
    const container = document.getElementById("app");
    const initialChildren = container.childNodes.length;
    const mutationObserver = new MutationObserver(() => {});
    mutationObserver.observe(container, { childList: true });
    const oldFocusedElement = before.focus === null ? null : document.activeElement;
    const next = makeRenderer(backend, current.strictMode);
    const returnedSnapshot = current.runtime.replaceRenderer(next);
    current.renderer = next;
    const mutations = mutationObserver.takeRecords();
    mutationObserver.disconnect();
    let observedChildren = initialChildren;
    let oldRootRemoved = false;
    let newRootAdded = false;
    let emptyAfterOldRemoval = false;
    for (const mutation of mutations) {
      if ([...mutation.removedNodes].includes(oldRoot)) oldRootRemoved = true;
      if ([...mutation.addedNodes].includes(container.firstElementChild)) newRootAdded = true;
      observedChildren -= mutation.removedNodes.length;
      observedChildren += mutation.addedNodes.length;
      if (oldRootRemoved && observedChildren === 0) emptyAfterOldRemoval = true;
    }
    const oldRendererSnapshot = emptyAfterOldRemoval
      ? { normalization: "outerHTML-v1", html: "", controls: [] }
      : null;
    const after = {
      trace: current.runtime.trace(),
      snapshot: current.runtime.snapshot(),
      hostRequests: current.host.requests(),
      hostCompletions: current.host.completions(),
      diagnostics: current.runtime.rendererDiagnostics(),
      focus: next.focusState(),
      focusNodeReplaced: oldFocusedElement === null ||
        (oldFocusedElement !== document.activeElement && !oldFocusedElement.isConnected),
      renderer: { id: next.record.id, backend: next.record.backend },
      oldRendererSnapshot,
      oldRootDetached: oldRoot === null || !oldRoot.isConnected,
      oldRootEmptyDuringSwap: emptyAfterOldRemoval,
      rootMutationEvidence: { childListRecords: mutations.length, oldRootRemoved, newRootAdded, emptyAfterOldRemoval },
      physicalHTML: document.getElementById("app").innerHTML,
    };
    return { before, after, returnedSnapshot };
  },
  fenceRetired(rendererId, action, renderEpoch = 0) {
    const record = rendererRecords.find((item) => item.id === rendererId);
    if (!record) throw new Error("unknown renderer id for stale callback probe");
    const hooks = record.hooks.at(-1);
    if (!hooks) throw new Error("renderer has not received runtime callbacks");
    let dispatch = null;
    if (record.lastDispatchMessage !== null) {
      dispatch = hooks.dispatch(copy(action), record.lastDispatchMessage);
    }
    const stale = hooks.onStaleAction(copy(action), renderEpoch);
    return { dispatch, stale, trace: requireInstance().runtime.trace(), snapshot: requireInstance().runtime.snapshot(), diagnostics: requireInstance().runtime.rendererDiagnostics() };
  },
  staleActive(action, renderEpoch = 0) {
    const callbacks = requireInstance().renderer.record.rendererCallbacks.at(-1);
    if (!callbacks) throw new Error("active renderer has no retained callback");
    return callbacks.onStaleAction(copy(action), renderEpoch);
  },
  unmount() {
    const current = requireInstance();
    const renderer = current.renderer;
    const hooks = renderer.record.hooks.at(-1);
    const action = current.fixtureScript.actions.find((item) => item !== null) ?? { path: "", event: "click", value: "" };
    const traceBefore = current.runtime.trace();
    const result = current.runtime.unmount();
    const physical = {
      normalization: "container-innerHTML-v1",
      html: document.getElementById("app").innerHTML,
      controls: document.getElementById("app").querySelectorAll("input,button,textarea,select").length,
    };
    const rendererSnapshot = renderer.domSnapshot();
    const traceAfterUnmount = current.runtime.trace();
    let fenced = null;
    if (hooks) {
      const expectedMessage = current.fixtureScript.expectations.find((item) => item.message !== null)?.message ?? { name: "fence", arg: "" };
      const probeMessage = renderer.record.lastDispatchMessage ?? { Name: expectedMessage.name, Arg: expectedMessage.arg };
      const dispatch = hooks.dispatch(copy(action), probeMessage);
      const stale = hooks.onStaleAction(copy(action), 0);
      fenced = { dispatch, stale, trace: current.runtime.trace(), diagnostics: current.runtime.rendererDiagnostics() };
    }
    return { result, traceBefore, traceAfterUnmount, traceAfter: current.runtime.trace(), physical, rendererSnapshot, fenced };
  },
};
