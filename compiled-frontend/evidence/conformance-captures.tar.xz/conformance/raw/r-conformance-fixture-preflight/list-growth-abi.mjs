import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import { pathToFileURL } from "node:url";

const compiledPath = "/tmp/gondola-compiled-atomic/apps/list-f8359aa2866d/gobi-compiled.mjs";
const digest = async () => createHash("sha256").update(await readFile(compiledPath)).digest("hex");
const inputSha256Before = await digest();
const { gobiCompiled } = await import(pathToFileURL(compiledPath).href);
const component = gobiCompiled.appIR.components.find((entry) =>
  entry.packagePath === "github.com/samuelpmahan/gondola/fixtures/compiled/list");
if (!component) throw new Error("compiled list component is missing");
const init = gobiCompiled.symbols[component.init];
const update = gobiCompiled.symbols[component.update];
if (typeof init !== "function" || typeof update !== "function") throw new Error("compiled list roles are not callable");

let state = init();
const observations = [];
for (let adds = 1; adds <= 5; adds += 1) {
  state = update(state, { Name: "add", Arg: "" })[0];
  if (adds !== 3 && adds !== 5) continue;
  const slice = state.Rows;
  const backing = slice?.backing ?? slice;
  if (!Array.isArray(backing)) throw new TypeError("compiled list Rows has no native backing array");
  const symbols = Reflect.ownKeys(backing).filter((key) => typeof key === "symbol");
  observations.push({
    adds,
    length: slice?.length ?? backing.length,
    capacity: slice?.capacity ?? backing.length,
    backingArrayLength: backing.length,
    offset: slice?.offset ?? 0,
    ownSymbols: symbols.map((symbol) => ({
      description: symbol.description,
      descriptor: {
        value: typeof backing[symbol],
        writable: Object.getOwnPropertyDescriptor(backing, symbol).writable,
        enumerable: Object.getOwnPropertyDescriptor(backing, symbol).enumerable,
        configurable: Object.getOwnPropertyDescriptor(backing, symbol).configurable,
      },
    })),
    spareSlotIndexes: Array.from({ length: (slice?.capacity ?? backing.length) - (slice?.length ?? backing.length) },
      (_, index) => (slice?.offset ?? 0) + (slice?.length ?? backing.length) + index)
      .map((index) => ({ index, own: Object.hasOwn(backing, index) })),
    rowIDs: Array.from({ length: slice?.length ?? backing.length }, (_, index) =>
      String(backing[(slice?.offset ?? 0) + index]?.ID)),
  });
}

const inputSha256After = await digest();
if (inputSha256Before !== inputSha256After) throw new Error("compiled module changed during ABI observation");
process.stdout.write(`${JSON.stringify({
  schema: "gobi.list-growth-abi-preflight/v1",
  node: process.version,
  compiledPath,
  inputSha256Before,
  inputSha256After,
  observations,
}, null, 2)}\n`);
