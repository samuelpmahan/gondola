#!/usr/bin/env bash
set -u
ROOT=/workspace/scratch/39a56936f173/gondola-compiled
OUT="$ROOT/compiled-frontend/conformance/raw/n6-source-900dc38-final"
NODE=/tmp/gondola-node22/node_modules/node/bin/node
GO=/tmp/gondola-go/bin/go
printf '%s\n' "$($GO version)" > "$OUT/logs/versions.txt"
printf '%s\n' "$($NODE --version)" >> "$OUT/logs/versions.txt"
printf '%s\n' "Chromium $(/tmp/chromium --version)" >> "$OUT/logs/versions.txt"
cd "$ROOT"
GOTOOLCHAIN=local GOFLAGS=-buildvcs=false "$GO" build -o "$OUT/compiled-native" ./cmd/compiled-native > "$OUT/logs/build-native.stdout.log" 2> "$OUT/logs/build-native.stderr.log"
for app in counter form list effect; do
  case "$app" in
    counter) appdir=counter-b05e9eb0e4e6 ;;
    form) appdir=form-a3fe6b48b000 ;;
    list) appdir=list-f8359aa2866d ;;
    effect) appdir=effect-ff8449e8f5b2 ;;
  esac
  "$OUT/compiled-native" --app-ir "/tmp/gondola-compiled-atomic/apps/$appdir/app-ir.json" --script "$ROOT/compiled-frontend/fixtures/$app.json" > "$OUT/$app.native.json" 2> "$OUT/logs/$app-native.stderr.log"
  "$NODE" "$ROOT/compiled-frontend/conformance/direct-js.mjs" --compiled "/tmp/gondola-compiled-atomic/apps/$appdir/gobi-compiled.mjs" --helpers "/tmp/gondola-compiled-atomic/apps/$appdir/encoder.mjs" --fixture "$ROOT/compiled-frontend/fixtures/$app.json" --output "$OUT/$app.direct.json" --manifest "$OUT/$app.direct.manifest.json" > "$OUT/logs/$app-direct.stdout.log" 2> "$OUT/logs/$app-direct.stderr.log"
  if CHROMIUM_PATH=/tmp/chromium "$NODE" "$ROOT/compiled-frontend/conformance/browser.mjs" --compiled "/tmp/gondola-compiled-atomic/apps/$appdir/gobi-compiled.mjs" --helpers "/tmp/gondola-compiled-atomic/apps/$appdir/encoder.mjs" --fixture "$ROOT/compiled-frontend/fixtures/$app.json" --output "$OUT/$app.browser.json" > "$OUT/logs/$app-browser.stdout.log" 2> "$OUT/logs/$app-browser.stderr.log"; then
    printf '%s browser pass\n' "$app" >> "$OUT/logs/browser-summary.txt"
  else
    rc=$?
    printf '%s browser rejected (exit %s)\n' "$app" "$rc" >> "$OUT/logs/browser-summary.txt"
  fi
done
