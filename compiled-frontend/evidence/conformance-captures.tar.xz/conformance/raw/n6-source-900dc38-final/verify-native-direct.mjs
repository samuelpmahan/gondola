import { readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { assertExactTraceValue } from "../../compare.mjs";

const directory = dirname(fileURLToPath(import.meta.url));
const apps = [];
for (const app of ["counter", "form", "list", "effect"]) {
  const native = JSON.parse(await readFile(resolve(directory, `${app}.native.json`), "utf8"));
  const direct = JSON.parse(await readFile(resolve(directory, `${app}.direct.json`), "utf8"));
  assertExactTraceValue(native, direct, `$[${app}].nativeVsDirect`);
  apps.push({ app, ticks: native.ticks.length, equality: "exact" });
}
const summary = { totalTicks: apps.reduce((count, app) => count + app.ticks, 0), apps };
await writeFile(resolve(directory, "native-direct-summary.json"), `${JSON.stringify(summary, null, 2)}\n`);
process.stdout.write(`${JSON.stringify(summary)}\n`);
