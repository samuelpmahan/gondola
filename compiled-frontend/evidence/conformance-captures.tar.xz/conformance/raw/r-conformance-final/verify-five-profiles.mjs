import assert from "node:assert/strict";
import { readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { assertExactTraceValue } from "../../compare.mjs";

const directory = dirname(fileURLToPath(import.meta.url));
const profiles = ["counter", "form", "list", "effect", "list-growth"];
const summary = [];
const readJSON = async (path) => JSON.parse(await readFile(resolve(directory, path), "utf8"));

for (const profile of profiles) {
  const [native, direct, browser, checked, fixture] = await Promise.all([
    readJSON(`${profile}.native.json`),
    readJSON(`${profile}.direct.json`),
    readJSON(`${profile}.browser.json`),
    readJSON(`${profile}.check.json`),
    readJSON(profile === "list-growth"
      ? "../../fixtures/list-growth.json"
      : `../../../fixtures/${profile}.json`),
  ]);
  assertExactTraceValue(native, direct, `$[${profile}].nativeVsDirect`);
  assert.equal(checked.status, "matched", `${profile} checker result`);
  const expectedTickCount = fixture.actions.length + 1 + fixture.hostScript.steps.filter((step) => step.completion !== null).length;
  assert.equal(native.ticks.length, expectedTickCount, `${profile} includes init, every attempted action, and every delivered reply`);
  assert.equal(direct.ticks.length, native.ticks.length);
  assert.equal(browser.trace.ticks.length, native.ticks.length);
  assert.equal(browser.pageErrors.length, 0);
  assert.deepEqual(browser.noWasm.wasmRequests, []);
  assert.deepEqual(browser.noWasm.wasmAPIAttempts, []);
  assert.deepEqual(browser.unmount.physicalDOM, { normalization: "container-innerHTML-v1", html: "", controls: 0 });
  assert.deepEqual(browser.unmount.rendererSnapshot, { normalization: "outerHTML-v1", html: "", controls: [] });
  assert.equal(browser.provenanceBase.node, "v22.23.4");
  assert.ok(browser.provenanceBase.inputs.length > 0);
  const bundlePath = browser.provenance.inputs.find((input) => input.path.startsWith("/tmp/gobi-compiled-browser-"))?.path;
  assert.ok(bundlePath, `${profile} browser bundle is source pinned`);
  const sourcePins = browser.provenance.inputs.filter((input) => input.path !== bundlePath);
  assertExactTraceValue(browser.provenanceBase.inputs, sourcePins, `$[${profile}].browserSourcePins`);

  if (profile === "list") {
    assert.equal(browser.focus.before.direction, "backward");
    assert.equal(browser.focus.immediate.direction, "backward");
    assert.equal(browser.focus.settled.direction, "backward");
    assert.equal(browser.focus.before.start, fixture.focusWitnesses[0].selectionStart);
    assert.equal(browser.focus.before.end, fixture.focusWitnesses[0].selectionEnd);
    assert.equal(browser.focus.immediate.sameKeyedNodeAtNewPath, true);
    assert.equal(browser.focus.settled.sameKeyedNodeAtNewPath, true);
    assert.equal(checked.lifecycleEvidence.detachedReactHandlerAfterNodeRemoval, true);
  }

  if (profile === "effect") {
    assert.equal(browser.effectHostEvidence.requests.length, fixture.hostScript.steps.length);
    assert.equal(browser.effectHostEvidence.completions.length, fixture.hostScript.steps.filter((step) => step.completion !== null).length);
    assert.equal(browser.duplicateCompletionEvidence.result.accepted, false);
    assert.equal(browser.duplicateCompletionEvidence.beforeTickCount, browser.duplicateCompletionEvidence.afterTickCount);
    for (const observation of browser.hostObservations.requests) {
      assert.ok(observation.tickCount >= 2);
      assert.ok(observation.snapshot.dom.html.includes("Status: pending"));
      assert.equal(observation.snapshot.dom.controls.find((control) => control.path === "1").disabled, true);
    }
  }

  if (profile === "list-growth") {
    assert.equal(native.ticks.length, 12);
    assert.equal(browser.actions.length, 11);
    assert.equal(browser.focus, null);
    assert.deepEqual(native.ticks[3].state.fields[0].value.items.map((row) => row.fields[0].value.integer), ["1", "2", "3"]);
    assert.deepEqual(native.ticks[5].state.fields[0].value.items.map((row) => row.fields[0].value.integer), ["1", "2", "3", "4", "5"]);
    assert.equal(browser.actions[10].expectedMessage, null);
    assert.equal(browser.actions[10].targetDisabled, true);
  }

  summary.push({
    profile,
    appId: native.appId,
    fixture: fixture.name,
    status: checked.status,
    ticks: native.ticks.length,
    mutationControls: checked.mutationControls.length,
    traceSha256: browser.traceSha256,
  });
}

const growthABI = await readJSON("list-growth-abi.json");
assert.equal(growthABI.inputSha256Before, growthABI.inputSha256After);
assert.deepEqual(growthABI.observations.map(({ adds, length, capacity, symbol }) => ({ adds, length, capacity, symbol })), [
  { adds: 3, length: 3, capacity: 4, symbol: "goscript.spareZero" },
  { adds: 5, length: 5, capacity: 8, symbol: "goscript.spareZero" },
]);
const result = {
  schema: "gobi.five-profile-conformance/v1",
  totalTicks: summary.reduce((sum, item) => sum + item.ticks, 0),
  profiles: summary,
  listGrowthABI: {
    compiledModuleSha256: growthABI.inputSha256Before,
    lengthCapacity: growthABI.observations.map(({ adds, length, capacity }) => ({ adds, length, capacity })),
  },
};
assert.equal(result.totalTicks, 43);
await writeFile(resolve(directory, "summary.json"), `${JSON.stringify(result, null, 2)}\n`);
process.stdout.write(`${JSON.stringify(result)}\n`);
