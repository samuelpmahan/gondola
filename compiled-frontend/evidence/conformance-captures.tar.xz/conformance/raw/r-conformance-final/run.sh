#!/usr/bin/env bash
set -euo pipefail
ROOT=/workspace/scratch/39a56936f173/gondola-compiled
OUT="$ROOT/compiled-frontend/conformance/raw/r-conformance-final"
COMPILED="$ROOT/compiled-frontend/artifacts/compiled"
NODE=/tmp/gondola-node22/node_modules/node/bin/node
GO=/tmp/gondola-go/bin/go
mkdir -p "$OUT/logs"
printf '%s\n' "$($GO version)" > "$OUT/logs/versions.txt"
printf '%s\n' "$($NODE --version)" >> "$OUT/logs/versions.txt"
printf '%s\n' "Chromium $(/tmp/chromium --version)" >> "$OUT/logs/versions.txt"
printf 'fresh build manifest sha256: ' >> "$OUT/logs/versions.txt"
sha256sum "$COMPILED/buildmanifest.json" >> "$OUT/logs/versions.txt"
cd "$ROOT"
GOTOOLCHAIN=local GOFLAGS=-buildvcs=false "$GO" build -o "$OUT/compiled-native" ./cmd/compiled-native > "$OUT/logs/build-native.stdout.log" 2> "$OUT/logs/build-native.stderr.log"
for profile in counter form list effect list-growth; do
  case "$profile" in
    counter) app=counter; appdir=counter-b05e9eb0e4e6; fixture="$ROOT/compiled-frontend/fixtures/counter.json" ;;
    form) app=form; appdir=form-a3fe6b48b000; fixture="$ROOT/compiled-frontend/fixtures/form.json" ;;
    list) app=list; appdir=list-f8359aa2866d; fixture="$ROOT/compiled-frontend/fixtures/list.json" ;;
    effect) app=effect; appdir=effect-ff8449e8f5b2; fixture="$ROOT/compiled-frontend/fixtures/effect.json" ;;
    list-growth) app=list; appdir=list-f8359aa2866d; fixture="$ROOT/compiled-frontend/conformance/fixtures/list-growth.json" ;;
  esac
  appIR="$COMPILED/apps/$appdir/app-ir.json"
  module="$COMPILED/apps/$appdir/gobi-compiled.mjs"
  helpers="$COMPILED/apps/$appdir/encoder.mjs"
  "$OUT/compiled-native" --app-ir "$appIR" --script "$fixture" > "$OUT/$profile.native.json" 2> "$OUT/logs/$profile-native.stderr.log"
  "$NODE" "$ROOT/compiled-frontend/conformance/direct-js.mjs" --compiled "$module" --helpers "$helpers" --fixture "$fixture" --output "$OUT/$profile.direct.json" --manifest "$OUT/$profile.direct.manifest.json" > "$OUT/logs/$profile-direct.stdout.log" 2> "$OUT/logs/$profile-direct.stderr.log"
  CHROMIUM_PATH=/tmp/chromium "$NODE" "$ROOT/compiled-frontend/conformance/browser.mjs" --compiled "$module" --helpers "$helpers" --fixture "$fixture" --output "$OUT/$profile.browser.json" > "$OUT/logs/$profile-browser.stdout.log" 2> "$OUT/logs/$profile-browser.stderr.log"
  "$NODE" "$ROOT/compiled-frontend/conformance/check.mjs" --app-ir "$appIR" --fixture "$fixture" --native "$OUT/$profile.native.json" --direct "$OUT/$profile.direct.json" --browser "$OUT/$profile.browser.json" --output "$OUT/$profile.check.json" > "$OUT/logs/$profile-check.stdout.log" 2> "$OUT/logs/$profile-check.stderr.log"
done
CHROMIUM_PATH=/tmp/chromium "$NODE" --test "$ROOT"/compiled-frontend/conformance/*.test.mjs > "$OUT/logs/conformance-tests.stdout.log" 2> "$OUT/logs/conformance-tests.stderr.log"
