import hashlib
import json
import pathlib
import re

root = pathlib.Path.cwd()
def digest(data):
    return hashlib.sha256(data).hexdigest()
def read(path):
    return (root / path).read_bytes()
def pin(path):
    data = read(path)
    return {"path": path, "bytes": len(data), "sha256": digest(data)}

report_path = "backend-qualification/coordination/reports/E-BUILD.md"
receipt_path = "backend-qualification/coordination/receipts/E-BUILD.json"
builder_path = "backend-qualification/build/build.mjs"
sealed_source_path = "backend-qualification/coordination/seals/E-BUILD/source/build.mjs"
postseal_source_path = "backend-qualification/coordination/seals/E-BUILD/post-seal-change/build.mjs"
recovery_root = pathlib.Path("backend-qualification/coordination/rawlogs/E-BUILD/post-seal-custody-recovery")
receipt = json.loads(read(receipt_path))
provenance = json.loads(read("backend-qualification/coordination/rawlogs/E-BUILD/build-inputs.json"))
source_pins = json.loads(read("backend-qualification/coordination/rawlogs/E-BUILD/source-pins.json"))["pins"]
recovery = json.loads(read((recovery_root / "recovery.json").as_posix()))
sealed_builder = read(sealed_source_path)
contract_text = read("backend-qualification/CONTRACT.md").decode("utf-8")
contract_ref = re.search(r"Base([0-9a-f]+)\(", contract_text.splitlines()[2]).group(1)
base_ref_matches = provenance["contractBaseCommitRef"] == contract_ref

build_checks = {}
for backend in ("react", "dom"):
    build = provenance[backend]
    output_root = pathlib.Path("/tmp/gobi-backend-qualification-E-BUILD-final-20261031") / "builds" / backend / "output"
    actual = [p for p in output_root.rglob("*") if p.is_file()]
    mismatches = []
    for item in build["outputs"]:
        path = output_root / item["path"]
        if not path.is_file():
            mismatches.append({"path": item["path"], "error": "missing"})
            continue
        data = path.read_bytes()
        if len(data) != item["bytes"] or digest(data) != item["sha256"]:
            mismatches.append({"path": item["path"], "error": "size-or-sha256"})
    app_ir_path = output_root / "apps/publications-5ad33d9496e7/app-ir.json"
    app_ir_data = app_ir_path.read_bytes()
    app_ir = json.loads(app_ir_data)
    component = next(row for row in app_ir["components"] if row["id"] == build["componentId"])
    build_checks[backend] = {
        "inventory_entries": len(build["outputs"]),
        "actual_files": len(actual),
        "inventory_hash_mismatches": mismatches,
        "app_ir_sha256": digest(app_ir_data),
        "capabilities": component["capabilities"],
    }

source_mismatches = []
for path, expected in source_pins.items():
    # The immutable sealed builder is the authority for this completed packet;
    # N5's separately authorized E-BUILD-BASE work owns the live path now.
    candidate_bytes = sealed_builder if path == builder_path else (root / path).read_bytes() if (root / path).is_file() else None
    if candidate_bytes is None:
        source_mismatches.append({"path": path, "error": "missing"})
        continue
    if len(candidate_bytes) != expected["bytes"] or digest(candidate_bytes) != expected["sha256"]:
        source_mismatches.append({"path": path, "error": "size-or-sha256"})

native_path = "backend-qualification/coordination/rawlogs/E-BUILD/native/native-trace.json"
native_data = read(native_path)
native = json.loads(native_data)
sealed_report = pathlib.Path("backend-qualification/coordination/seals/E-BUILD/reports/E-BUILD.md").read_bytes()
sealed_receipt = pathlib.Path("backend-qualification/coordination/seals/E-BUILD/receipts/E-BUILD.json").read_bytes()
candidate_original = (recovery_root / "candidate-original-builder.mjs").read_bytes()
postseal_builder = read(postseal_source_path)

result = {
    "decision": "amend" if not base_ref_matches else "accepted",
    "sealed_packet": {
        "report_matches_seal": read(report_path) == sealed_report,
        "receipt_matches_seal": read(receipt_path) == sealed_receipt,
        "report_sha256": digest(sealed_report),
        "receipt_sha256": digest(sealed_receipt),
    },
    "custody": {
        "sealed_builder_sha256": digest(sealed_builder),
        "reconstruction_sha256": digest(candidate_original),
        "postseal_changed_builder_sha256": digest(postseal_builder),
        "reconstruction_matches_sealed": candidate_original == sealed_builder,
        "postseal_bytes_differ": postseal_builder != sealed_builder,
        "receipt_says_prior_packet_unmodified": recovery["priorReportAndReceiptRewritten"] is False,
        "source_pin_builder_uses_immutable_seal": True,
    },
    "builds": build_checks,
    "source_pins": {"count": len(source_pins), "mismatches": source_mismatches},
    "native_trace": {
        "sha256": digest(native_data),
        "events": len(native["events"]),
        "steps": len(native["steps"]),
        "receipt_hash_matches": digest(native_data) == receipt["native_trace"]["sha256"],
    },
    "base_reference": {
        "contract": contract_ref,
        "contract_length": len(contract_ref),
        "provenance": provenance["contractBaseCommitRef"],
        "provenance_length": len(provenance["contractBaseCommitRef"]),
        "receipt": receipt["source"]["base_reference_from_contract"],
        "matches": base_ref_matches,
        "receipt_equals_provenance": receipt["source"]["base_reference_from_contract"] == provenance["contractBaseCommitRef"],
    },
    "builder_pin_in_receipt": {
        "sealed_source_bytes": len(sealed_builder),
        "sealed_source_sha256": digest(sealed_builder),
        "matches_receipt": len(sealed_builder) == receipt["source"]["builder"]["bytes"] and digest(sealed_builder) == receipt["source"]["builder"]["sha256"],
    },
    "report_pin_in_receipt": pin(report_path) == receipt["report"],
}
print(json.dumps(result, indent=2, sort_keys=True))
