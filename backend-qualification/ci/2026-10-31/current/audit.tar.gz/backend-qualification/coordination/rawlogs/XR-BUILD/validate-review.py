import hashlib
import json
import pathlib

root = pathlib.Path.cwd()
receipt_path = pathlib.Path("backend-qualification/coordination/receipts/XR-BUILD.json")
receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
if receipt.get("job_id") != "XR-BUILD" or receipt.get("worker") != "N3":
    raise SystemExit("review receipt job_id/worker mismatch")
if receipt.get("decision") not in {"accepted", "amend", "rejected"}:
    raise SystemExit("review receipt decision missing or invalid")
if not isinstance(receipt.get("summary"), str) or not receipt["summary"].strip():
    raise SystemExit("review receipt summary missing")

source_pins = [value for value in receipt["source"].values() if isinstance(value, dict) and "path" in value]
pins = [*source_pins, receipt["report"], *receipt["evidence"]]
for item in pins:
    data = (root / item["path"]).read_bytes()
    if len(data) != item["bytes"] or hashlib.sha256(data).hexdigest() != item["sha256"]:
        raise SystemExit(f"pin mismatch: {item['path']}")
print("PASS: XR-BUILD receipt fields and every source, report, and rawlog pin matched.")
