import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
raw_dir = ROOT / "backend-qualification/coordination/rawlogs/E-HARNESS/attempt-04-node22-source-pinned"
raw_path = raw_dir / "qualification.raw.json"
summary_path = raw_dir / "qualification.summary.json"
raw = json.loads(raw_path.read_text())
summary = json.loads(summary_path.read_text())
receipt = json.loads((ROOT / "backend-qualification/coordination/receipts/E-HARNESS.json").read_text())
plan = json.loads((ROOT / "backend-qualification/oracle/plan.json").read_text())

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert digest(raw_path) == receipt["execution"]["raw_report"]["sha256"]
assert digest(summary_path) == receipt["execution"]["summary"]["sha256"]
assert summary["status"] == "matched" and summary["sourcePinsStable"] is True
assert summary["matrix"] == {"total": 13, "healthy": 3, "faultCases": 10, "passed": 13, "failed": 0}
assert summary["baseline"]["status"] == "matched"
assert summary["baseline"]["events"] == 50 and summary["baseline"]["stateCheckpoints"] == 46
assert raw["schema"] == "gobi.backend-qualification-run/v1"
assert raw["sourceCommit"] == "5662efcd7feb7920e4690d38cc76a297fed69d5a"
assert summary["sourceCommit"] == raw["sourceCommit"]
assert summary["sourceAttestation"] == "author-uncommitted-base-source"
assert len(raw["results"]) == 13 and len(plan["cases"]) == 13

for pin in summary["sourcePins"]:
    path = Path(pin["path"])
    assert path.is_file(), pin["label"]
    assert path.stat().st_size == pin["bytes"], pin["label"]
    assert digest(path) == pin["sha256"], pin["label"]
for key in ("runner", "renderer_decorator", "browser_entry_seam"):
    item = receipt["source"][key]
    path = ROOT / item["path"]
    assert path.stat().st_size == item["bytes"] and digest(path) == item["sha256"], key

channels = ["dom", "disabled", "dispatch-count", "trace-count", "state"]
assert [row["id"] for row in raw["results"]] == plan["caseIds"]
for row, case in zip(raw["results"], plan["cases"]):
    evidence_path = (raw_dir / row["evidencePath"]).resolve()
    assert evidence_path.is_relative_to(raw_dir.resolve())
    evidence_bytes = evidence_path.read_bytes()
    assert hashlib.sha256(evidence_bytes).hexdigest() == row["evidenceSHA256"], row["id"]
    evidence = json.loads(evidence_bytes)
    assert evidence["schema"] == "gobi.backend-qualification-case-evidence/v1"
    assert (evidence["id"], evidence["backend"], evidence["fault"]) == (row["id"], row["backend"], row["fault"])
    assert evidence["infrastructureErrors"] == [] and evidence["pageErrors"] == [], row["id"]
    assert evidence["eventsObserved"] == row["eventsObserved"]
    assert evidence["traceTicks"] == row["traceTicks"]
    assert evidence["probeException"] == row["probeException"]
    observed = evidence["observed"]
    pairs = evidence["channelComparisons"]
    assert set(pairs) == set(channels), row["id"]
    assert pairs["dom"]["expected"] == evidence["expected"]["dom"]["html"]
    assert pairs["dom"]["observed"] == observed["dom"]["html"]
    assert pairs["disabled"]["expected"] == [{"path": evidence["expected"]["disabled"]["path"], "disabled": evidence["expected"]["disabled"]["value"]}]
    control = next(item for item in observed["dom"]["controls"] if item["path"] == evidence["expected"]["disabled"]["path"])
    assert pairs["disabled"]["observed"] == [{"path": control["path"], "disabled": control["disabled"]}]
    dispatch_expected = evidence["expected"].get("dispatchCount", evidence["expected"].get("dispatchCountDelta"))
    assert pairs["dispatch-count"]["expected"] == dispatch_expected
    assert pairs["dispatch-count"]["observed"] == observed["callbackCounts"]["dispatch"]
    assert pairs["trace-count"]["expected"] == evidence["expected"]["traceTicks"]
    assert pairs["trace-count"]["observed"] == observed["traceTicks"]
    assert pairs["state"]["expected"] == evidence["expected"]["state"]
    assert pairs["state"]["observed"] == observed["state"]
    derived = [name for name in channels if pairs[name]["expected"] != pairs[name]["observed"]]
    assert evidence["observedChannels"] == derived == row["observedChannels"], row["id"]

    if case["fault"] == "none":
        assert row["activated"] is False and row["activationCount"] == 0
        assert row["observedChannels"] == []
        assert row["eventsObserved"] == 50 and row["traceTicks"] == 46
        assert evidence["baselineCheck"]["status"] == "matched"
        assert evidence["baselineCheck"]["events"] == 50
        assert evidence["baselineCheck"]["stateCheckpoints"] == 46
        assert len(evidence["profile"]["actions"]) == 34
        assert observed["callbackCounts"]["dispatch"] == 34
        if row["backend"] == "swap":
            assert evidence["profile"]["callbackCounts"]["dispatch"] == 36
            assert len(evidence["profile"]["observations"]["dispatch"]) == 36
            event_rows = evidence["profile"]["events"]
            accepted_swap = event_rows[26]["operation"]
            stale_callback = event_rows[27]["operation"]
            assert accepted_swap["after"]["retiredCallback"]["dispatch"]["accepted"] is False
            assert accepted_swap["after"]["retiredCallback"]["dispatch"]["stale"] is True
            assert accepted_swap["acceptedPreserved"]["trace"] is True
            assert stale_callback["result"]["accepted"] is False and stale_callback["result"]["stale"] is True
            assert stale_callback["invariants"]["traceUnchanged"] is True
        else:
            assert evidence["profile"]["callbackCounts"]["dispatch"] == 34
            assert len(evidence["profile"]["observations"]["dispatch"]) == 34
    else:
        activation = evidence["activation"]
        assert row["activated"] is True and row["activationCount"] == 1
        assert activation["activated"] is True and activation["activationCount"] == 1
        assert len(activation["records"]) == 1
        record = activation["records"][0]
        assert record["fault"] == case["fault"] and record["backend"] == case["backend"]
        assert activation["eventIndex"] == case["activation"]["eventIndex"]
        assert record["eventIndex"] == case["activation"]["eventIndex"]
        assert activation["targetPath"] == case["activation"]["targetPath"]
        assert record["target"]["path"] == case["activation"]["targetPath"]
        assert activation["callbackInvocations"] == record["callbackInvocationsAfter"]
        target = record["target"]
        assert target["before"]["path"] == case["activation"]["targetPath"]
        assert target["after"]["path"] == case["activation"]["targetPath"]
        if case["fault"] == "text-corruption":
            assert target["before"]["text"] != target["after"]["text"]
        elif case["fault"] == "key-order":
            assert target["before"]["childOrder"] == list(reversed(target["after"]["childOrder"]))
            assert target["before"]["outerHTML"] != target["after"]["outerHTML"]
        elif case["fault"] == "enabled-control":
            assert target["before"]["disabled"] is True and target["after"]["disabled"] is False
        else:
            assert target["before"]["connected"] is True and target["after"]["connected"] is True
            assert target["before"]["disabled"] is False and target["after"]["disabled"] is False
        for channel in case["expectedChannels"]:
            if case["channelRule"] == "any":
                break
            assert channel in derived, (row["id"], channel)
        if case["channelRule"] == "any":
            assert any(channel in derived for channel in case["expectedChannels"]), row["id"]
        assert set(derived).issubset(set(case["allowedChannels"]))
        if case["activation"]["eventIndex"] is None:
            assert row["eventsObserved"] == 0 and row["traceTicks"] == 1
        else:
            assert case["activation"]["eventIndex"] == 0 and row["eventsObserved"] == 1
            assert row["traceTicks"] == (1 if case["fault"] == "drop-click" else 3)
            assert record["callbackInvocationsBefore"]["rendererDispatch"] == 0
            assert record["callbackInvocationsAfter"]["rendererDispatch"] == 1
            if case["fault"] == "drop-click":
                assert record["callbackInvocationsAfter"]["forwardedDispatch"] == 0
            if case["fault"] == "duplicate-click":
                assert record["callbackInvocationsAfter"]["forwardedDispatch"] == 2

runner = (ROOT / "backend-qualification/conformance/qualification.mjs").read_text()
entry = (ROOT / "compiled-publications/conformance/browser-entry.mjs").read_text()
assert "const page = await browser.newPage();" in runner
assert "await page.close().catch" in runner and "window.__gobiCompiledPublications?.dispose?.()" in runner
assert "physicalDOM: physicalDOM" not in entry
assert "physicalDOM,\n      physicalDOMError" in entry
assert "physicalDOM ?? raw?.rendererDOM" in runner
print("E-HARNESS raw report and 13 evidence hashes verified")
print("3 healthy profiles matched 50 source events and 46 checkpoints")
print("healthy swap includes two fenced retired-callback probes; 34 physical click dispatches remain separately evidenced")
print("10 faults each activated once with oracle-bound event/target and derived semantic channels")
print("drop/duplicate physical event 0 and actual callback/tick behavior verified")
print("all evidence has zero infrastructure/page errors; per-case page lifecycle is isolated and closed")
print("runner, adapter, and browser-entry source hashes match the sealed receipt")
