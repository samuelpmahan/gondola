#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
EVIDENCE = ROOT / "backend-qualification/coordination"
HARNESS = EVIDENCE / "rawlogs/E-HARNESS/attempt-04-node22-source-pinned"
XRLOG = EVIDENCE / "rawlogs/XR-ADAPTERS"

EXPECTED = {
    "backend-qualification/adapters/qualification-decorator.mjs": "c6e75b5a6b935b7d009ce0fd6d5a0d58f6490bfe44c5a34c54b3ba8544a2ba31",
    "backend-qualification/adapters/qualification-decorator.test.mjs": "d46f986888b13d1fd4cf055bc4186d55c80cf72bf649c606629f8f42263d0d72",
    "compiled-publications/conformance/browser-entry.mjs": "b99a9d24fd39bfb59662ca6859559f508f60f8da07b3777a004d4397b2ee2492",
    "backend-qualification/coordination/reports/E-ADAPTERS.md": "170c748a5f5922616cb387773d253cc25afbeb8124834f971a83628c4dd32034",
    "backend-qualification/coordination/receipts/E-ADAPTERS.json": "fb36738c722e0f15812c43a6616931615b3b3008f7cd5dfa2062c1159e28d170",
    "backend-qualification/conformance/qualification.mjs": "18991f813d2bfb78499b542a0b99dfd2eae3252fec6c61203759abbde744b050",
}
EXPECTED_RAW = "4222a32d73fde4e9fa31e534ebad7ab61fae8337f6cff7e0b2c9b05486586bcf"
EXPECTED_SUMMARY = "3110e119c325eb644c26671290c482b09ee8408f6a9eca868e0066b5f36c3cc0"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(ok, message):
    if not ok:
        raise AssertionError(message)


pins = {}
for rel, expected in EXPECTED.items():
    path = ROOT / rel
    pins[rel] = {"bytes": path.stat().st_size, "sha256": sha(path), "matches_expected": sha(path) == expected}
    require(pins[rel]["matches_expected"], f"source pin mismatch: {rel}")

seal = EVIDENCE / "seals/E-ADAPTERS"
seal_matches = {}
for rel in ["reports/E-ADAPTERS.md", "receipts/E-ADAPTERS.json"]:
    live = EVIDENCE / rel
    sealed = seal / rel
    seal_matches[rel] = live.read_bytes() == sealed.read_bytes()
    require(seal_matches[rel], f"sealed E-ADAPTERS copy mismatch: {rel}")

receipt = json.loads((EVIDENCE / "receipts/E-ADAPTERS.json").read_text())
require(receipt["validation"]["focused_tests"] == {"passed": 6, "failed": 0, "cancelled": 0, "skipped": 0}, "E-ADAPTERS test receipt does not record 6/6")
require(receipt["scope"]["application_or_renderer_core_paths_changed"] == [], "application/renderer-core scope is not empty")

test_log = (XRLOG / "adapter-tests.stdout.log").read_text()
test_exit = int((XRLOG / "adapter-tests.exit-code").read_text().strip())
require(test_exit == 0 and "# tests 6" in test_log and "# pass 6" in test_log and "# fail 0" in test_log, "independent adapter tests did not pass 6/6")
syntax = {name: int((XRLOG / f"syntax-{name}.exit-code").read_text().strip()) for name in ["decorator", "test", "browser-entry"]}
require(all(code == 0 for code in syntax.values()), "independent syntax check failure")

raw_path = HARNESS / "qualification.raw.json"
summary_path = HARNESS / "qualification.summary.json"
require(sha(raw_path) == EXPECTED_RAW, "N4 raw report hash mismatch")
require(sha(summary_path) == EXPECTED_SUMMARY, "N4 summary hash mismatch")
raw = json.loads(raw_path.read_text())
summary = json.loads(summary_path.read_text())
require(raw["schema"] == "gobi.backend-qualification-run/v1" and len(raw["results"]) == 13, "unexpected N4 report schema/cardinality")
require(summary["matrix"] == {"total": 13, "healthy": 3, "faultCases": 10, "passed": 13, "failed": 0}, "N4 matrix summary mismatch")
require(summary["sourcePinsStable"] is True and summary["sourceAttestation"] == "author-uncommitted-base-source", "unexpected source attestation or unstable source pins")
require(sha(ROOT / "backend-qualification/conformance/qualification.mjs") == EXPECTED["backend-qualification/conformance/qualification.mjs"], "N4 runner source pin mismatch")

case_inventory = []
by_id = {}
for result in raw["results"]:
    evidence_path = HARNESS / result["evidencePath"]
    require(sha(evidence_path) == result["evidenceSHA256"], f"N4 evidence hash mismatch: {result['id']}")
    case = json.loads(evidence_path.read_text())
    case_inventory.append({"id": result["id"], "path": str(evidence_path.relative_to(ROOT)), "bytes": evidence_path.stat().st_size, "sha256": sha(evidence_path)})
    by_id[result["id"]] = (result, case)
    require(result["infrastructureErrors"] == [] and result["pageErrors"] == [], f"N4 infrastructure/page errors: {result['id']}")

for name in ["healthy-react", "healthy-dom", "healthy-swap"]:
    result, case = by_id[name]
    require(result["activated"] is False and result["activationCount"] == 0 and result["eventsObserved"] == 50 and result["traceTicks"] == 46, f"healthy default-off behavior mismatch: {name}")
    require(case.get("baselineCheck", {}).get("status") == "matched", f"healthy baseline mismatch: {name}")
    require(case["observedChannels"] == [] and case["probeException"] is None, f"healthy observation mismatch: {name}")

fault_summaries = []
for backend in ["react", "dom"]:
    for family in ["text-corruption", "key-order", "enabled-control", "drop-click", "duplicate-click"]:
        name = f"fault-{backend}-{family}"
        result, case = by_id[name]
        activation = case["activation"]
        require(result["activated"] is True and result["activationCount"] == 1 and activation["activationCount"] == 1, f"fault activation count mismatch: {name}")
        record = activation["records"][0]
        if family in {"drop-click", "duplicate-click"}:
            require(record["eventIndex"] == 0 and activation["eventIndex"] == 0, f"click fault did not activate at event 0: {name}")
            expected_forward = 0 if family == "drop-click" else 2
            require(record["callbackInvocationsAfter"]["rendererDispatch"] == 1, f"renderer callback was not observed once: {name}")
            require(record["callbackInvocationsAfter"]["forwardedDispatch"] == expected_forward, f"actual callback forwarding mismatch: {name}")
        else:
            require(record["eventIndex"] is None and record["target"]["before"] != record["target"]["after"], f"initial fault did not mutate an actual target: {name}")
        require(case["channelComparisons"]["dom"]["expected"] != case["channelComparisons"]["dom"]["observed"], f"physical DOM channel does not differ: {name}")
        require("dom" in result["observedChannels"], f"physical DOM channel was not observed: {name}")
        if family == "enabled-control":
            require("disabled" in result["observedChannels"] and record["target"]["before"]["disabled"] is True and record["target"]["after"]["disabled"] is False, f"enabled control mutation missing: {name}")
        fault_summaries.append({"id": name, "activationCount": result["activationCount"], "eventIndex": record["eventIndex"], "observedChannels": result["observedChannels"]})

swap = by_id["healthy-swap"][1]["profile"]
accepted = next(item for item in swap["swaps"] if item["accepted"])
retired = accepted["after"]["retiredCallback"]
require(retired["dispatch"]["stale"] is True and retired["stale"]["stale"] is True and retired["fence"]["tickCountUnchanged"] and retired["fence"]["snapshotUnchanged"], "healthy retired-renderer fencing mismatch")
delivery = swap["staleDeliveries"][0]
require(delivery["result"]["accepted"] is False and delivery["invariants"]["traceUnchanged"] and delivery["invariants"]["pendingUnchanged"], "healthy cancelled reply fencing mismatch")
require(by_id["healthy-swap"][1]["baselineCheck"]["status"] == "matched", "healthy swap baseline failed")

probe = json.loads((XRLOG / "failed-profile-dispose.stdout.json").read_text())
probe_exit = int((XRLOG / "failed-profile-dispose.exit-code").read_text().strip())
require(probe_exit == 0 and probe["failedReplay"] is True and probe["mountedAtInspection"] is True, "failed-profile disposal probe did not inspect mounted failed profile")
require(probe["physicalMatchesActual"] is True and "fault" not in probe["physicalHTML"], "inspectRaw did not reflect actual mounted physical HTML")
require(probe["disposeIdempotent"] is True and probe["firstDispose"]["physicalDOMCleared"] is True and probe["firstDispose"]["errors"] == [], "browser dispose was not safe/idempotent")
require(probe["secondAdapterDispose"]["listenerRemoved"] is True and probe["physicalDOMCleared"] is True and probe["pageErrors"] == [], "decorator listener/container cleanup failed")

result = {
    "schema": "gobi.backend-qualification-adapters-review-audit/v1",
    "decision": "accepted",
    "sourcePins": pins,
    "sealedEAdaptersCopiesMatch": seal_matches,
    "independentTests": {"node": (XRLOG / "node-version.stdout.log").read_text().strip(), "passed": 6, "failed": 0, "exitCode": test_exit, "syntaxExitCodes": syntax},
    "n4": {
        "rawReportPath": str(raw_path.relative_to(ROOT)), "rawReportBytes": raw_path.stat().st_size, "rawReportSHA256": sha(raw_path),
        "summaryPath": str(summary_path.relative_to(ROOT)), "summaryBytes": summary_path.stat().st_size, "summarySHA256": sha(summary_path),
        "matrix": summary["matrix"], "sourceAttestation": summary["sourceAttestation"], "sourcePinsStable": summary["sourcePinsStable"],
        "healthy": [{"id": name, "eventsObserved": by_id[name][0]["eventsObserved"], "traceTicks": by_id[name][0]["traceTicks"], "activationCount": by_id[name][0]["activationCount"], "baseline": by_id[name][1]["baselineCheck"]["status"]} for name in ["healthy-react", "healthy-dom", "healthy-swap"]],
        "faults": fault_summaries,
        "staleRendererDispatchAndStaleCallbackFenced": True,
        "cancelledOldReplyRejectedWithoutStateChange": True,
        "caseEvidence": case_inventory,
    },
    "failedMountedProfileProbe": {
        "path": "backend-qualification/coordination/rawlogs/XR-ADAPTERS/failed-profile-dispose.stdout.json",
        "browserVersion": probe["browserVersion"], "failedReplay": probe["failedReplay"], "mountedAtInspection": probe["mountedAtInspection"],
        "inspectRawMatchesLiveDOM": probe["physicalMatchesActual"], "disposeIdempotent": probe["disposeIdempotent"],
        "physicalDOMCleared": probe["physicalDOMCleared"], "listenerRemoved": probe["secondAdapterDispose"]["listenerRemoved"],
        "pageErrors": probe["pageErrors"], "exitCode": probe_exit,
    },
}
print(json.dumps(result, indent=2))
