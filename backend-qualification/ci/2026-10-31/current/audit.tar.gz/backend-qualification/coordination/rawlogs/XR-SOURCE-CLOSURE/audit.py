from __future__ import annotations

import hashlib
import json
import os
import re
from collections import deque
from pathlib import Path

ROOT = Path.cwd()
COORD = ROOT / "backend-qualification/coordination"
MANIFEST_PATH = COORD / "rawlogs/E-SOURCE-CLOSURE/source-closure-manifest.json"
manifest = json.loads(MANIFEST_PATH.read_text())
runner_path = ROOT / "backend-qualification/run.mjs"
runner_text = runner_path.read_text()


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pin(path: Path) -> dict[str, object]:
    return {"path": path.as_posix(), "bytes": path.stat().st_size, "sha256": sha(path)}


def source_array(text: str, name: str) -> list[str]:
    match = re.search(rf"const {name} = \[(.*?)\n\];", text, re.S)
    if not match:
        raise RuntimeError(f"cannot parse {name} from current runner")
    return re.findall(r'"([^"]+)"', match.group(1))


excluded = {
    ".git", "node_modules", "output", "evidence", "coordination", "rawlogs",
    "reports", "receipts", "attempts", "__pycache__", ".cache", "review-evidence",
}
current_source_files = source_array(runner_text, "sourceFiles")
current_source_dirs = source_array(runner_text, "sourceDirectories")
current_paths = set(current_source_files)
for directory in current_source_dirs:
    base = ROOT / directory
    if not base.exists():
        continue
    for root, dirs, files in os.walk(base):
        dirs[:] = sorted(name for name in dirs if name not in excluded)
        for name in files:
            path = Path(root) / name
            if path.is_file():
                current_paths.add(path.relative_to(ROOT).as_posix())

old_paths = {entry["path"] for entry in manifest["paths"]}
added = sorted(current_paths - old_paths)
removed = sorted(old_paths - current_paths)
missing_old_files = sorted(path for path in old_paths if not (ROOT / path).is_file())

build_input = json.loads((ROOT / manifest["n2BuildInput"]["path"]).read_text())
n2_paths = set(build_input.get("sourcePins", build_input))
review_evidence = manifest["reviewEvidence"]["paths"]

helper = Path("compiled-children/browser-version.mjs")
helper_test = Path("compiled-children/conformance/browser-version.test.mjs")
workflow_path = Path(".github/workflows/gobi-backend-qualification.yml")
workflow_text = (ROOT / workflow_path).read_text()
workflow_patterns = set(re.findall(r"^\s+- '([^']+)'\s*$", workflow_text, re.M))
required_shared_tests = '"compiled-children/conformance/browser-version.test.mjs"' in runner_text
helper_imported = 'from "../compiled-children/browser-version.mjs"' in runner_text

current_boundary_issues = []
for path in [helper.as_posix(), helper_test.as_posix()]:
    if path not in current_paths:
        current_boundary_issues.append(f"new runner dependency absent from sourcePins set: {path}")
    if path not in workflow_patterns:
        current_boundary_issues.append(f"new runner dependency absent from workflow path filters: {path}")
if not helper_imported:
    current_boundary_issues.append("current runner does not import the Chromium version helper")
if not required_shared_tests:
    current_boundary_issues.append("current runner does not require the Chromium helper test")

current_runtime_test_paths = manifest["runtimeTestPathChecklist"] + [helper_test.as_posix()]
todo = deque(path for path in current_runtime_test_paths if path.endswith((".mjs", ".js", ".cjs")))
visited: set[str] = set()
missing_imports: list[dict[str, str]] = []
external_node_modules: set[str] = set()
external_packages: set[str] = set()
import_pattern = re.compile(r'(?:from\s*|import\s*\()\s*["\']([^"\']+)["\']')
while todo:
    source = todo.popleft()
    if source in visited:
        continue
    visited.add(source)
    source_path = ROOT / source
    if not source_path.is_file():
        missing_imports.append({"from": source, "specifier": "<source seed missing>"})
        continue
    for specifier in import_pattern.findall(source_path.read_text(errors="replace")):
        if not specifier.startswith("."):
            if not specifier.startswith("node:") and re.fullmatch(r"[A-Za-z0-9@][A-Za-z0-9@/._-]*", specifier):
                external_packages.add(specifier)
            continue
        lexical_target = source_path.parent / specifier
        if "node_modules" in lexical_target.parts:
            external_node_modules.add(specifier)
            continue
        target = lexical_target.resolve()
        candidates = [target, *(Path(str(target) + suffix) for suffix in (".mjs", ".js", ".json"))]
        resolved = next((candidate for candidate in candidates if candidate.is_file()), None)
        if resolved is None:
            missing_imports.append({"from": source, "specifier": specifier})
            continue
        try:
            relative_target = resolved.relative_to(ROOT).as_posix()
        except ValueError:
            missing_imports.append({"from": source, "specifier": specifier, "target": str(resolved)})
            continue
        if relative_target not in current_paths:
            missing_imports.append({"from": source, "specifier": specifier, "target": relative_target})
        todo.append(relative_target)

old_seal_checks = []
for live, sealed in [
    (COORD / "reports/E-SOURCE-CLOSURE.md", COORD / "seals/E-SOURCE-CLOSURE/reports/E-SOURCE-CLOSURE.md"),
    (COORD / "receipts/E-SOURCE-CLOSURE.json", COORD / "seals/E-SOURCE-CLOSURE/receipts/E-SOURCE-CLOSURE.json"),
]:
    old_seal_checks.append({"live": pin(live), "sealed": pin(sealed), "byteIdentical": live.read_bytes() == sealed.read_bytes()})

source_files_outside = {
    "qualificationRunner": pin(runner_path),
    "qualificationWorkflow": pin(ROOT / workflow_path),
    "chromiumHelper": pin(ROOT / helper),
    "chromiumHelperTest": pin(ROOT / helper_test),
    "currentQPublicationsRunner": pin(ROOT / "compiled-publications/run.mjs"),
    "parentPublicationsRunner": pin(Path("/workspace/scratch/39a56936f173/gondola-publications/compiled-publications/run.mjs")),
    "cleanPublicationsRunner": pin(Path("/workspace/scratch/39a56936f173/gondola-publications-clean/compiled-publications/run.mjs")),
    "parentPublicationsWorkflow": pin(Path("/workspace/scratch/39a56936f173/gondola-publications/.github/workflows/gobi-compiled-publications.yml")),
    "cleanPublicationsWorkflow": pin(Path("/workspace/scratch/39a56936f173/gondola-publications-clean/.github/workflows/gobi-compiled-publications.yml")),
    "currentQPublicationsConformanceRun": pin(ROOT / "compiled-publications/conformance/run.mjs"),
    "parentPublicationsConformanceRun": pin(Path("/workspace/scratch/39a56936f173/gondola-publications/compiled-publications/conformance/run.mjs")),
}

parent_publications_runner_in_current_set = "compiled-publications/run.mjs" in current_paths
parent_publications_workflow_in_current_set = ".github/workflows/gobi-compiled-publications.yml" in current_paths
runner_imports_parent_publications_runner = bool(re.search(r"(?:from|import\s*\()\s*[\"'](?:\.\./)*compiled-publications/run\.mjs", runner_text))

author_inputs = manifest["authorArtifactInputs"]
current_runner_fresh_attempt = (
    "const attemptId = `attempt-${new Date().toISOString()" in runner_text
    and "createExclusiveAttemptDirectory(attemptRoot)" in runner_text
    and '"E-HARNESS"' not in runner_text
    and '"E-GO"' not in runner_text
    and "/tmp/gobi-backend-qualification" not in runner_text
)

result = {
    "schema": "gobi.backend-qualification-source-closure-review/v1",
    "oldSnapshot": {
        "report": pin(COORD / "reports/E-SOURCE-CLOSURE.md"),
        "receipt": pin(COORD / "receipts/E-SOURCE-CLOSURE.json"),
        "manifest": pin(MANIFEST_PATH),
        "pathCount": manifest["pathCount"],
        "oldPathListCount": len(old_paths),
        "allOldPathsStillExist": not missing_old_files,
        "missingOldPaths": missing_old_files,
        "n2BuildInputs": manifest["n2BuildInput"]["pinCount"],
        "n2BuildInputPathsCoveredByOldBoundary": len(n2_paths & old_paths) == 87,
        "n2BuildInputPathsCoveredByCurrentBoundary": len(n2_paths & current_paths) == 87,
        "reviewEvidenceFiles": manifest["reviewEvidence"]["count"],
        "reviewEvidenceBytes": manifest["reviewEvidence"]["bytes"],
        "oldInternalJSImportModules": manifest["javascriptImportClosure"]["internalModuleCount"],
        "oldMissingOrUnpinnedImports": manifest["javascriptImportClosure"]["missingOrUnpinnedImports"],
        "forcedStageCandidates": manifest["forcedStageCandidates"],
        "authorArtifactInputs": author_inputs,
        "reportReceiptMatchSeals": all(item["byteIdentical"] for item in old_seal_checks),
        "sealChecks": old_seal_checks,
    },
    "currentN6Delta": {
        "oldPathCount": len(old_paths),
        "currentPathCount": len(current_paths),
        "added": added,
        "removed": removed,
        "runnerAndWorkflowCurrentPinsDifferFromOldSnapshot": {
            "runner": manifest["runner"]["sha256"] != sha(runner_path),
            "workflow": manifest["workflow"]["sha256"] != sha(ROOT / workflow_path),
        },
        "currentNewInputPins": [pin(ROOT / helper), pin(ROOT / helper_test)],
        "runnerImportsHelper": helper_imported,
        "runnerSourceFilesIncludeBoth": all(path in current_source_files for path in [helper.as_posix(), helper_test.as_posix()]),
        "runnerExplicitlyRunsTest": required_shared_tests,
        "workflowFiltersIncludeBoth": all(path in workflow_patterns for path in [helper.as_posix(), helper_test.as_posix()]),
        "currentImportClosure": {
            "seedCount": len(current_runtime_test_paths),
            "internalModuleCount": len(visited),
            "missingOrUnpinnedImports": missing_imports,
            "externalLockedNodeModules": sorted(external_node_modules),
            "externalPackages": sorted(external_packages),
        },
        "issues": current_boundary_issues,
        "freshAttemptNoAuthorArtifactStaticCheck": current_runner_fresh_attempt,
    },
    "parentPR17Separation": {
        "parentModifiedRunnerPath": "compiled-publications/run.mjs",
        "parentModifiedWorkflowPath": ".github/workflows/gobi-compiled-publications.yml",
        "parentRunnerInN6Boundary": parent_publications_runner_in_current_set,
        "parentWorkflowInN6Boundary": parent_publications_workflow_in_current_set,
        "qualificationRunnerImportsParentRunner": runner_imports_parent_publications_runner,
        "parentRunnerAndWorkflowPins": {
            "parent": [source_files_outside["parentPublicationsRunner"], source_files_outside["parentPublicationsWorkflow"]],
            "clean": [source_files_outside["cleanPublicationsRunner"], source_files_outside["cleanPublicationsWorkflow"]],
            "currentQRunner": source_files_outside["currentQPublicationsRunner"],
            "currentQWorkflow": source_files_outside["qualificationWorkflow"],
        },
        "qualificationAndParentConformanceRunEqual": source_files_outside["currentQPublicationsConformanceRun"]["sha256"] == source_files_outside["parentPublicationsConformanceRun"]["sha256"],
        "newChromiumHelperAndTestMatchParentWorktree": {
            "helper": sha(ROOT / helper) == sha(Path("/workspace/scratch/39a56936f173/gondola-publications/compiled-children/browser-version.mjs")),
            "test": sha(ROOT / helper_test) == sha(Path("/workspace/scratch/39a56936f173/gondola-publications/compiled-children/conformance/browser-version.test.mjs")),
        },
        "boundaryNote": "The parent runner/workflow are a separate publication lane and are outside the 177-path N6 qualification source set. Root's inherited/legacy test gate is separate.",
    },
    "currentWorkflowBaseIdentityWiring": {
        "sourceCommitExpression": "inputs.source_commit || github.event.pull_request.head.sha || github.sha" in workflow_text,
        "checkoutSameExpression": "ref: ${{ inputs.source_commit || github.event.pull_request.head.sha || github.sha }}" in workflow_text,
        "headComparedToSourceCommit": 'test "$(git rev-parse HEAD)" = "$SOURCE_COMMIT"' in workflow_text,
        "runnerReceivesSourceCommit": 'bash run-backend-qualification.sh --source-commit "$SOURCE_COMMIT"' in workflow_text,
    },
    "scope": {"gitCommandsUsed": False, "testsOrFullPipelineRun": False, "sourceOrGitFilesChanged": False},
}
print(json.dumps(result, indent=2))
