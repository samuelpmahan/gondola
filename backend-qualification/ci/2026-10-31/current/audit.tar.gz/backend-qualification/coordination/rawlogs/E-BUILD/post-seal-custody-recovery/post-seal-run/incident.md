# Post-seal run preservation

This run was started after the original E-BUILD report/receipt were sealed. The source pin set had changed to 85 by omitting the baseline literal expectations file from sourcePins; its hash is separately recorded in provenance. The UI tool invocation was interrupted, but recorded command outputs show a complete native/React/DOM builder run. This run is preserved here and is not the sealed E-BUILD result. The post-seal builder source copy is preserved alongside this run.
