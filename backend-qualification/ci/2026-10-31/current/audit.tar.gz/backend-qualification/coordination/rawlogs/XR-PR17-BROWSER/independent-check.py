#!/usr/bin/env python3
"""Read-only review checks for the sealed E-PR17-BROWSER source and evidence."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path.cwd().resolve()
PUB = (ROOT.parent / "gondola-publications").resolve()
OUT = ROOT / "backend-qualification/coordination/rawlogs/XR-PR17-BROWSER/independent-check.json"
BASE = "5f624b9a46b56d9610e936360e9da2fe46b99a29"
BASE_TREE = "e020be3eab3b5e0f67f3e9ea7a73662e7d3bf434"
ATTEMPT = "attempt-20261031T181141849Z-6"

def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def info(path: Path, display: str | None = None) -> dict:
    b = path.read_bytes()
    return {"path": display or str(path), "bytes": len(b), "sha256": sha(b)}

def worktree_file(root: Path, rel: str) -> bytes:
    return (root / rel).read_bytes()

# Verify both source worktrees and their relationship to the supplied parent checkpoint.
source_paths = ["compiled-publications/run.mjs", ".github/workflows/gobi-compiled-publications.yml"]
source_hashes = {}
for rel in source_paths:
    pub_bytes = worktree_file(PUB, rel)
    qual_bytes = worktree_file(ROOT, rel)
    committed = subprocess.run(["git", "show", f"{BASE}:{rel}"], cwd=ROOT, check=True, capture_output=True).stdout
    assert pub_bytes == qual_bytes == committed
    source_hashes[rel] = {"publications": info(PUB / rel, rel), "qualification": info(ROOT / rel, rel), "baseCommitBlobByteIdentical": True}
base_object = subprocess.run(["git", "rev-parse", f"{BASE}^{{commit}}"], cwd=ROOT, check=True, text=True, capture_output=True).stdout.strip()
base_tree = subprocess.run(["git", "rev-parse", f"{BASE}^{{tree}}"], cwd=ROOT, check=True, text=True, capture_output=True).stdout.strip()
assert base_object == BASE and base_tree == BASE_TREE

# Verify the shared validator is called, included in both source pins and test list,
# and that the workflow preserves the PR16 chain after the new profile.
run_text = worktree_file(ROOT, "compiled-publications/run.mjs").decode()
workflow_text = worktree_file(ROOT, ".github/workflows/gobi-compiled-publications.yml").decode()
helper_rel = "compiled-children/browser-version.mjs"
test_rel = "compiled-children/conformance/browser-version.test.mjs"
helper_bytes = worktree_file(ROOT, helper_rel)
test_bytes = worktree_file(ROOT, test_rel)
helper_pub_bytes = worktree_file(PUB, helper_rel)
test_pub_bytes = worktree_file(PUB, test_rel)
assert helper_bytes == helper_pub_bytes and test_bytes == test_pub_bytes
assert f'import {{ isChromiumVersionOutput }} from "../{helper_rel}";' in run_text
assert "isChromiumVersionOutput(chromiumVersion.trim())" in run_text
assert f'"{helper_rel}"' in run_text and f'"{test_rel}"' in run_text
assert f'"{test_rel}"' in run_text[run_text.index("const nodeTests = ["):run_text.index("];", run_text.index("const nodeTests = ["))]
publication_step = workflow_text.index("- name: Run typed input and keyed publication profile")
inherited_step = workflow_text.index("- name: Run the full PR16 inherited chain")
assert publication_step < inherited_step
assert "run: bash run-compiled-publications.sh" in workflow_text[publication_step:inherited_step]
assert "run: bash run-compiled-children.sh" in workflow_text[inherited_step:]

# Verify the final author packet is distinct from the preliminary root seal and
# matches the final-author copy, including the corrected attempt receipt length.
current_report = (ROOT / "backend-qualification/coordination/reports/E-PR17-BROWSER.md").read_bytes()
current_receipt = (ROOT / "backend-qualification/coordination/receipts/E-PR17-BROWSER.json").read_bytes()
final_report = (ROOT / "backend-qualification/coordination/seals/E-PR17-BROWSER/final-author/reports/E-PR17-BROWSER.md").read_bytes()
final_receipt = (ROOT / "backend-qualification/coordination/seals/E-PR17-BROWSER/final-author/receipts/E-PR17-BROWSER.json").read_bytes()
initial_report = (ROOT / "backend-qualification/coordination/seals/E-PR17-BROWSER/reports/E-PR17-BROWSER.md").read_bytes()
initial_receipt = (ROOT / "backend-qualification/coordination/seals/E-PR17-BROWSER/receipts/E-PR17-BROWSER.json").read_bytes()
assert current_report == final_report and current_receipt == final_receipt
final_packet = json.loads(final_receipt)
initial_packet = json.loads(initial_receipt)
assert final_packet["job_id"] == "E-PR17-BROWSER" and final_packet["worker"] == "N4"
assert final_packet["verification"]["fullPublicationProfile"]["stageCount"] == 8
assert final_packet["verification"]["fullPublicationProfile"]["allStagesPassed"] is True
assert final_packet["verification"]["fullPublicationProfile"]["sourcePinDiffCount"] == 0
assert final_packet["verification"]["fullPublicationProfile"]["attemptReceipt"]["bytes"] == 243906
assert final_packet["verification"]["fullPublicationProfile"]["attemptReceipt"]["sha256"] == "f95934cfe17e8b5e97e3afa5d01115fd78238709ff9f07a1d6caf31c15ed0954"
assert initial_packet["verification"]["fullPublicationProfile"]["attemptReceipt"]["bytes"] == 0

attempt_root = PUB / "compiled-publications/demo/output/attempts" / ATTEMPT
attempt_receipt_path = PUB / "compiled-publications/evidence/attempts" / ATTEMPT / "receipt.json"
attempt_report_path = PUB / "compiled-publications/evidence/attempts" / ATTEMPT / "report.md"
archive_path = attempt_root.with_suffix(".tar.gz")
manifest_path = attempt_root.with_suffix(".archive-manifest.json")
consumer_path = PUB / "compiled-publications/evidence/attempts" / ATTEMPT / "independent-archive-consumer.json"
actual_attempt_receipt = json.loads(attempt_receipt_path.read_text())
assert len(attempt_receipt_path.read_bytes()) == 243906
assert sha(attempt_receipt_path.read_bytes()) == final_packet["verification"]["fullPublicationProfile"]["attemptReceipt"]["sha256"]
assert actual_attempt_receipt["status"] == "passed" and actual_attempt_receipt["finalAcceptance"] is True
assert len(actual_attempt_receipt["stages"]) == 8 and all(s["status"] == "passed" for s in actual_attempt_receipt["stages"])
assert len(actual_attempt_receipt["sourceBefore"]) == 130
assert len(actual_attempt_receipt["sourceAfter"]) == 130
assert actual_attempt_receipt["sourcePinsMatch"] is True
archive_pin = final_packet["verification"]["fullPublicationProfile"]["archive"]
assert archive_path.stat().st_size == archive_pin["bytes"]
assert sha(archive_path.read_bytes()) == archive_pin["sha256"]
manifest_bytes = manifest_path.read_bytes()
manifest = json.loads(manifest_bytes)
assert len(manifest["members"]) == 363 and actual_attempt_receipt["archive"]["memberCount"] == 363
assert sha(manifest_bytes) == actual_attempt_receipt["archive"]["manifest"]["sha256"]
consumer = json.loads(consumer_path.read_text())
assert consumer["status"] == "passed" and consumer["members"] == 363
with tarfile.open(archive_path, "r:gz") as archive:
    archived_names = archive.getnames()
assert len(archived_names) == 363
assert sorted(archived_names) == sorted(item["path"] for item in manifest["members"])
report_pin = final_packet["verification"]["fullPublicationProfile"]["attemptReport"]
assert len(attempt_report_path.read_bytes()) == report_pin["bytes"]
assert sha(attempt_report_path.read_bytes()) == report_pin["sha256"]

# Check the point-in-time hosted CI observation. It proves profile success only;
# the inherited step is still running and qualification is still queued there.
ci_path = ROOT / "backend-qualification/coordination/pr17-ci-hotfix-observed.json"
ci = json.loads(ci_path.read_text())
assert ci["sourceCommit"] == BASE and ci["runId"] == 41228270986
job = ci["observation"][0]
assert job["id"] == 124616896941 and job["status"] == "in_progress"
steps = {step["name"]: step for step in job["steps"]}
assert steps["Run typed input and keyed publication profile"]["conclusion"] == "success"
assert steps["Run the full PR16 inherited chain"]["status"] == "in_progress"
assert len(ci["qualificationPending"]) == 1 and ci["qualificationPending"][0]["status"] == "queued"

result = {
    "schema": "gobi.pr17-browser-independent-review-check/v1",
    "base": {"commit": base_object, "tree": base_tree},
    "sourceCopies": source_hashes,
    "sharedHelper": {
        "path": helper_rel,
        "bytes": len(helper_bytes),
        "sha256": sha(helper_bytes),
        "testPath": test_rel,
        "testBytes": len(test_bytes),
        "testSha256": sha(test_bytes),
        "publicationHelperByteIdentical": helper_bytes == helper_pub_bytes,
        "publicationTestByteIdentical": test_bytes == test_pub_bytes,
        "importedAndCalled": True,
        "bothFilesInSourcePins": True,
        "helperTestInFocusedList": True,
    },
    "workflow": {"publicationProfileBeforeInheritedChain": True, "inheritedCommand": "bash run-compiled-children.sh"},
    "finalAuthorPacket": {
        "report": {"bytes": len(final_report), "sha256": sha(final_report), "matchesCurrent": True},
        "receipt": {"bytes": len(final_receipt), "sha256": sha(final_receipt), "matchesCurrent": True},
        "preliminarySeal": {"reportSha256": sha(initial_report), "receiptSha256": sha(initial_receipt), "attemptReceiptBytesField": initial_packet["verification"]["fullPublicationProfile"]["attemptReceipt"]["bytes"]},
        "correctedAttemptReceiptBytes": len(attempt_receipt_path.read_bytes()),
    },
    "localAttempt": {
        "attempt": ATTEMPT,
        "status": actual_attempt_receipt["status"],
        "receipt": info(attempt_receipt_path, str(attempt_receipt_path.relative_to(PUB))),
        "report": info(attempt_report_path, str(attempt_report_path.relative_to(PUB))),
        "sourcePinsBefore": len(actual_attempt_receipt["sourceBefore"]),
        "sourcePinsAfter": len(actual_attempt_receipt["sourceAfter"]),
        "sourcePinDiffCount": final_packet["verification"]["fullPublicationProfile"]["sourcePinDiffCount"],
        "stages": [{"name": s["name"], "status": s["status"]} for s in actual_attempt_receipt["stages"]],
        "archive": {"path": str(archive_path.relative_to(PUB)), "bytes": archive_path.stat().st_size, "sha256": sha(archive_path.read_bytes()), "manifest": info(manifest_path, str(manifest_path.relative_to(PUB))), "manifestMembers": len(manifest["members"]), "tarMembers": len(archived_names), "consumer": info(consumer_path, str(consumer_path.relative_to(PUB))), "consumerPassed": consumer["status"] == "passed"},
    },
    "hostedCISnapshot": {
        "path": str(ci_path.relative_to(ROOT)),
        "sha256": sha(ci_path.read_bytes()),
        "checkedAt": ci["checkedAt"],
        "runId": ci["runId"],
        "jobId": job["id"],
        "publicationProfileConclusion": steps["Run typed input and keyed publication profile"]["conclusion"],
        "inheritedChainStatus": steps["Run the full PR16 inherited chain"]["status"],
        "qualificationStatus": ci["qualificationPending"][0]["status"],
    },
}
OUT.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
