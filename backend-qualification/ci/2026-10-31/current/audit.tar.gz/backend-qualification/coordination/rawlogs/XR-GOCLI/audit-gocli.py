import hashlib
import json
import pathlib

root = pathlib.Path.cwd()
def data(path):
    return (root / path).read_bytes()
def pin(path):
    value = data(path)
    return {"path": path, "bytes": len(value), "sha256": hashlib.sha256(value).hexdigest()}

report_path = "backend-qualification/coordination/reports/E-GOCLI.md"
receipt_path = "backend-qualification/coordination/receipts/E-GOCLI.json"
receipt = json.loads(data(receipt_path))
actual_inputs = json.loads(data("backend-qualification/coordination/rawlogs/E-GOCLI/actual-inputs.json"))
actual_raw_path = pathlib.Path(actual_inputs["rawReport"]["path"])
actual_raw_bytes = actual_raw_path.read_bytes()
actual_raw = json.loads(actual_raw_bytes)
certificate_path = pathlib.Path("backend-qualification/coordination/rawlogs/E-GOCLI/actual-certificate.json")
certificate_bytes = certificate_path.read_bytes()
certificate = json.loads(certificate_bytes)
actual_certificate_path = pathlib.Path("/tmp/gobi-backend-qualification-E-GOCLI-20261031/certificate.json")
actual_certificate_bytes = actual_certificate_path.read_bytes()
source = {key: pin(path) for key, path in (
    ("main", "cmd/backend-qualification/main.go"),
    ("tests", "cmd/backend-qualification/main_test.go"),
)}
source_pin_mismatches = []
for path, expected in receipt["reviewed_source_sha256"].items():
    body = data(path)
    if len(body) != expected["bytes"] or hashlib.sha256(body).hexdigest() != expected["sha256"]:
        source_pin_mismatches.append(path)
case_evidence = []
for row in actual_raw["results"]:
    case_path = actual_raw_path.parent / row["evidencePath"]
    body = case_path.read_bytes()
    case_evidence.append({
        "id": row["id"],
        "bytes": len(body),
        "sha256": hashlib.sha256(body).hexdigest(),
        "matches_report": hashlib.sha256(body).hexdigest() == row["evidenceSHA256"],
    })

main_text = data("cmd/backend-qualification/main.go").decode("utf-8")
main_test_text = data("cmd/backend-qualification/main_test.go").decode("utf-8")
go_log = pathlib.Path("backend-qualification/coordination/rawlogs/E-GOCLI/go-packages.stdout.log").read_text()
node_log = pathlib.Path("backend-qualification/coordination/rawlogs/E-GOCLI/oracle-cli.stdout.log").read_text()
help_red = pathlib.Path("backend-qualification/coordination/rawlogs/E-GOCLI/tests/help-stderr-red/output.log").read_text()
env_red = pathlib.Path("backend-qualification/coordination/rawlogs/E-GOCLI/oracle-cli-missing-gobin/observed-failure.md").read_text()

result = {
    "sealed_packet": {
        "report_matches_seal": data(report_path) == data("backend-qualification/coordination/seals/E-GOCLI/reports/E-GOCLI.md"),
        "receipt_matches_seal": data(receipt_path) == data("backend-qualification/coordination/seals/E-GOCLI/receipts/E-GOCLI.json"),
        "report_sha256": hashlib.sha256(data(report_path)).hexdigest(),
        "receipt_sha256": hashlib.sha256(data(receipt_path)).hexdigest(),
    },
    "source": {
        **source,
        "reviewed_source_pin_count": len(receipt["reviewed_source_sha256"]),
        "reviewed_source_pin_mismatches": source_pin_mismatches,
        "main_invokes_go_certifier_before_writer": main_text.index("backendqualification.CertifyFile") < main_text.index("backendqualification.WriteCertificate"),
        "main_exits_nonzero_on_error": "os.Exit(1)" in main_text,
        "same_path_guard_present": "sameFilesystemPath(*inputPath, *outputPath)" in main_text,
        "unit_tests_check_same_path_preserves_input": "input changed after rejected same-path invocation" in main_test_text,
        "unit_tests_check_bad_input_creates_no_certificate": "certificate exists after failed certification" in main_test_text and "certificate exists after failed input open" in main_test_text,
    },
    "actual_input": {
        "path": actual_inputs["rawReport"]["path"],
        "bytes": len(actual_raw_bytes),
        "sha256": hashlib.sha256(actual_raw_bytes).hexdigest(),
        "matches_receipt": len(actual_raw_bytes) == actual_inputs["rawReport"]["bytes"] and hashlib.sha256(actual_raw_bytes).hexdigest() == actual_inputs["rawReport"]["sha256"],
        "schema": actual_raw["schema"],
        "sourceCommit": actual_raw["sourceCommit"],
        "case_count": len(actual_raw["results"]),
        "case_evidence": case_evidence,
        "all_case_evidence_hashes_match": all(row["matches_report"] for row in case_evidence),
    },
    "actual_certificate": {
        "bytes": len(certificate_bytes),
        "sha256": hashlib.sha256(certificate_bytes).hexdigest(),
        "matches_receipt": len(certificate_bytes) == receipt["certificate"]["bytes"] and hashlib.sha256(certificate_bytes).hexdigest() == receipt["certificate"]["sha256"],
        "schema": certificate["schema"],
        "qualified": certificate["qualified"],
        "result_count": len(certificate["results"]),
        "passed_count": sum(bool(row["passed"]) for row in certificate["results"]),
        "failed_case_ids": [row["id"] for row in certificate["results"] if not row["passed"]],
        "ids_match_input": {row["id"] for row in certificate["results"]} == {row["id"] for row in actual_raw["results"]},
        "rawlog_copy_matches_actual_cli_output": certificate_bytes == actual_certificate_bytes,
        "actual_cli_output_sha256": hashlib.sha256(actual_certificate_bytes).hexdigest(),
    },
    "recorded_tests": {
        "go_package_exit_code": pathlib.Path("backend-qualification/coordination/rawlogs/E-GOCLI/go-packages.exit-code").read_text().strip(),
        "node_suite_exit_code": pathlib.Path("backend-qualification/coordination/rawlogs/E-GOCLI/oracle-cli.exit-code").read_text().strip(),
        "go_package_results_present": "github.com/samuelpmahan/gondola/backendqualification" in go_log and "github.com/samuelpmahan/gondola/cmd/backend-qualification" in go_log,
        "node_blackbox_15_of_15": "# tests 15\n# suites 0\n# pass 15\n# fail 0" in node_log,
        "help_output_red_preserved": "help wrote unexpected stderr" in help_red,
        "missing_gobin_red_preserved": "spawnSync go ENOENT" in env_red,
    },
}
print(json.dumps(result, indent=2, sort_keys=True))
