import hashlib
import json
import pathlib

root = pathlib.Path.cwd()
receipt = json.loads(pathlib.Path("backend-qualification/coordination/receipts/XR-GOCLI.json").read_text())
if receipt.get("job_id") != "XR-GOCLI" or receipt.get("worker") != "N3":
    raise SystemExit("review receipt job_id/worker mismatch")
if receipt.get("decision") not in {"accepted", "amend", "rejected"}:
    raise SystemExit("review receipt decision missing or invalid")
if not isinstance(receipt.get("summary"), str) or not receipt["summary"].strip():
    raise SystemExit("review receipt summary missing")
source_pins = [value for value in receipt["source"].values() if isinstance(value, dict) and "path" in value]
for item in [*source_pins, receipt["report"], *receipt["evidence"]]:
    data = pathlib.Path(item["path"]).read_bytes() if pathlib.Path(item["path"]).is_absolute() else (root / item["path"]).read_bytes()
    if len(data) != item["bytes"] or hashlib.sha256(data).hexdigest() != item["sha256"]:
        raise SystemExit(f"pin mismatch: {item['path']}")
print("PASS: XR-GOCLI receipt fields and every source, report, and rawlog pin matched.")
