import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';

const receiptPath = 'backend-qualification/coordination/receipts/XR-ORACLE.json';
const receipt = JSON.parse(readFileSync(receiptPath));
const sha256 = path => createHash('sha256').update(readFileSync(path)).digest('hex');
const pinned = [
  [receipt.inputs.eOracleReport.path, receipt.inputs.eOracleReport.sha256],
  [receipt.inputs.eOracleReceipt.path, receipt.inputs.eOracleReceipt.sha256],
  [receipt.inputs.plan.path, receipt.inputs.plan.sha256],
  [receipt.inputs.oracleModule.path, receipt.inputs.oracleModule.sha256],
  [receipt.inputs.oracleTests.path, receipt.inputs.oracleTests.sha256],
  [receipt.inputs.actualCapture.path, receipt.inputs.actualCapture.sha256],
  [receipt.inputs.goCertificate.path, receipt.inputs.goCertificate.sha256],
  [receipt.verification.reviewerRerun.rawLog, receipt.verification.reviewerRerun.rawLogSha256],
  [receipt.verification.caseInventory.path, receipt.verification.caseInventory.sha256],
  [receipt.report.path, receipt.report.sha256],
];
for (const [path, expected] of pinned) {
  const actual = sha256(path);
  if (actual !== expected) throw new Error(`${path} hash mismatch: ${actual} != ${expected}`);
  console.log(`${actual}  ${path}`);
}
const capture = JSON.parse(readFileSync(receipt.inputs.actualCapture.path));
const certificate = JSON.parse(readFileSync(receipt.inputs.goCertificate.path));
if (capture.results.length !== 13) throw new Error(`capture has ${capture.results.length} cases`);
if (certificate.qualified !== true || certificate.results.length !== 13 || certificate.results.some(row => !row.passed)) {
  throw new Error('Go certificate is not qualified 13/13');
}
console.log('capture cases=13; Go certificate=qualified, 13/13');
