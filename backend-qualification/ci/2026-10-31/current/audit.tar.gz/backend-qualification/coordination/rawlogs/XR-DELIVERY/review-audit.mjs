import { createHash } from 'node:crypto';
import { readFile, stat, writeFile } from 'node:fs/promises';
import { resolve, sep } from 'node:path';

const root = process.cwd();
const attempt = 'backend-qualification/output/attempts/attempt-20261031T181327827Z-18';
const runtimeReceiptPath = 'backend-qualification/evidence/attempts/attempt-20261031T181327827Z-18/receipt.json';
const runtimeReportPath = 'backend-qualification/evidence/attempts/attempt-20261031T181327827Z-18/report.md';
const load = async path => JSON.parse(await readFile(resolve(root, path), 'utf8'));
const bytes = async path => readFile(resolve(root, path));
const sha = data => createHash('sha256').update(data).digest('hex');
const failures = [];
const expect = (condition, message) => { if (!condition) failures.push(message); };
const reviewerReceipt = await load('backend-qualification/coordination/receipts/E-DELIVERY.json');
const runtime = await load(runtimeReceiptPath);
const raw = await load(`${attempt}/qualification/qualification.raw.json`);
const summary = await load(`${attempt}/qualification/qualification.summary.json`);
const certificate = await load(`${attempt}/certificate/certificate.json`);
const provenance = await load(`${attempt}/inputs/provenance/build-inputs.json`);
const viewer = await load(`${attempt}/demo/site/viewer-data.json`);
const smoke = await load(`${attempt}/demo/http-smoke.json`);
const manifestPath = `${attempt}.archive-manifest.json`;
const archivePath = `${attempt}.tar.gz`;
const manifest = await load(manifestPath);
const consumer = await load('backend-qualification/evidence/attempts/attempt-20261031T181327827Z-18/independent-archive-consumer.json');
const standalone = await load('backend-qualification/coordination/rawlogs/XR-DELIVERY/standalone-archive-reverification.json');

const sealedReport = await bytes('backend-qualification/coordination/seals/E-DELIVERY/reports/E-DELIVERY.md');
const activeReport = await bytes('backend-qualification/coordination/reports/E-DELIVERY.md');
const sealedReceipt = await bytes('backend-qualification/coordination/seals/E-DELIVERY/receipts/E-DELIVERY.json');
const activeReceipt = await bytes('backend-qualification/coordination/receipts/E-DELIVERY.json');
expect(sealedReport.equals(activeReport), 'active E-DELIVERY report differs from sealed bytes');
expect(sealedReceipt.equals(activeReceipt), 'active E-DELIVERY receipt differs from sealed bytes');

const before = runtime.sourceBefore ?? {};
const after = runtime.sourceAfter ?? {};
const sourcePaths = Object.keys(before).sort();
expect(sourcePaths.length === 177, `outer source pin count=${sourcePaths.length}, expected 177`);
expect(Object.keys(after).length === 177, `outer source after count=${Object.keys(after).length}, expected 177`);
expect(runtime.sourcePinsMatch === true, 'runtime receipt sourcePinsMatch is not true');
expect(JSON.stringify(before) === JSON.stringify(after), 'before/after source pin maps differ');
const sourceMismatches = [];
for (const path of sourcePaths) {
  const b = before[path];
  const a = after[path];
  if (!b || !a || b.bytes !== a.bytes || b.sha256 !== a.sha256) {
    sourceMismatches.push({ path, before: b ?? null, after: a ?? null, actual: null });
    continue;
  }
  const full = resolve(root, path);
  if (!full.startsWith(`${root}${sep}`)) {
    sourceMismatches.push({ path, reason: 'pin path escapes source root' });
    continue;
  }
  try {
    const file = await bytes(full);
    if (file.length !== b.bytes || sha(file) !== b.sha256) sourceMismatches.push({ path, expected: b, actual: { bytes: file.length, sha256: sha(file) } });
  } catch (error) {
    sourceMismatches.push({ path, reason: String(error) });
  }
}
expect(sourceMismatches.length === 0, `current source pin mismatches=${sourceMismatches.length}`);
const buildPins = provenance.sourcePins ?? {};
const buildPinMismatches = [];
for (const [path, pin] of Object.entries(buildPins)) {
  if (!before[path] || before[path].bytes !== pin.bytes || before[path].sha256 !== pin.sha256) buildPinMismatches.push(path);
}
expect(Object.keys(buildPins).length === 87, `N2 build provenance pin count=${Object.keys(buildPins).length}, expected 87`);
expect(provenance.sourcePinsMatchAfterBuild === true && buildPinMismatches.length === 0, `N2 pin comparison failed (${buildPinMismatches.length} mismatches)`);

expect(raw.schema === 'gobi.backend-qualification-run/v1', 'raw capture schema mismatch');
expect(raw.sourceCommit === '77f7ce36439f1ae457a397269ea5a8c6d2db1cb2', 'raw capture candidate sourceCommit mismatch');
expect(raw.results?.length === 13, `raw case count=${raw.results?.length}`);
expect(summary.status === 'matched', `qualification summary status=${summary.status}`);
const baseline = summary.baseline;
expect(baseline?.status === 'matched', `literal baseline status=${baseline?.status}`);
expect(baseline?.mutationControls?.length === 16 && baseline.mutationControls.every(row => row.detected === true), 'literal baseline did not detect all 16 mutation controls');
expect(baseline?.noWasmGuardCoverage?.status === 'complete' && baseline.noWasmGuardCoverage.entries === 10 && baseline.noWasmGuardCoverage.failures === 0, 'no-WASM guard coverage is incomplete');
expect(baseline?.seededRuns?.count === 0, 'unexpected seeded run in fixed E-DELIVERY scenario');
expect(certificate.schema === 'gobi.backend-qualification-certificate/v1' && certificate.qualified === true && certificate.results?.length === 13 && certificate.results.every(row => row.passed), 'Go certificate is not qualified 13/13');
expect(certificate.sourceCommit === raw.sourceCommit, 'Go certificate sourceCommit differs from raw capture');
const certById = new Map(certificate.results.map(row => [row.id, row]));
const evidenceChecks = [];
for (const row of raw.results ?? []) {
  const cert = certById.get(row.id);
  const evidencePath = `${attempt}/qualification/${row.evidencePath}`;
  const evidenceBytes = await bytes(evidencePath);
  const evidenceHash = sha(evidenceBytes);
  const valid = Boolean(cert) && cert.passed === true && row.evidenceSHA256 === evidenceHash && cert.evidenceSHA256 === evidenceHash && cert.id === row.id;
  evidenceChecks.push({ id: row.id, evidenceBytes: evidenceBytes.length, evidenceSHA256: evidenceHash, valid });
  expect(valid, `evidence/certificate mismatch for ${row.id}`);
  expect((row.pageErrors?.length ?? 0) === 0 && (row.infrastructureErrors?.length ?? 0) === 0, `page/infra errors in ${row.id}`);
  if (row.fault === 'none') expect(row.eventsObserved === 50 && row.traceTicks === 46 && row.activated === false && row.activationCount === 0, `healthy record incomplete: ${row.id}`);
  else expect(row.activated === true && row.activationCount === 1, `fault activation invalid: ${row.id}`);
}
expect(viewer.sourceCommit === raw.sourceCommit && viewer.qualified === certificate.qualified, 'viewer source/verdict mismatch');
expect(viewer.cases?.length === certificate.results.length, 'viewer case count mismatch');
const viewerRows = [];
for (const row of viewer.cases ?? []) {
  const id = row.raw?.id;
  const cert = certById.get(id);
  const valid = Boolean(cert) && row.certificate?.id === id && row.certificate?.passed === cert.passed && row.raw.evidenceSHA256 === row.evidenceHash && row.evidenceHash === cert.evidenceSHA256;
  viewerRows.push({ id, valid });
  expect(valid, `viewer raw/cert/evidence labels differ for ${id}`);
}
expect(smoke.status === 'passed' && smoke.checkCount === 12 && smoke.checks?.length === 12 && smoke.checks.every(row => row.passed) && (smoke.pageErrors?.length ?? 0) === 0, 'HTTP smoke not passed 12/12');

const archiveBytes = await bytes(archivePath);
const manifestBytes = await bytes(manifestPath);
expect(archiveBytes.length === 2443344 && sha(archiveBytes) === '61bb3df8c16323be5ef856edf834ac73ac69fde462224dd1ac8b35ef93ed97ca', 'archive byte/hash pin mismatch');
expect(manifestBytes.length === 75340 && sha(manifestBytes) === '8adc8f345a5b66a6ea1fbb92fe9bd510d1682f4c37d4c76e8a0660e06ce30cb1', 'manifest byte/hash pin mismatch');
expect(manifest.members?.length === 397 && consumer.status === 'passed' && consumer.members === 397, 'sealed independent consumer did not verify 397 members');
expect(standalone.status === 'passed' && standalone.members === 397 && standalone.archive.sha256 === sha(archiveBytes) && standalone.manifest.sha256 === sha(manifestBytes), 'reviewer standalone archive consumer mismatch');

const output = {
  schema: 'gobi.backend-qualification-review-audit/v1',
  status: failures.length === 0 ? 'passed' : 'failed',
  sealedReportSha256: sha(sealedReport),
  sealedReceiptSha256: sha(sealedReceipt),
  attempt: runtime.attempt,
  sourceCommit: runtime.sourceCommit,
  sourcePins: { count: sourcePaths.length, currentMismatches: sourceMismatches.length, beforeAfterEqual: JSON.stringify(before) === JSON.stringify(after), n2ProvenancePins: Object.keys(buildPins).length, n2PinMismatches: buildPinMismatches.length },
  mountedCases: { count: raw.results.length, certificateQualified: certificate.qualified, resultsPassed: certificate.results.filter(row => row.passed).length, healthyComplete: raw.results.filter(row => row.fault === 'none').length, activatedFaults: raw.results.filter(row => row.fault !== 'none' && row.activated && row.activationCount === 1).length, pageInfrastructureErrors: raw.results.reduce((n,row) => n+(row.pageErrors?.length??0)+(row.infrastructureErrors?.length??0),0), evidenceHashesVerified: evidenceChecks.filter(row => row.valid).length },
  baseline: { status: baseline.status, mutationControlsDetected: baseline.mutationControls.filter(row => row.detected).length, mutationControlCount: baseline.mutationControls.length, noWasmGuardCoverage: baseline.noWasmGuardCoverage, browserProfiles: baseline.browserProfiles, seededRuns: baseline.seededRuns },
  viewer: { sourceCommit: viewer.sourceCommit, qualified: viewer.qualified, caseCount: viewer.cases.length, caseLabelsAndEvidenceValid: viewerRows.filter(row => row.valid).length, smokeChecksPassed: smoke.checks.filter(row => row.passed).length, smokeCheckCount: smoke.checks.length },
  archive: { bytes: archiveBytes.length, sha256: sha(archiveBytes), manifestBytes: manifestBytes.length, manifestSha256: sha(manifestBytes), memberCount: manifest.members.length, producerConsumerStatus: consumer.status, reviewerConsumerStatus: standalone.status },
  failures,
};
await writeFile('backend-qualification/coordination/rawlogs/XR-DELIVERY/review-audit.json', `${JSON.stringify(output, null, 2)}\n`);
process.stdout.write(`${JSON.stringify(output, null, 2)}\n`);
if (failures.length) process.exitCode = 1;
