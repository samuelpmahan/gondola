import { createHash } from "node:crypto";
import { spawnSync } from "node:child_process";
import { cp, mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../../..");
const rawSource = "/tmp/gobi-backend-qualification-E-HARNESS-node22/qualification.raw.json";
const sourceDir = path.dirname(rawSource);
const goBin = process.env.GOBI_GO_BIN || "/tmp/gondola-go/bin/go";
const env = { ...process.env, GOTOOLCHAIN: "local", GOFLAGS: "-buildvcs=false" };
const tempRoot = await mkdtemp(path.join(os.tmpdir(), "gobi-xr-go-raw-channels-"));
const sourceBytes = await readFile(rawSource);
const report = JSON.parse(sourceBytes.toString("utf8"));
const hash = (bytes) => createHash("sha256").update(bytes).digest("hex");

async function execute(name, mutate) {
  const directory = path.join(tempRoot, name);
  await mkdir(directory, { recursive: true });
  await cp(path.join(sourceDir, "cases"), path.join(directory, "cases"), { recursive: true });
  const input = structuredClone(report);
  mutate?.(input);
  const inputPath = path.join(directory, "qualification.raw.json");
  const outputPath = path.join(directory, "certificate.json");
  await writeFile(inputPath, `${JSON.stringify(input, null, 2)}\n`);
  const result = spawnSync(goBin, ["run", "./cmd/backend-qualification", "--input", inputPath, "--output", outputPath], {
    cwd: root,
    env,
    encoding: "utf8",
    maxBuffer: 16 * 1024 * 1024,
  });
  return {
    name,
    exitCode: result.status,
    signal: result.signal ?? null,
    spawnError: result.error ? String(result.error.message ?? result.error) : null,
    stderr: result.stderr ?? "",
    certificateExists: result.status === 0,
  };
}

try {
  const base = await execute("actual", null);
  const unknown = await execute("unknown-channel", (input) => {
    input.results.find((row) => row.id === "fault-react-text-corruption").observedChannels.push("gpu-pixels");
  });
  const duplicate = await execute("duplicate-channel", (input) => {
    input.results.find((row) => row.id === "fault-react-text-corruption").observedChannels.push("dom");
  });
  console.log(JSON.stringify({
    schema: "gobi.backend-qualification-go-review-probes/v1",
    sourceReportSha256: hash(sourceBytes),
    cases: [base, unknown, duplicate],
  }, null, 2));
} finally {
  await rm(tempRoot, { recursive: true, force: true });
}
