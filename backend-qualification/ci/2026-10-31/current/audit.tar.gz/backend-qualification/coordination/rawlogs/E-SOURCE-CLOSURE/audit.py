from __future__ import annotations

import hashlib
import json
import os
import re
from collections import deque
from pathlib import Path

ROOT = Path.cwd()
RUNNER = Path("backend-qualification/run.mjs")
EXCLUDED = {
    ".git", "node_modules", "output", "evidence", "coordination", "rawlogs",
    "reports", "receipts", "attempts", "__pycache__", ".cache", "review-evidence",
}


def source_array(text: str, name: str) -> list[str]:
    match = re.search(rf"const {name} = \[(.*?)\n\];", text, re.S)
    if not match:
        raise RuntimeError(f"cannot read {name} from runner source")
    return re.findall(r'"([^"]+)"', match.group(1))


def walk_files(directory: Path) -> list[Path]:
    found: list[Path] = []
    if not directory.exists():
        return found
    with os.scandir(directory) as entries:
        ordered = sorted(entries, key=lambda entry: entry.name)
    for entry in ordered:
        path = Path(entry.path)
        if entry.is_dir(follow_symlinks=False):
            if entry.name not in EXCLUDED:
                found.extend(walk_files(path))
        elif entry.is_file(follow_symlinks=False):
            found.append(path)
    return found


def file_pin(path: str) -> dict[str, object]:
    data = Path(path).read_bytes()
    return {"path": path, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


text = RUNNER.read_text()
source_files = source_array(text, "sourceFiles")
source_dirs = source_array(text, "sourceDirectories")
paths = set(source_files)
for directory in source_dirs:
    paths.update(path.as_posix() for path in walk_files(Path(directory)))
ordered_paths = sorted(paths)

build_inputs_path = Path("backend-qualification/coordination/rawlogs/E-BUILD-BASE/build-a/build-inputs.json")
build_inputs = json.loads(build_inputs_path.read_text())
n2_pins = build_inputs.get("sourcePins", build_inputs)
n2_paths = sorted(n2_pins)

workflow = Path(".github/workflows/gobi-backend-qualification.yml").read_text()
path_block = workflow.split("    paths:\n", 1)[1].split("  workflow_dispatch:", 1)[0]
patterns = re.findall(r"^\s+- '([^']+)'\s*$", path_block, re.M)


def workflow_covers(path: str) -> bool:
    for pattern in patterns:
        if pattern.endswith("/**") and path.startswith(pattern[:-2]):
            return True
        if pattern == path:
            return True
    return False


runtime_and_test_paths = [
    "backend-qualification/run.mjs",
    "backend-qualification/build/build.mjs",
    "backend-qualification/build/base-ref.test.mjs",
    "backend-qualification/conformance/qualification.mjs",
    "backend-qualification/adapters/qualification-decorator.mjs",
    "backend-qualification/adapters/qualification-decorator.test.mjs",
    "backend-qualification/oracle/oracle.mjs",
    "backend-qualification/oracle/oracle.test.mjs",
    "backend-qualification/oracle/plan.json",
    "backend-qualification/demo/app.mjs",
    "backend-qualification/demo/build.mjs",
    "backend-qualification/demo/smoke.mjs",
    "backend-qualification/demo/verify-archive.mjs",
    "cmd/backend-qualification/main.go",
    "cmd/compiled-publications-native/main.go",
    "compiled-children/runtime/runtime.mjs",
    "compiled-children/runtime/runtime.test.mjs",
    "compiled-frontend/conformance/browser.mjs",
    "compiled-frontend/conformance/no-wasm.mjs",
    "compiled-frontend/conformance/compare.mjs",
    "compiled-frontend/conformance/fixture-expectations.mjs",
    "compiled-frontend/conformance/observed-action.mjs",
    "compiled-frontend/conformance/direct-js.mjs",
    "compiled-frontend/conformance/provenance.mjs",
    "compiled-frontend/conformance/trace.mjs",
    "compiled-frontend/frontend/shared/view.mjs",
    "compiled-publications/conformance/browser-entry.mjs",
    "compiled-publications/conformance/browser.mjs",
    "compiled-publications/conformance/check.mjs",
    "compiled-publications/conformance/direct.mjs",
    "compiled-publications/conformance/run.mjs",
    "compiled-publications/conformance/seeded.mjs",
    "compiled-publications/runtime/runtime.mjs",
    "compiled-publications/oracle/expectations.json",
    "fixtures/compiled/publications/scenario.json",
    "interaction/package.json",
    "interaction/package-lock.json",
]

import_pattern = re.compile(r'(?:from\s*|import\s*\()\s*["\']([^"\']+)["\']')
todo = deque(path for path in runtime_and_test_paths if path.endswith((".mjs", ".js", ".cjs")))
visited: set[str] = set()
missing_imports: list[dict[str, str]] = []
external_node_modules: set[str] = set()
external_packages: set[str] = set()
while todo:
    source = todo.popleft()
    if source in visited:
        continue
    visited.add(source)
    source_path = Path(source)
    if not source_path.is_file():
        missing_imports.append({"from": source, "specifier": "<source seed missing>"})
        continue
    for specifier in import_pattern.findall(source_path.read_text(errors="replace")):
        if not specifier.startswith("."):
            if not specifier.startswith("node:") and re.fullmatch(r"[A-Za-z0-9@][A-Za-z0-9@/._-]*", specifier):
                external_packages.add(specifier)
            continue
        lexical_target = source_path.parent / specifier
        if "node_modules" in lexical_target.parts:
            external_node_modules.add(specifier)
            continue
        target = lexical_target.resolve()
        candidates = [target, *(Path(str(target) + suffix) for suffix in (".mjs", ".js", ".json"))]
        resolved = next((candidate for candidate in candidates if candidate.is_file()), None)
        if resolved is None:
            missing_imports.append({"from": source, "specifier": specifier})
            continue
        try:
            relative_target = resolved.relative_to(ROOT).as_posix()
        except ValueError:
            missing_imports.append({"from": source, "specifier": specifier, "target": str(resolved)})
            continue
        if relative_target not in paths:
            missing_imports.append({"from": source, "specifier": specifier, "target": relative_target})
        todo.append(relative_target)

review_evidence = sorted(path for path in ordered_paths if "/review-evidence/" in path)
workflow_gaps = [path for path in runtime_and_test_paths if not workflow_covers(path)]
manifest = {
    "schema": "gobi.backend-qualification-source-closure-audit/v1",
    "snapshotNote": "Path list and content pins reflect this read-only audit snapshot. The N1 certificate implementation and test source hashes were not declared final because the authorized N2 repair was still in progress.",
    "runner": file_pin(RUNNER.as_posix()),
    "workflow": file_pin(".github/workflows/gobi-backend-qualification.yml"),
    "sourceDirectories": source_dirs,
    "explicitSourceFiles": source_files,
    "pathCount": len(ordered_paths),
    "paths": [file_pin(path) for path in ordered_paths],
    "n2BuildInput": {
        "path": build_inputs_path.as_posix(),
        "pinCount": len(n2_paths),
        "missingFromOuterSourceBoundary": sorted(set(n2_paths) - paths),
    },
    "reviewEvidence": {
        "count": len(review_evidence),
        "bytes": sum(Path(path).stat().st_size for path in review_evidence),
        "paths": review_evidence,
    },
    "forcedStageCandidates": [
        file_pin("backend-qualification/build/build.mjs"),
        file_pin("backend-qualification/build/base-ref.test.mjs"),
    ],
    "workflowRuntimeTestPathGaps": workflow_gaps,
    "runtimeTestPathChecklist": runtime_and_test_paths,
    "javascriptImportClosure": {
        "seedCount": len(runtime_and_test_paths),
        "internalModuleCount": len(visited),
        "missingOrUnpinnedImports": missing_imports,
        "externalLockedNodeModules": sorted(external_node_modules),
        "externalPackages": sorted(external_packages),
    },
    "sourceBaseIdentityWiring": {
        "runnerUsesSourceCommitArgument": "--source-commit" in RUNNER.read_text(),
        "workflowSourceCommitValue": "inputs.source_commit || github.event.pull_request.head.sha || github.sha" in workflow,
        "checkoutUsesSameExpression": "ref: ${{ inputs.source_commit || github.event.pull_request.head.sha || github.sha }}" in workflow,
        "checkoutHeadIsComparedToSourceCommit": 'test "$(git rev-parse HEAD)" = "$SOURCE_COMMIT"' in workflow,
        "workflowPassesSourceCommitToRunner": 'bash run-backend-qualification.sh --source-commit "$SOURCE_COMMIT"' in workflow,
    },
    "authorArtifactInputs": {
        "qualificationBuildOutputsCreatedUnderUniqueAttempt": True,
        "qualificationEvidenceAndCertificateRequireAttemptPaths": True,
        "browserBundleUsesUniqueTempDirectoryAndIsRemoved": True,
        "archiveConsumerUsesFreshExtractionAndRemovesIt": True,
        "tmpFallbacksAreExecutablesOnly": ["Go", "Node", "Chromium"],
        "readsAuthorAttemptArtifacts": False,
    },
}

output = Path("backend-qualification/coordination/rawlogs/E-SOURCE-CLOSURE/source-closure-manifest.json")
output.write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({
    "manifest": output.as_posix(),
    "pathCount": manifest["pathCount"],
    "n2BuildInputCount": manifest["n2BuildInput"]["pinCount"],
    "n2BuildInputMissing": manifest["n2BuildInput"]["missingFromOuterSourceBoundary"],
    "reviewEvidenceCount": manifest["reviewEvidence"]["count"],
    "reviewEvidenceBytes": manifest["reviewEvidence"]["bytes"],
    "workflowRuntimeTestPathGaps": workflow_gaps,
    "javascriptImportClosureModuleCount": len(visited),
    "javascriptImportClosureMissing": missing_imports,
    "runnerSha256": manifest["runner"]["sha256"],
    "workflowSha256": manifest["workflow"]["sha256"],
}, indent=2))
