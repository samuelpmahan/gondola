# E-BUILD execution notes

- A first successful builder invocation was superseded after N4/N5 clarified that `expectationsPath` must name the existing baseline literal oracle, while N4 loads the qualification `plan.json` separately. The final fresh invocation uses that corrected return path and pins both inputs. The earlier provisional output directory is not used by N4/N6 or this receipt.
- The first independent audit-script invocation failed while opening AppIR because the verifier joined an output-root-relative artifact path to the build output directory a second time. The verifier path was corrected; all 18 final audit checks passed. This was a reviewer-script path error, not a GoScript/native build failure.
- No application, compiler, native CLI, renderer, or shared runner source was modified in this lane.
