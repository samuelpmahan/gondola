import { createServer } from "node:http";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "../../../..");
const temp = await mkdtemp(resolve(tmpdir(), "xr-adapters-probe-"));
const entryPath = resolve(temp, "entry.mjs");
const bundlePath = resolve(temp, "bundle.mjs");
const react = "/tmp/gobi-backend-qualification-E-BUILD-final-20261031/builds/react/output/apps/publications-5ad33d9496e7";
const dom = "/tmp/gobi-backend-qualification-E-BUILD-final-20261031/builds/dom/output/apps/publications-5ad33d9496e7";
const quote = (value) => JSON.stringify(resolve(value));
const entry = [
  `import { gobiCompiled as gobiReact } from ${quote(`${react}/gobi-compiled.mjs`)};`,
  `import * as encoderReact from ${quote(`${react}/encoder.mjs`)};`,
  `import { gobiCompiled as gobiDom } from ${quote(`${dom}/gobi-compiled.mjs`)};`,
  `import * as encoderDom from ${quote(`${dom}/encoder.mjs`)};`,
  `import { installPublicationsBrowser } from ${quote(`${ROOT}/compiled-publications/conformance/browser-entry.mjs`)};`,
  `import { createQualificationDecorator } from ${quote(`${ROOT}/backend-qualification/adapters/qualification-decorator.mjs`)};`,
  `const adapter = createQualificationDecorator({ fault: "drop-click" });`,
  `window.__gobiCompiledPublications = installPublicationsBrowser({ gobiReact, encoderReact, gobiDom, encoderDom, rendererDecorator: adapter.rendererDecorator });`,
  `window.__gobiQualificationAdapter = adapter;`,
].join("\n");
await writeFile(entryPath, entry, "utf8");
const { build } = await import(pathToFileURL(resolve(ROOT, "interaction/node_modules/esbuild/lib/main.js")).href);
await build({ entryPoints: [entryPath], bundle: true, platform: "browser", format: "esm", target: "es2022", nodePaths: [resolve(ROOT, "interaction/node_modules")], outfile: bundlePath, logLevel: "silent" });
const fixture = JSON.parse(await readFile(resolve(ROOT, "fixtures/compiled/publications/scenario.json"), "utf8"));
const expectations = JSON.parse(await readFile(resolve(ROOT, "compiled-publications/oracle/expectations.json"), "utf8"));
const server = createServer(async (request, response) => {
  if (request.url === "/") {
    response.writeHead(200, { "content-type": "text/html; charset=utf-8" });
    response.end('<!doctype html><div id="app"></div><script type="module" src="/bundle.mjs"></script>');
  } else if (request.url === "/bundle.mjs") {
    response.writeHead(200, { "content-type": "text/javascript; charset=utf-8" });
    response.end(await readFile(bundlePath));
  } else response.writeHead(404).end();
});
await new Promise((accept, reject) => { server.once("error", reject); server.listen(0, "127.0.0.1", accept); });
const { chromium } = await import(pathToFileURL(resolve(ROOT, "interaction/node_modules/playwright/index.mjs")).href);
let browser;
let result;
try {
  browser = await chromium.launch({ executablePath: "/tmp/chromium", headless: true, args: ["--no-sandbox"] });
  const page = await browser.newPage();
  const pageErrors = [];
  page.on("pageerror", (error) => pageErrors.push(String(error?.message ?? error)));
  await page.goto(`http://127.0.0.1:${server.address().port}/`, { waitUntil: "load" });
  await page.waitForFunction(() => typeof window.__gobiCompiledPublications?.runProfile === "function");
  const outcome = await page.evaluate(async ({ fixture, expectations }) => {
    const api = window.__gobiCompiledPublications;
    let failedReplay = false;
    try { await api.runProfile({ kind: "react", fixture, expectations }); }
    catch { failedReplay = true; }
    const raw = api.inspectRaw();
    const actualDOM = document.querySelector("#app")?.firstElementChild?.outerHTML ?? "";
    const physicalMatchesActual = raw.physicalDOM?.html === actualDOM;
    const intercepted = window.__gobiQualificationAdapter.activationRecords()[0] ?? null;
    const firstDispose = api.dispose();
    const secondDispose = api.dispose();
    const secondAdapterDispose = window.__gobiQualificationAdapter.dispose();
    return {
      failedReplay,
      mountedAtInspection: raw.mounted,
      physicalMatchesActual,
      physicalHTML: raw.physicalDOM?.html ?? null,
      rendererHTML: raw.rendererDOM?.html ?? null,
      activation: intercepted,
      firstDispose,
      secondDispose,
      secondAdapterDispose,
      disposeIdempotent: JSON.stringify(firstDispose) === JSON.stringify(secondDispose),
      physicalDOMCleared: document.querySelector("#app")?.childNodes.length === 0,
    };
  }, { fixture, expectations });
  result = { browserVersion: await browser.version(), pageErrors, ...outcome };
  process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
} finally {
  await browser?.close();
  await new Promise((accept) => server.close(accept));
  await rm(temp, { recursive: true, force: true });
}
