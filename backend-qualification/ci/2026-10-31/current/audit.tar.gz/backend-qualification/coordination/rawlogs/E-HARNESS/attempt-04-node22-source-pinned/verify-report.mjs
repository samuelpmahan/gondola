import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";

const rawPath = resolve(process.argv[2] ?? "");
if (!process.argv[2]) throw new Error("usage: node verify-report.mjs <qualification.raw.json>");
const raw = JSON.parse(await readFile(rawPath, "utf8"));
const planPath = resolve(dirname(rawPath), "../../../../oracle/plan.json");
const plan = JSON.parse(await readFile(planPath, "utf8"));
const channels = ["dom", "disabled", "dispatch-count", "trace-count", "state"];
const canonical = (value) => {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.keys(value).sort().map((key) => [key, canonical(value[key])]));
  }
  return value;
};
const same = (left, right) => JSON.stringify(canonical(left)) === JSON.stringify(canonical(right));
if (raw.schema !== "gobi.backend-qualification-run/v1" || raw.results?.length !== 13) {
  throw new Error("raw report schema or case count differs");
}
const planCases = new Map(plan.cases.map((item) => [item.id, item]));
const ids = new Set();
for (const row of raw.results) {
  if (ids.has(row.id)) throw new Error(`duplicate case id ${row.id}`);
  ids.add(row.id);
  const planCase = planCases.get(row.id);
  if (!planCase) throw new Error(`unknown case id ${row.id}`);
  const evidencePath = resolve(dirname(rawPath), row.evidencePath);
  const bytes = await readFile(evidencePath);
  const digest = createHash("sha256").update(bytes).digest("hex");
  if (digest !== row.evidenceSHA256) throw new Error(`evidence hash mismatch for ${row.id}`);
  const evidence = JSON.parse(bytes.toString("utf8"));
  const observed = channels.filter((name) => !same(
    evidence.channelComparisons?.[name]?.expected,
    evidence.channelComparisons?.[name]?.observed,
  ));
  if (!same(observed, row.observedChannels)) throw new Error(`derived channels differ for ${row.id}`);
  if (row.infrastructureErrors.length || row.pageErrors.length) throw new Error(`runtime errors recorded for ${row.id}`);
  if (planCase.fault === "none") {
    if (row.activated || row.activationCount !== 0 || row.eventsObserved !== 50 || row.traceTicks !== 46 || observed.length) {
      throw new Error(`healthy case measurements differ for ${row.id}`);
    }
  } else if (!row.activated || row.activationCount !== 1 || observed.some((name) => !planCase.allowedChannels.includes(name))) {
    throw new Error(`fault activation/channel policy differs for ${row.id}`);
  }
}
if (ids.size !== plan.caseCount) throw new Error("not all planned cases were present");
console.log(JSON.stringify({ status: "matched", cases: ids.size, evidenceFiles: ids.size, sourceCommit: raw.sourceCommit }));
