#!/usr/bin/env python3
"""Read-only independent validation of the preserved E-COUNTER-REGRESSION packet."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path.cwd().resolve()
OUT = ROOT / "backend-qualification/coordination/rawlogs/XR-COUNTER-REGRESSION/independent-check.json"

def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def file_info(rel: str) -> dict:
    path = ROOT / rel
    data = path.read_bytes()
    return {"path": rel, "bytes": len(data), "sha256": digest(data)}

def parse_manifest(rel: str) -> list[tuple[str, str]]:
    rows = []
    for line in (ROOT / rel).read_text().splitlines():
        if not line:
            continue
        expected, absolute = line.split("  ", 1)
        path = Path(absolute).resolve()
        path.relative_to(ROOT)
        rows.append((str(path), expected))
    return rows

trace_rel = "interaction/build/interaction-traces-seed-20261030.json"
trace_bytes = (ROOT / trace_rel).read_bytes()
trace = json.loads(trace_bytes)
scenarios = trace["scenarios"]
native = trace["nativeComparison"]["scenarios"]
action_count = sum(len(row["actions"]) for row in scenarios)
tick_count = sum(len(row["ticks"]) for row in scenarios)
max_generated_actions = max((len(row["actions"]) for row in scenarios[7:]), default=0)
assert trace["seed"] == 20261030
assert trace["generatedCases"] == 100
assert len(scenarios) == 107 and len(scenarios) - trace["generatedCases"] == 7
assert action_count == 4366 and tick_count == 4473
assert max_generated_actions <= 80
assert trace["mismatches"] == []
assert trace["nativeComparison"]["status"] == "matched"
assert trace["nativeComparison"]["comparator"] == "ready"
assert len(native) == 107
assert all(row["status"] == "matched" and row["exitCode"] == 0 for row in native)
assert digest(trace_bytes) == "4e22212a1c8b66c1cc768cf2f01b5ea0d45c994221f8b634a183fecab7194fb5"

before_rel = "interaction/coordination/rawlogs/E-COUNTER-REGRESSION/counter-inputs.before.sha256"
after_rel = "interaction/coordination/rawlogs/E-COUNTER-REGRESSION/counter-inputs.after.sha256"
before = parse_manifest(before_rel)
after = parse_manifest(after_rel)
assert len(before) == 23 and len(after) == 23
assert before == after
current_mismatches = []
base_commit = "5662efcd7feb7920e4690d38cc76a297fed69d5a"
git_mismatches = []
for absolute, expected in before:
    actual = digest(Path(absolute).read_bytes())
    if actual != expected:
        current_mismatches.append({"path": str(Path(absolute).relative_to(ROOT)), "expected": expected, "actual": actual})
    relative = str(Path(absolute).relative_to(ROOT))
    committed = subprocess.run(["git", "show", f"{base_commit}:{relative}"], check=True, capture_output=True).stdout
    if committed != Path(absolute).read_bytes():
        git_mismatches.append({"path": relative, "manifestSha256": expected, "baseBlobSha256": digest(committed)})
assert not current_mismatches
assert not git_mismatches
assert (ROOT / "interaction/coordination/rawlogs/E-COUNTER-REGRESSION/counter-inputs.diff.log").read_bytes() == b""
assert (ROOT / "interaction/coordination/rawlogs/E-COUNTER-REGRESSION/counter-inputs.diff.exit-code").read_text().strip() == "0"

source_report_rel = "interaction/coordination/reports/E-COUNTER-REGRESSION.md"
source_receipt_rel = "interaction/coordination/receipts/E-COUNTER-REGRESSION.json"
mirror_report_rel = "backend-qualification/coordination/reports/E-COUNTER-REGRESSION.md"
mirror_receipt_rel = "backend-qualification/coordination/receipts/E-COUNTER-REGRESSION.json"
source_report = (ROOT / source_report_rel).read_bytes()
source_receipt = (ROOT / source_receipt_rel).read_bytes()
mirror_report = (ROOT / mirror_report_rel).read_bytes()
mirror_receipt = (ROOT / mirror_receipt_rel).read_bytes()
ledger = json.loads((ROOT / "backend-qualification/coordination/counter-packet-byte-mirror.json").read_text())
assert source_report == mirror_report and source_receipt == mirror_receipt
assert len(ledger) == 2
assert {row["original"]: row for row in ledger}[source_report_rel]["bytes"] == len(source_report)
assert {row["original"]: row for row in ledger}[source_report_rel]["sha256"] == digest(source_report)
assert {row["original"]: row for row in ledger}[source_receipt_rel]["bytes"] == len(source_receipt)
assert {row["original"]: row for row in ledger}[source_receipt_rel]["sha256"] == digest(source_receipt)
receipt = json.loads(source_receipt)
assert receipt["job_id"] == "E-COUNTER-REGRESSION" and receipt["worker"] == "N4"
assert receipt["outcome"] == "confirmed_reuse"
assert receipt["execution"]["exitCode"] == 0
assert receipt["derivedResults"]["trace"]["sha256"] == digest(trace_bytes)
assert receipt["derivedResults"]["trace"]["browserMismatchCount"] == 0
assert receipt["derivedResults"]["trace"]["nativeMatchedCount"] == 107
assert receipt["derivedResults"]["trace"]["nativeMismatchCount"] == 0
test_output = (ROOT / "interaction/coordination/rawlogs/E-COUNTER-REGRESSION/pipeline.stdout.log").read_text()
assert "# tests 8" in test_output and "# pass 8" in test_output and "# fail 0" in test_output
verified_build_outputs = []
for row in receipt["buildOutputs"]:
    item = file_info(row["path"])
    assert item["bytes"] == row["bytes"] and item["sha256"] == row["sha256"]
    verified_build_outputs.append(item)

recorded_metrics = json.loads((ROOT / "interaction/coordination/rawlogs/E-COUNTER-REGRESSION/counter-metrics.json").read_text())
assert recorded_metrics["trace"]["sha256"] == digest(trace_bytes)
assert recorded_metrics["trace"]["actionCount"] == action_count
assert recorded_metrics["trace"]["initialAndActionTicks"] == tick_count
assert recorded_metrics["trace"]["browserMismatches"] == len(trace["mismatches"])
assert recorded_metrics["trace"]["nativeMismatchCount"] == 0
assert recorded_metrics["trace"]["nativeMatchedCount"] == len(native)

versions = {
    "go": subprocess.run(["/tmp/gondola-go/bin/go", "version"], check=True, text=True, capture_output=True).stdout.strip(),
    "node": subprocess.run(["/tmp/gondola-node22/node_modules/node/bin/node", "--version"], check=True, text=True, capture_output=True).stdout.strip(),
    "chromium": subprocess.run(["/tmp/chromium", "--version"], check=True, text=True, capture_output=True).stdout.strip(),
    "react": json.loads((ROOT / "interaction/node_modules/react/package.json").read_text())["version"],
    "nodeModulesSymlink": str((ROOT / "interaction/node_modules").resolve()),
}
env = os.environ.copy()
env["PATH"] = "/tmp/gondola-node22/node_modules/node/bin:" + env.get("PATH", "")
versions["npm"] = subprocess.run(["npm", "--version"], check=True, env=env, text=True, capture_output=True).stdout.strip()
assert versions["go"] == "go version go1.24.0 linux/amd64"
assert versions["node"] == "v22.23.4"
assert versions["chromium"] == "Chromium 153.0.8010.0"
assert versions["react"] == "19.3.1"
assert versions["npm"] == "11.9.0"

result = {
    "schema": "gobi.counter-regression-independent-check/v1",
    "trace": {
        "path": trace_rel,
        "bytes": len(trace_bytes),
        "sha256": digest(trace_bytes),
        "seed": trace["seed"],
        "generatedCases": trace["generatedCases"],
        "fixedScenarios": len(scenarios) - trace["generatedCases"],
        "scenarioCount": len(scenarios),
        "maxGeneratedActionsObserved": max_generated_actions,
        "actionCount": action_count,
        "initialAndActionTicks": tick_count,
        "browserMismatches": len(trace["mismatches"]),
        "nativeScenarios": len(native),
        "nativeMatched": sum(row["status"] == "matched" for row in native),
        "nativeMismatches": sum(row["status"] != "matched" for row in native),
        "nativeExitCodes": sorted({row["exitCode"] for row in native}),
    },
    "sourceIntegrity": {
        "inputCount": len(before),
        "baseCommit": base_commit,
        "baseCommitObject": subprocess.run(["git", "rev-parse", f"{base_commit}^{{commit}}"], check=True, text=True, capture_output=True).stdout.strip(),
        "beforeManifest": file_info(before_rel),
        "afterManifest": file_info(after_rel),
        "manifestsIdentical": before == after,
        "currentInputMismatches": current_mismatches,
        "baseBlobMismatches": git_mismatches,
        "diffLog": file_info("interaction/coordination/rawlogs/E-COUNTER-REGRESSION/counter-inputs.diff.log"),
        "diffExitCode": 0,
    },
    "mirroredPacket": {
        "report": {"original": file_info(source_report_rel), "mirror": file_info(mirror_report_rel), "byteIdentical": source_report == mirror_report},
        "receipt": {"original": file_info(source_receipt_rel), "mirror": file_info(mirror_receipt_rel), "byteIdentical": source_receipt == mirror_receipt},
        "ledger": file_info("backend-qualification/coordination/counter-packet-byte-mirror.json"),
        "originalReceiptOutcome": receipt["outcome"],
        "pipelineExitCode": receipt["execution"]["exitCode"],
        "nodeTests": {"passed": 8, "failed": 0},
        "buildOutputsVerified": verified_build_outputs,
    },
    "versions": versions,
    "otherPins": {
        "metrics": file_info("interaction/coordination/rawlogs/E-COUNTER-REGRESSION/counter-metrics.json"),
        "pipelineCommand": file_info("interaction/coordination/rawlogs/E-COUNTER-REGRESSION/pipeline.command.txt"),
        "pipelineExitCode": file_info("interaction/coordination/rawlogs/E-COUNTER-REGRESSION/pipeline.exit-code"),
        "pipelineStdout": file_info("interaction/coordination/rawlogs/E-COUNTER-REGRESSION/pipeline.stdout.log"),
        "pipelineStderr": file_info("interaction/coordination/rawlogs/E-COUNTER-REGRESSION/pipeline.stderr.log"),
        "environment": file_info("interaction/coordination/rawlogs/E-COUNTER-REGRESSION/environment.txt"),
    },
}
OUT.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
