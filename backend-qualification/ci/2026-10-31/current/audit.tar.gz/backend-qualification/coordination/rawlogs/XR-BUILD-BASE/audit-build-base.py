import hashlib
import json
import pathlib
import re

root = pathlib.Path.cwd()
def read(path):
    return (root / path).read_bytes()
def sha(data):
    return hashlib.sha256(data).hexdigest()
def pin(path):
    body = read(path)
    return {"path": path, "bytes": len(body), "sha256": sha(body)}

receipt_path = "backend-qualification/coordination/receipts/E-BUILD-BASE.json"
report_path = "backend-qualification/coordination/reports/E-BUILD-BASE.md"
receipt = json.loads(read(receipt_path))
report = read(report_path)
contract_bytes = read("backend-qualification/CONTRACT.md")
contract_text = contract_bytes.decode("utf-8")
contract_ref = re.search(r"^Base([0-9a-f]{40})\(PR17\)", contract_text, re.MULTILINE).group(1)
builder_path = "backend-qualification/build/build.mjs"
builder_bytes = read(builder_path)
test_path = "backend-qualification/build/base-ref.test.mjs"
test_bytes = read(test_path)
source_ref = re.search(r'contractBaseCommitRef\s*=\s*"([^"]+)"', builder_bytes.decode("utf-8")).group(1)
base_meta = json.loads(read("backend-qualification/coordination/rawlogs/E-BUILD-BASE/run-metadata.json"))

source_pins_by_run = {}
run_checks = {}
app_irs = {}
native_traces = {}
output_inventories = {}
for letter in ("a", "b"):
    provenance_path = f"backend-qualification/coordination/rawlogs/E-BUILD-BASE/build-{letter}/build-inputs.json"
    provenance_bytes = read(provenance_path)
    provenance = json.loads(provenance_bytes)
    source_pins = provenance["sourcePins"]
    source_pins_by_run[letter] = source_pins
    source_mismatches = []
    for path, expected in source_pins.items():
        candidate = root / path
        if not candidate.is_file():
            source_mismatches.append({"path": path, "error": "missing"})
            continue
        body = candidate.read_bytes()
        if len(body) != expected["bytes"] or sha(body) != expected["sha256"]:
            source_mismatches.append({"path": path, "error": "size-or-sha256"})
    output_checks = {}
    output_root = pathlib.Path(f"/tmp/gobi-backend-qualification-E-BUILD-BASE-20261031-{letter}/builds")
    output_inventories[letter] = {}
    for backend in ("react", "dom"):
        build = provenance[backend]
        physical_output = output_root / backend / "output"
        actual_files = [path for path in physical_output.rglob("*") if path.is_file()]
        mismatches = []
        for item in build["outputs"]:
            candidate = physical_output / item["path"]
            if not candidate.is_file():
                mismatches.append({"path": item["path"], "error": "missing"})
                continue
            body = candidate.read_bytes()
            if len(body) != item["bytes"] or sha(body) != item["sha256"]:
                mismatches.append({"path": item["path"], "error": "size-or-sha256"})
        app_ir_path = physical_output / "apps/publications-5ad33d9496e7/app-ir.json"
        app_ir_bytes = app_ir_path.read_bytes()
        app_ir = json.loads(app_ir_bytes)
        component = next(row for row in app_ir["components"] if row["id"] == build["componentId"])
        app_irs[(letter, backend)] = app_ir_bytes
        output_checks[backend] = {
            "inventory_entries": len(build["outputs"]),
            "output_count": build["outputCount"],
            "physical_files": len(actual_files),
            "inventory_hash_mismatches": mismatches,
            "app_ir_sha256": sha(app_ir_bytes),
            "capabilities": component["capabilities"],
        }
        output_inventories[letter][backend] = sorted(
            (item["path"], item["bytes"], item["sha256"]) for item in build["outputs"]
        )
    native_path = pathlib.Path(f"/tmp/gobi-backend-qualification-E-BUILD-BASE-20261031-{letter}/native/native-trace.json")
    native_bytes = native_path.read_bytes()
    native = json.loads(native_bytes)
    native_traces[letter] = native_bytes
    run_checks[letter] = {
        "provenance_sha256": sha(provenance_bytes),
        "contract_base_ref": provenance["contractBaseCommitRef"],
        "source_pin_count": len(source_pins),
        "source_pins_match_after_build": provenance["sourcePinsMatchAfterBuild"],
        "source_pin_mismatches": source_mismatches,
        "contract_pin": source_pins.get("backend-qualification/CONTRACT.md"),
        "contract_pin_matches_current": source_pins.get("backend-qualification/CONTRACT.md") == {"bytes": len(contract_bytes), "sha256": sha(contract_bytes)},
        "builds": output_checks,
        "native_trace_sha256": sha(native_bytes),
        "native_events": len(native.get("events", [])),
        "native_steps": len(native.get("steps", [])),
    }

same_pin_sets = source_pins_by_run["a"] == source_pins_by_run["b"]
current_source_mismatches = run_checks["a"]["source_pin_mismatches"] + run_checks["b"]["source_pin_mismatches"]
native_rawlog_bytes = read("backend-qualification/coordination/rawlogs/E-BUILD/native/native-trace.json")
test_log = read("backend-qualification/coordination/rawlogs/E-BUILD-BASE/base-ref-tests.log").decode("utf-8")
source_receipt_mismatches = []
for path, expected_sha in receipt["sourceSha256"].items():
    body = read(path)
    if sha(body) != expected_sha:
        source_receipt_mismatches.append(path)
rawlog_receipt_mismatches = []
for path, expected_sha in receipt["rawLogSha256"].items():
    body = read(path)
    if sha(body) != expected_sha:
        rawlog_receipt_mismatches.append(path)
old_e_build = json.loads(read("backend-qualification/coordination/rawlogs/E-BUILD/build-inputs.json"))
module_comparison = {}
for backend in ("react", "dom"):
    inventory_a = {row["path"]: (row["bytes"], row["sha256"]) for row in json.loads(read(f"backend-qualification/coordination/rawlogs/E-BUILD-BASE/build-a/build-inputs.json"))[backend]["outputs"]}
    inventory_b = {row["path"]: (row["bytes"], row["sha256"]) for row in json.loads(read(f"backend-qualification/coordination/rawlogs/E-BUILD-BASE/build-b/build-inputs.json"))[backend]["outputs"]}
    changed_paths = [path for path in sorted(set(inventory_a) | set(inventory_b)) if inventory_a.get(path) != inventory_b.get(path)]
    module_a = pathlib.Path(f"/tmp/gobi-backend-qualification-E-BUILD-BASE-20261031-a/builds/{backend}/output/apps/publications-5ad33d9496e7/gobi-compiled.mjs").read_text().splitlines()
    module_b = pathlib.Path(f"/tmp/gobi-backend-qualification-E-BUILD-BASE-20261031-b/builds/{backend}/output/apps/publications-5ad33d9496e7/gobi-compiled.mjs").read_text().splitlines()
    line_diffs = [(left, right) for left, right in zip(module_a, module_b) if left != right]
    noncomment_diffs = [(left, right) for left, right in line_diffs if not (left.startswith("//") and right.startswith("//"))]
    module_comparison[backend] = {
        "inventory_diff_paths": changed_paths,
        "compiled_module_hash_a": inventory_a.get("apps/publications-5ad33d9496e7/gobi-compiled.mjs", [None, None])[1],
        "compiled_module_hash_b": inventory_b.get("apps/publications-5ad33d9496e7/gobi-compiled.mjs", [None, None])[1],
        "compiled_module_differing_lines": len(line_diffs),
        "differing_lines_are_comments_only": not noncomment_diffs and all(left.startswith("//") and right.startswith("//") for left, right in line_diffs),
        "noncomment_line_differences": len(noncomment_diffs),
    }
result = {
    "decision": "accepted" if contract_ref == source_ref and not current_source_mismatches and same_pin_sets else "amend",
    "sealed_repair_packet": {
        "report_sha256": sha(report),
        "receipt_sha256": sha(read(receipt_path)),
        "report_matches_seal": report == read("backend-qualification/coordination/seals/E-BUILD-BASE/reports/E-BUILD-BASE.md"),
        "receipt_matches_seal": read(receipt_path) == read("backend-qualification/coordination/seals/E-BUILD-BASE/receipts/E-BUILD-BASE.json"),
        "report_matches_receipt_pin": len(report) == receipt["report"]["bytes"] and sha(report) == receipt["report"]["sha256"],
    },
    "historical_e_build": {
        "old_source_sha256": sha(read("backend-qualification/coordination/seals/E-BUILD/source/build.mjs")),
        "old_report_unchanged": read("backend-qualification/coordination/reports/E-BUILD.md") == read("backend-qualification/coordination/seals/E-BUILD/reports/E-BUILD.md"),
        "old_receipt_unchanged": read("backend-qualification/coordination/receipts/E-BUILD.json") == read("backend-qualification/coordination/seals/E-BUILD/receipts/E-BUILD.json"),
    },
    "base_reference": {
        "contract_ref": contract_ref,
        "contract_ref_length": len(contract_ref),
        "builder_ref": source_ref,
        "builder_ref_length": len(source_ref),
        "receipt_ref": receipt["repair"]["contractBaseReference"],
        "all_full_exact_match": contract_ref == source_ref == receipt["repair"]["contractBaseReference"],
        "malformed_contract_rejections": 1,
        "truncated_ref_rejection_recorded": "rejects a truncated 39-character base reference" in test_log,
        "mismatched_full_ref_rejection_recorded": "rejects a different but valid-length commit reference" in test_log,
    },
    "runs": run_checks,
    "source_input_coverage": {
        "pin_count_per_run": [len(source_pins_by_run["a"]), len(source_pins_by_run["b"])],
        "pin_sets_identical": same_pin_sets,
        "current_input_pin_mismatches": current_source_mismatches,
        "source_pin_set_includes_contract": "backend-qualification/CONTRACT.md" in source_pins_by_run["a"],
        "source_receipt_mismatches": source_receipt_mismatches,
        "rawlog_receipt_mismatches": rawlog_receipt_mismatches,
        "outer_release_source_inventory_claimed": False,
    },
    "output_repeatability": {
        "per_run_inventory_hashes_match_physical_tree": all(not run_checks[letter]["builds"][backend]["inventory_hash_mismatches"] for letter in ("a", "b") for backend in ("react", "dom")),
        "react": module_comparison["react"],
        "dom": module_comparison["dom"],
        "react_appir_matches_original_e_build": run_checks["a"]["builds"]["react"]["app_ir_sha256"] == old_e_build["react"]["appIRSha256"],
        "dom_appir_matches_original_e_build": run_checks["a"]["builds"]["dom"]["app_ir_sha256"] == old_e_build["dom"]["appIRSha256"],
    },
    "native_trace": {
        "build_a_b_byte_identical": native_traces["a"] == native_traces["b"],
        "build_a_b_sha256": sha(native_traces["a"]),
        "original_e_build_trace_sha256": sha(native_rawlog_bytes),
        "matches_original_trace": native_traces["a"] == native_rawlog_bytes,
        "events": run_checks["a"]["native_events"],
        "steps": run_checks["a"]["native_steps"],
    },
    "base_ref_test_log": {
        "passed_four": "# tests 4\n# suites 0\n# pass 4\n# fail 0" in test_log,
        "sha256": sha(read("backend-qualification/coordination/rawlogs/E-BUILD-BASE/base-ref-tests.log")),
    },
    "source_hashes": {
        "builder": {"bytes": len(builder_bytes), "sha256": sha(builder_bytes), "matches_receipt": sha(builder_bytes) == receipt["sourceSha256"][builder_path]},
        "test": {"bytes": len(test_bytes), "sha256": sha(test_bytes), "matches_receipt": sha(test_bytes) == receipt["sourceSha256"][test_path]},
    },
    "run_metadata_sha256": sha(read("backend-qualification/coordination/rawlogs/E-BUILD-BASE/run-metadata.json")),
}
print(json.dumps(result, indent=2, sort_keys=True))
