#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
COORD = ROOT / "backend-qualification/coordination"
RECEIPT_PATH = COORD / "receipts/E-GO-CHANNELS.json"
receipt = json.loads(RECEIPT_PATH.read_text())
failures = []

for artifact in receipt.get("source", {}).get("files", []):
    path = Path(artifact["path"])
    if not path.is_absolute():
        path = ROOT / path
    if not path.is_file():
        failures.append(f"missing source: {artifact['path']}")
        continue
    data = path.read_bytes()
    if len(data) != artifact["bytes"] or hashlib.sha256(data).hexdigest() != artifact["sha256"]:
        failures.append(f"source pin mismatch: {artifact['path']}")

for key in ["actual_capture", "actual_certificate"]:
    artifact = receipt.get("source", {}).get(key)
    if not artifact:
        failures.append(f"missing source pin: {key}")
        continue
    path = Path(artifact["path"])
    if not path.is_absolute():
        path = ROOT / path
    if not path.is_file():
        failures.append(f"missing source artifact: {artifact['path']}")
        continue
    data = path.read_bytes()
    if len(data) != artifact["bytes"] or hashlib.sha256(data).hexdigest() != artifact["sha256"]:
        failures.append(f"source artifact pin mismatch: {artifact['path']}")

for evidence in receipt.get("evidence", []):
    path = ROOT / evidence["path"]
    if not path.is_file():
        failures.append(f"missing evidence: {evidence['path']}")
        continue
    data = path.read_bytes()
    if len(data) != evidence["bytes"] or hashlib.sha256(data).hexdigest() != evidence["sha256"]:
        failures.append(f"evidence pin mismatch: {evidence['path']}")

report = receipt.get("report", {})
report_path = ROOT / report.get("path", "")
if not report_path.is_file():
    failures.append("missing review report")
else:
    data = report_path.read_bytes()
    if len(data) != report.get("bytes") or hashlib.sha256(data).hexdigest() != report.get("sha256"):
        failures.append("review report pin mismatch")

for live, sealed in [
    (COORD / "reports/E-GO.md", COORD / "seals/E-GO/reports/E-GO.md"),
    (COORD / "receipts/E-GO.json", COORD / "seals/E-GO/receipts/E-GO.json"),
]:
    if not live.is_file() or not sealed.is_file() or live.read_bytes() != sealed.read_bytes():
        failures.append(f"original E-GO sealed packet mismatch: {live.name}")

if failures:
    print(json.dumps({"status": "failed", "failures": failures}, indent=2))
    raise SystemExit(1)
print("PASS")
