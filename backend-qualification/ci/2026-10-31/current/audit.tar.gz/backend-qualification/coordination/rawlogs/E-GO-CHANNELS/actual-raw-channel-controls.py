#!/usr/bin/env python3
import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
INPUT = Path("/tmp/gobi-backend-qualification-E-HARNESS-node22/qualification.raw.json")
cases_root = INPUT.parent / "cases"
go = "/tmp/gondola-go/bin/go"
results = []

with tempfile.TemporaryDirectory(prefix="gobi-actual-raw-channels-") as temp:
    temp_root = Path(temp)
    shutil.copytree(cases_root, temp_root / "cases")
    original = json.loads(INPUT.read_text())
    for label, values, expected_error in [
        ("unknown", ["dom", "gpu-pixels"], 'unknown channel "gpu-pixels"'),
        ("duplicate", ["dom", "dom"], 'duplicate channel "dom"'),
    ]:
        run = json.loads(json.dumps(original))
        row = next(item for item in run["results"] if item["id"] == "fault-react-text-corruption")
        row["observedChannels"] = values
        input_path = temp_root / f"run-{label}.json"
        output_path = temp_root / f"certificate-{label}.json"
        input_path.write_text(json.dumps(run))
        command = [go, "run", "./cmd/backend-qualification", "--input", str(input_path), "--output", str(output_path)]
        env = dict(os.environ, GOTOOLCHAIN="local", GOFLAGS="-buildvcs=false")
        process = subprocess.run(command, cwd=ROOT, env=env, text=True, capture_output=True)
        error_match = expected_error in process.stderr
        certificate_exists = output_path.exists()
        result = {
            "name": label,
            "command": " ".join(command),
            "inputChannels": values,
            "exitCode": process.returncode,
            "stderr": process.stderr.strip(),
            "expectedErrorFound": error_match,
            "certificateExists": certificate_exists,
        }
        results.append(result)
        if process.returncode == 0 or not error_match or certificate_exists:
            raise SystemExit(json.dumps({"failedControl": result}, indent=2))

print(json.dumps({"schema": "gobi.backend-qualification-raw-channel-repair-controls/v1", "results": results}, indent=2))
