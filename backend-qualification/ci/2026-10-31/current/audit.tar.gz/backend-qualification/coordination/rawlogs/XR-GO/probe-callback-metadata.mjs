import { createHash } from "node:crypto";
import { spawnSync } from "node:child_process";
import { cp, mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../../..");
const rawSource = "/tmp/gobi-backend-qualification-E-HARNESS-node22/qualification.raw.json";
const tempRoot = await mkdtemp(path.join(os.tmpdir(), "gobi-xr-go-callbacks-"));
const env = { ...process.env, GOTOOLCHAIN: "local", GOFLAGS: "-buildvcs=false" };

try {
  const directory = path.join(tempRoot, "callback-metadata");
  await mkdir(directory, { recursive: true });
  await cp(path.join(path.dirname(rawSource), "cases"), path.join(directory, "cases"), { recursive: true });
  const run = JSON.parse(await readFile(rawSource, "utf8"));
  const row = run.results.find((item) => item.id === "fault-react-drop-click");
  const evidencePath = path.join(directory, row.evidencePath);
  const evidence = JSON.parse(await readFile(evidencePath, "utf8"));
  evidence.activation.callbackInvocations = false;
  evidence.activation.records[0].callbackInvocationsBefore = "not-a-counter-object";
  evidence.activation.records[0].callbackInvocationsAfter = [];
  evidence.observed.callbackInvocations = null;
  const evidenceBytes = Buffer.from(`${JSON.stringify(evidence, null, 2)}\n`);
  await writeFile(evidencePath, evidenceBytes);
  row.evidenceSHA256 = createHash("sha256").update(evidenceBytes).digest("hex");
  const inputPath = path.join(directory, "qualification.raw.json");
  const outputPath = path.join(directory, "certificate.json");
  await writeFile(inputPath, `${JSON.stringify(run, null, 2)}\n`);
  const result = spawnSync(process.env.GOBI_GO_BIN || "/tmp/gondola-go/bin/go", [
    "run", "./cmd/backend-qualification", "--input", inputPath, "--output", outputPath,
  ], { cwd: root, env, encoding: "utf8", maxBuffer: 16 * 1024 * 1024 });
  console.log(JSON.stringify({
    schema: "gobi.backend-qualification-go-callback-review/v1",
    case: row.id,
    callbackInvocationsTypes: {
      activation: typeof evidence.activation.callbackInvocations,
      before: typeof evidence.activation.records[0].callbackInvocationsBefore,
      after: Array.isArray(evidence.activation.records[0].callbackInvocationsAfter) ? "array" : typeof evidence.activation.records[0].callbackInvocationsAfter,
      observed: evidence.observed.callbackInvocations,
    },
    exitCode: result.status,
    stderr: result.stderr ?? "",
    certificateExists: result.status === 0,
  }, null, 2));
} finally {
  await rm(tempRoot, { recursive: true, force: true });
}
