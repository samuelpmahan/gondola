import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";

import { buildQualificationInputs } from "../../../build/build.mjs";

const directories = [
  "/tmp/gobi-backend-qualification-E-BUILD-BASE-20261031-a",
  "/tmp/gobi-backend-qualification-E-BUILD-BASE-20261031-b",
];
const digest = (bytes) => createHash("sha256").update(bytes).digest("hex");
const runs = [];

for (const outputDir of directories) {
  const inputs = await buildQualificationInputs({ outputDir });
  const provenance = JSON.parse(await readFile(inputs.provenancePath, "utf8"));
  const native = await readFile(inputs.nativePath);
  assert.equal(provenance.contractBaseCommitRef, "5662efcd7feb7920e4690d38cc76a297fed69d5a");
  assert.equal(provenance.contractBaseCommitRef.length, 40);
  assert.equal(provenance.react.outputCount, 67);
  assert.equal(provenance.dom.outputCount, 67);
  assert.equal(provenance.react.appIRSha256, provenance.dom.appIRSha256);
  assert.equal(provenance.sourcePinsMatchAfterBuild, true);
  runs.push({
    outputDir,
    provenancePath: inputs.provenancePath,
    nativePath: inputs.nativePath,
    nativeSha256: digest(native),
    baseRef: provenance.contractBaseCommitRef,
    sourcePinCount: Object.keys(provenance.sourcePins).length,
    reactOutputCount: provenance.react.outputCount,
    domOutputCount: provenance.dom.outputCount,
    reactAppIRSha256: provenance.react.appIRSha256,
    domAppIRSha256: provenance.dom.appIRSha256,
    reactManifestSha256: provenance.react.manifest.sha256,
    domManifestSha256: provenance.dom.manifest.sha256,
  });
}

assert.equal(runs[0].nativeSha256, runs[1].nativeSha256);
assert.equal(runs[0].reactAppIRSha256, runs[1].reactAppIRSha256);
assert.equal(runs[0].domAppIRSha256, runs[1].domAppIRSha256);
assert.equal(runs[0].sourcePinCount, runs[1].sourcePinCount);
console.log(JSON.stringify({ schema: "gobi.backend-qualification-build-base-recheck/v1", runs }, null, 2));
