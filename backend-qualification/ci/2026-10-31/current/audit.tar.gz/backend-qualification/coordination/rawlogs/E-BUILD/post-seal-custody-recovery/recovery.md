# E-BUILD post-seal custody recovery

The original sealed E-BUILD report and receipt were not modified. After sealing, one source line was removed from `backend-qualification/build/build.mjs`, omitting `compiled-publications/oracle/expectations.json` from `sourcePins`. The post-seal builder run completed; its command logs, provenance, native trace, and post-seal builder bytes are preserved under this directory.

The exact original source was recovered by reinserting that single line into the preserved post-seal bytes. The reconstructed candidate SHA-256 matched the announced sealed builder hash `315a0d4f227ec99501b7eb4b4305ab16ed1c7a4a4659ace9975b36b584e66ad0` before the live file was restored. The candidate and both before/after byte counts and hashes are in `recovery.json`. No further build was started after restoration.
