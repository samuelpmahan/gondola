import hashlib
import json
from pathlib import Path

manifest_path = Path("backend-qualification/coordination/rawlogs/E-SOURCE-CLOSURE/source-closure-manifest.json")
manifest = json.loads(manifest_path.read_text())
changed = []
missing = []
for pin in manifest["paths"]:
    path = Path(pin["path"])
    if not path.is_file():
        missing.append(pin["path"])
        continue
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if len(data) != pin["bytes"] or digest != pin["sha256"]:
        changed.append(pin["path"])
print(json.dumps({
    "manifestPathCount": manifest["pathCount"],
    "rehashed": len(manifest["paths"]),
    "changedSinceManifest": changed,
    "missingSinceManifest": missing,
}, indent=2))
