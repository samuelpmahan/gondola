import json
import os
import pathlib
import subprocess
import tempfile

root = pathlib.Path.cwd()
go = "/tmp/gondola-go/bin/go"
env = os.environ.copy()
env.update({"GOTOOLCHAIN": "local", "GOFLAGS": "-buildvcs=false"})
rows = {}

with tempfile.TemporaryDirectory(prefix="xr-gocli-safeguards-") as temp:
    directory = pathlib.Path(temp)
    input_path = directory / "input.json"
    original = b"{not-json\n"
    input_path.write_bytes(original)
    alias_path = directory / "input-alias.json"
    alias_path.symlink_to(input_path)
    same_path = subprocess.run(
        [go, "run", "./cmd/backend-qualification", "--input", str(input_path), "--output", str(alias_path)],
        cwd=root, env=env, text=True, capture_output=True, check=False,
    )
    same_path_rejected_before_parse = "input and output paths must be different" in same_path.stderr
    same_path_preserved_input = input_path.read_bytes() == original
    alias_still_present = alias_path.is_symlink()
    rows["symlink_alias"] = {
        "exit_code": same_path.returncode,
        "stderr": same_path.stderr,
        "rejected_before_parse": same_path_rejected_before_parse,
        "input_preserved": same_path_preserved_input,
        "output_alias_preserved": alias_still_present,
    }

    malformed_output = directory / "malformed-certificate.json"
    malformed = subprocess.run(
        [go, "run", "./cmd/backend-qualification", "--input", str(input_path), "--output", str(malformed_output)],
        cwd=root, env=env, text=True, capture_output=True, check=False,
    )
    rows["malformed_input"] = {
        "exit_code": malformed.returncode,
        "stderr": malformed.stderr,
        "output_certificate_created": malformed_output.exists(),
        "input_preserved": input_path.read_bytes() == original,
    }

if not (
    rows["symlink_alias"]["exit_code"] != 0
    and rows["symlink_alias"]["rejected_before_parse"]
    and rows["symlink_alias"]["input_preserved"]
    and rows["symlink_alias"]["output_alias_preserved"]
    and rows["malformed_input"]["exit_code"] != 0
    and not rows["malformed_input"]["output_certificate_created"]
    and rows["malformed_input"]["input_preserved"]
):
    raise SystemExit(json.dumps(rows, indent=2))
print(json.dumps(rows, indent=2, sort_keys=True))
