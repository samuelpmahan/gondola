#!/usr/bin/env python3
"""Read-only provenance cross-check for the fresh E-BUILD outputs."""
from pathlib import Path
import hashlib, json, os, sys

ROOT = Path.cwd()
OUTPUT = Path(os.environ.get('GOBI_E_BUILD_OUTPUT', '/tmp/gobi-backend-qualification-E-BUILD-final-20261031'))
RAW = ROOT/'backend-qualification/coordination/rawlogs/E-BUILD'

def digest(path):
    h=hashlib.sha256(); size=0
    with Path(path).open('rb') as stream:
        while True:
            block=stream.read(1024*1024)
            if not block: break
            h.update(block); size+=len(block)
    return {'bytes':size,'sha256':h.hexdigest()}

def check_record(path, record):
    actual=digest(path)
    return actual['bytes']==record['bytes'] and actual['sha256']==record['sha256'], actual

p=OUTPUT/'provenance/build-inputs.json'
provenance=json.loads(p.read_text())
checks={}
source_mismatches=[]
for rel,pin in provenance['sourcePins'].items():
    ok,actual=check_record(ROOT/rel,pin)
    if not ok: source_mismatches.append({'path':rel,'expected':pin,'actual':actual})
checks['all_86_current_source_pins_match']=len(provenance['sourcePins'])==86 and not source_mismatches
checks['source_pins_match_after_build_flag']=provenance['sourcePinsMatchAfterBuild'] is True
checks['source_pin_mismatches_empty']=not source_mismatches

for name in ('react','dom'):
    build=provenance[name]
    output_dir=OUTPUT/build['buildRoot']/'output'
    manifest=OUTPUT/build['manifest']['path']
    manifest_ok,manifest_actual=check_record(manifest,build['manifest'])
    checks[f'{name}_manifest_matches_record']=manifest_ok
    outputs_ok=True
    for item in build['outputs']:
        ok,_=check_record(output_dir/item['path'],item)
        outputs_ok=outputs_ok and ok
    checks[f'{name}_all_{build["outputCount"]}_outputs_match']=outputs_ok and build['outputCount']==67
    app_ir=json.loads((OUTPUT/build['artifacts']['appIR']['path']).read_text())
    component=next((c for c in app_ir['components'] if c['id']==build['componentId']),None)
    checks[f'{name}_five_required_capabilities']=component is not None and all(
      cap in component['capabilities'] for cap in ['view.node','numeric.safe-integer','numeric.float64','effect.request-reply','effect.cancel']) and len(component['capabilities'])==5

checks['react_dom_appir_identical']=provenance['react']['artifacts']['appIR']['sha256']==provenance['dom']['artifacts']['appIR']['sha256']
checks['react_dom_encoder_identical']=provenance['react']['artifacts']['encoder']['sha256']==provenance['dom']['artifacts']['encoder']['sha256']
checks['locked_inputs_pinned']=all(path in provenance['sourcePins'] and provenance['sourcePins'][path]==pin for path,pin in provenance['locks'].items())
plan_json=json.loads((ROOT/provenance['plan']['path']).read_text())
checks['scenario_pin_matches_plan']=provenance['fixture']['sha256']==plan_json['scenario']['sha256'] and provenance['plan']['schema']=='gobi.backend-qualification-oracle-plan/v1'
checks['baseline_oracle_matches_plan']=provenance['expectations']['sha256']==plan_json['baselineOracle']['sha256']
trace=OUTPUT/provenance['nativeTrace']['path']
trace_ok,trace_actual=check_record(trace,provenance['nativeTrace'])
trace_json=json.loads(trace.read_text())
checks['fresh_native_trace_50_events_45_updates']=trace_ok and len(trace_json['events'])==50 and len(trace_json['steps'])==45
checks['rawlog_native_trace_matches_output']=digest(RAW/'native/native-trace.json')==trace_actual
checks['rawlog_provenance_matches_output']=digest(RAW/'build-inputs.json')==digest(p)
command_checks={}
for command_file in sorted((OUTPUT/'provenance/commands').glob('*.command.json')):
    record=json.loads(command_file.read_text()); label=record['label']; base=command_file.with_suffix('')
    stdout=command_file.parent/f'{label}.stdout.log'; stderr=command_file.parent/f'{label}.stderr.log'
    so=digest(stdout); se=digest(stderr)
    command_checks[label]=(record['exitCode']==0 and so['bytes']==record['stdoutBytes'] and so['sha256']==record['stdoutSha256'] and se['bytes']==record['stderrBytes'] and se['sha256']==record['stderrSha256'])
checks['all_six_commands_exit_clean_and_logs_match']=len(command_checks)==6 and all(command_checks.values())

result={
  'schema':'gobi.backend-qualification-build-audit/v1',
  'outputDir':str(OUTPUT),
  'provenance':digest(p),
  'builderSource':provenance['sourcePins']['backend-qualification/build/build.mjs'],
  'versions':provenance['versions'],
  'fixture':provenance['fixture'],
  'plan':provenance['plan'],
  'expectations':provenance['expectations'],
  'nativeTrace':{**provenance['nativeTrace'],'actual':trace_actual},
  'builds':{backend:{'manifest':provenance[backend]['manifest'],'outputCount':provenance[backend]['outputCount'],'capabilities':provenance[backend]['capabilities'],'artifacts':provenance[backend]['artifacts']} for backend in ('react','dom')},
  'sourcePinCount':len(provenance['sourcePins']),
  'sourcePinMismatches':source_mismatches,
  'commandChecks':command_checks,
  'checks':checks,
  'allPassed':all(checks.values()),
  'method':'Rehashed current source pins, build manifests, every recorded generated output, native trace and copied evidence using 1 MiB streaming. No compiler/runtime tests were added or replayed here.'
}
(RAW/'audit.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'allPassed':result['allPassed'],'checks':checks},indent=2))
if not result['allPassed']: sys.exit(1)
