import hashlib
import importlib.util
import json
import pathlib

root = pathlib.Path.cwd()
receipt_path = pathlib.Path("backend-qualification/coordination/receipts/E-ADAPTERS.json")
receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
state = json.loads(pathlib.Path("backend-qualification/coordination/state.json").read_text(encoding="utf-8"))
validator_spec = importlib.util.spec_from_file_location(
    "backend_qualification_probe", "backend-qualification/coordination/probe.py"
)
validator = importlib.util.module_from_spec(validator_spec)
validator_spec.loader.exec_module(validator)
validator.validate_receipt(receipt, state["jobs"]["E-ADAPTERS"], "N3")

pins = [
    receipt["source"]["contract"], receipt["source"]["plan"],
    receipt["source"]["decorator"], receipt["source"]["focused_tests"],
    receipt["source"]["browser_entry"], receipt["report"], *receipt["evidence"],
]
for pin in pins:
    data = (root / pin["path"]).read_bytes()
    if len(data) != pin["bytes"] or hashlib.sha256(data).hexdigest() != pin["sha256"]:
        raise SystemExit(f"pin mismatch: {pin['path']}")
print("PASS: receipt validated and every recorded source, report, and rawlog pin matched.")
