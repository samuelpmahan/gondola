import { installPublicationsBrowser } from "../../../../compiled-publications/conformance/browser-entry.mjs";

if (typeof installPublicationsBrowser !== "function") {
  throw new TypeError("browser entry did not export installPublicationsBrowser");
}

console.log("browser-entry import/export: PASS");
