import hashlib, json
from pathlib import Path
root = Path.cwd()
receipt_path = Path('backend-qualification/coordination/receipts/XR-GO-CHANNELS.json')
receipt = json.loads(receipt_path.read_text())
assert receipt['job_id'] == 'XR-GO-CHANNELS' and receipt['worker'] == 'N3'
assert receipt['decision'] in {'accepted', 'amend', 'rejected'}
assert receipt['summary'].strip()
items = [receipt['report'], *receipt['source'].values(), *receipt['evidence']]
for item in items:
    if not isinstance(item, dict) or 'path' not in item:
        continue
    path = Path(item['path'])
    data = path.read_bytes() if path.is_absolute() else (root / path).read_bytes()
    assert len(data) == item['bytes'], f"size mismatch: {item['path']}"
    assert hashlib.sha256(data).hexdigest() == item['sha256'], f"SHA mismatch: {item['path']}"
print("PASS: XR-GO-CHANNELS receipt pins verified.")
