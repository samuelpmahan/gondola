import { createHash } from 'node:crypto';
import { readFileSync, statSync } from 'node:fs';
import { basename, dirname, resolve } from 'node:path';

const path = resolve('interaction/build/interaction-traces-seed-20261030.json');
const bytes = readFileSync(path);
const report = JSON.parse(bytes);
const scenarios = report.scenarios ?? [];
const native = report.nativeComparison?.scenarios ?? [];
const metrics = {
  schema: 'gobi.original-counter-regression-metrics/v1',
  trace: {
    path: 'interaction/build/interaction-traces-seed-20261030.json',
    bytes: statSync(path).size,
    sha256: createHash('sha256').update(bytes).digest('hex'),
    seed: report.seed,
    generatedCases: report.generatedCases,
    maxActionsPerGeneratedCase: report.maxActionsPerGeneratedCase,
    scenarioCount: scenarios.length,
    fixedScenarioCount: scenarios.length - report.generatedCases,
    actionCount: scenarios.reduce((sum, row) => sum + row.actions.length, 0),
    initialAndActionTicks: scenarios.reduce((sum, row) => sum + row.ticks.length, 0),
    browserMismatches: report.mismatches.length,
    nativeComparatorStatus: report.nativeComparison?.status,
    nativeComparatorState: report.nativeComparison?.comparator,
    nativeScenarioCount: native.length,
    nativeMatchedCount: native.filter(row => row.status === 'matched').length,
    nativeMismatchCount: native.filter(row => row.status !== 'matched').length,
    nativeExitCodes: [...new Set(native.map(row => row.exitCode))].sort(),
    reactVersion: report.react,
    browser: report.browser,
  },
  buildOutputs: ['counter.wasm', 'compare-interaction', 'wasm_exec.js', 'react-reference.bundle.mjs'].map(name => {
    const output = resolve('interaction/build', name);
    const data = readFileSync(output);
    return { path: `interaction/build/${basename(output)}`, bytes: statSync(output).size, sha256: createHash('sha256').update(data).digest('hex') };
  }),
};
process.stdout.write(`${JSON.stringify(metrics, null, 2)}\n`);
