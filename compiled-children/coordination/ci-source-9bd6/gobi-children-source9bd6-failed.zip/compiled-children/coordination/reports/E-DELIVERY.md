# E-DELIVERY: compiled keyed child collection delivery

**Outcome: mixed_change. Status: failed.** 5 failure(s) were recorded; this full delivery attempt is not accepted.

## Commands and versions

- Attempt: `compiled-children/demo/output/attempts/attempt-20261031T133539109Z-2893` (full mode, Node unknown, root Go unknown, compiler Go unknown, Chromium unknown).
- Fixture: `fixtures/compiled/children/scenario.json`; scenario seed: `fixed frozen fixture; seeded sequence seed is recorded by N4 harness output`.
- `version-npm`: `npm --version` (exit 0; stdout SHA-256 `d49bd31f65cb736f4045946e1c8365657cfed300dc0e4f173af5e93ab4500e1a`; stderr SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`).
- `version-root-go`: `go version` (exit 0; stdout SHA-256 `07b0d66d21bcdfdc8456adcb17203f3af8656dc11549da62e6940f99b8d45444`; stderr SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`).
- `version-compiler-go`: `go version` (exit 0; stdout SHA-256 `5707bf75dd54b4fdd5ac209444d48c9c4179ebf8510f80e2f7293dfbedc1012b`; stderr SHA-256 `5151ff770762de6f3d21fa34a3ccd2e9a1be33a9d367dbf46a121ff5556cab07`).
- `version-chromium`: `/home/runner/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome --version` (exit 0; stdout SHA-256 `e80c4d9fde0435da1c86813c0248cd6a000255879eb2dc86cde8e09a0213e3b6`; stderr SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`).

## Stage ledger

- preflight-and-toolchain: **failed** — Chromium version output is empty or invalid: Google Chrome for Testing 156.0.8078.4

## Acceptance checks

- Any prior author E-DELIVERY report and receipt were preserved as read-only attempt provenance before canonical files were updated

## Archive and delivery boundary

No complete archive verification was produced.

Prior evidence limitation: The known prior local-container archive corruption remains excluded; its evidence is not copied, repaired, rewritten, or used for this run. The new attempt has independent archive and delivery verification. The accepted prior evidence identifier is `978eaea98831154f8152baa1a64f1d1356916596`.

## Failures and mismatches

- stage:preflight-and-toolchain: Chromium version output is empty or invalid: Google Chrome for Testing 156.0.8078.4
- runner: full runner withheld because frozen inputs or toolchain preflight failed
- archive: Archive withheld because the pre-command source pin set was not captured.
- source-pins-after: sourceAfter differs from sourceBefore
- archive-delivery-boundary: archive, manifest, or source boundary verification is incomplete

Inherited chain: not verified. N4 harness: not matched. N5 literal oracle: not passed. HTTP demo: not passed.

The prior local-container archive was left untouched and is not acceptance evidence. This report does not claim hosted CI success unless a separate run artifact is supplied and matched to this exact source and receipt.
