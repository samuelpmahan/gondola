import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import { add, fill, fixedScripts, save } from "./scripts.mjs";
import { derivePostorder, expectedNativeStep, normalizeFocus, validateNativeCoverage, validateScenario, writeRawArtifacts } from "./check.mjs";

test("postorder is independently derived with ascending sibling IDs", () => {
  const tree = [
    { SessionID: 1, ParentID: 0, Depth: 1 },
    { SessionID: 2, ParentID: 1, Depth: 2 },
    { SessionID: 3, ParentID: 1, Depth: 2 },
    { SessionID: 4, ParentID: 2, Depth: 3 },
    { SessionID: 5, ParentID: 2, Depth: 3 },
    { SessionID: 6, ParentID: 0, Depth: 1 },
  ];
  assert.deepEqual(derivePostorder(tree, 1), [4, 5, 2, 3, 1]);
  assert.throws(() => derivePostorder([
    { SessionID: 1, ParentID: 2, Depth: 2 },
    { SessionID: 2, ParentID: 1, Depth: 3 },
  ], 1), /cycle/i);
});

test("native steps encode actual collection browser actions", () => {
  const snapshot = {
    state: { Rows: [{ ID: 1 }, { ID: 2 }] },
    bindings: [{ Message: "edit/2", Path: "2/1/0" }],
  };
  assert.deepEqual(expectedNativeStep(add("oak"), snapshot), { Path: "0", Event: "click", Value: "" });
  assert.deepEqual(expectedNativeStep(fill("oak", 2, "two\r\nrows"), snapshot), { Path: "2/1/0", Event: "input", Value: "tworows" });
  assert.deepEqual(expectedNativeStep(save("oak", 2), snapshot), { Path: "2/1/5", Event: "click", Value: "" });
});

test("collapsed selection is normalized; noncollapsed direction stays exact", () => {
  assert.deepEqual(normalizeFocus({ key: "row-1-input", selectionStart: 4, selectionEnd: 4, selectionDirection: "backward" }), {
    key: "row-1-input", selectionStart: 4, selectionEnd: 4, selectionDirection: "none",
  });
  assert.deepEqual(normalizeFocus({ key: "row-1-input", selectionStart: 2, selectionEnd: 6, selectionDirection: "backward" }), {
    key: "row-1-input", selectionStart: 2, selectionEnd: 6, selectionDirection: "backward",
  });
});

test("native comparison channels fail closed when segments are absent or empty", () => {
  const issues = [];
  validateNativeCoverage({ ticks: [], nativeSegments: [] }, issues);
  assert.ok(issues.some(({ field }) => field === "native.missing-segments"));
  const empty = [];
  validateNativeCoverage({ ticks: [], nativeSegments: [{ name: "oak", generation: 1, frames: empty }] }, empty);
  assert.ok(empty.some(({ field }) => field === "native.empty-segment"));
});

test("scenario checker requires all actor channels even when candidate and reference both omit them", () => {
  const scenario = {
    name: "missing-channel-control",
    actions: [],
    ticks: [{ index: 0, action: null, candidate: {}, reference: {} }],
    nativeSegments: [],
  };
  const issues = validateScenario(scenario);
  assert.ok(issues.some(({ field }) => field === "actor.missing.managerTree"));
  assert.ok(issues.some(({ field }) => field === "actor.missing.audit" || field.includes("session")));
  assert.ok(issues.some(({ field }) => field === "native.missing-segments"));
});

test("scenario checker fails closed when both actors omit immediate focus channels", () => {
  const action = { kind: "root", name: "oak", backend: "dom" };
  const actor = { managerTree: [], hostTree: [], managerList: [], sessions: [], snapshotAllIDs: [], activeIDs: [], transports: [], rootSlots: [] };
  const scenario = {
    name: "missing-focus-channel-control",
    actions: [action],
    ticks: [
      { index: 0, action: null, candidate: actor, reference: structuredClone(actor) },
      { index: 1, action, candidate: actor, reference: structuredClone(actor),
        operationResults: [{ side: "candidate" }, { side: "reference" }] },
    ],
    nativeSegments: [{ name: "oak", generation: 1, frames: [{}, {}] }],
  };
  const issues = validateScenario(scenario);
  assert.ok(issues.some(({ field }) => field === "focus.activation-missing"));
  assert.ok(issues.some(({ field }) => field === "focus.post-action-missing"));
});

test("fixed schedules retain required nested renderer and disposal witnesses", () => {
  assert.deepEqual(fixedScripts.map(({ actions }) => actions.length), [27, 21, 16]);
  assert.ok(fixedScripts.some(({ actions }) => actions.some((action) => action.kind === "stale-release")));
  assert.ok(fixedScripts.some(({ actions }) => actions.filter((action) => action.kind === "replace").length >= 3));
});

test("raw evidence shards preserve every scenario and mismatch with verifiable hashes", async () => {
  const outputDir = await mkdtemp(join(tmpdir(), "session-tree-raw-evidence-"));
  try {
    const scenarios = [
      { name: "first", seed: 7, actions: [{ kind: "root" }], ticks: [{ candidate: { sessions: [{}] }, reference: { sessions: [{}] } }], nativeSegments: [{ frames: [{}] }] },
      { name: "second", seed: 9, actions: [], ticks: [{ candidate: { sessions: [] }, reference: { sessions: [] } }], nativeSegments: [] },
    ];
    const issues = Array.from({ length: 300 }, (_, index) => ({ field: `control-${index}`, tick: index }));
    const artifacts = await writeRawArtifacts({ scenarios, issues, outputDir, baseName: "bounded-test" });
    assert.equal(artifacts.scenarioFiles.length, 2);
    assert.deepEqual(artifacts.scenarioFiles.map(({ name }) => name), ["first", "second"]);
    assert.ok(artifacts.scenarioFiles.every((entry) => entry.sha256.length === 64));
    assert.equal(artifacts.scenarioFiles[0].globalTicks, 1);
    assert.equal(artifacts.scenarioFiles[0].candidateSessionObservations, 1);
    assert.equal(artifacts.scenarioFiles[0].referenceSessionObservations, 1);
    assert.equal(artifacts.mismatchArtifact.count, 300);
    assert.equal(artifacts.mismatchArtifact.sha256.length, 64);
    const encodedIssues = await readFile(artifacts.mismatchArtifact.path, "utf8");
    assert.equal(JSON.parse(encodedIssues).length, 300);
    assert.equal(createHash("sha256").update(encodedIssues).digest("hex"), artifacts.mismatchArtifact.sha256);
    const encodedScenario = await readFile(artifacts.scenarioFiles[1].path, "utf8");
    assert.deepEqual(JSON.parse(encodedScenario), scenarios[1]);
    assert.equal(createHash("sha256").update(encodedScenario).digest("hex"), artifacts.scenarioFiles[1].sha256);
  } finally {
    await rm(outputDir, { recursive: true, force: true });
  }
});
