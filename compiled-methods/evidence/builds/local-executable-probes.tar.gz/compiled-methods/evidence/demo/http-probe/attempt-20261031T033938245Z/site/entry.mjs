import { gobiCompiled as methodsModule } from "/workspace/scratch/39a56936f173/gondola-methods/compiled-methods/artifacts/compiler-gate/react/output/apps/methods-0cac42b0a982/gobi-compiled.mjs";
import * as methodsEncoder from "/workspace/scratch/39a56936f173/gondola-methods/compiled-methods/artifacts/compiler-gate/react/output/apps/methods-0cac42b0a982/encoder.mjs";
import { startMethodDemo } from "/workspace/scratch/39a56936f173/gondola-methods/compiled-methods/demo/app.mjs";
startMethodDemo(methodsModule, methodsEncoder);
