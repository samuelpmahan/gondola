// Generated file based on view.go
// Updated when compliance tests are re-run, DO NOT EDIT!

import * as $ from "@goscript/builtin/index.js"
import * as strconv from "@goscript/strconv/index.js"
import * as gobi from "@goscript/github.com/samuelpmahan/gondola/gobi/index.js"
import * as counter from "@goscript/github.com/samuelpmahan/gondola/counter/index.js"
import * as __goscript_app from "./app.gs.ts"
import "@goscript/strconv/index.js"
import "@goscript/github.com/samuelpmahan/gondola/gobi/index.js"
import "@goscript/github.com/samuelpmahan/gondola/counter/index.js"
import "./app.gs.ts"

export function View(state: __goscript_app.State): gobi.Node {
	return state.ComposeView()
}
