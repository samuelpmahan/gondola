// Generated file based on app.go
// Updated when compliance tests are re-run, DO NOT EDIT!

import * as $ from "@goscript/builtin/index.js"
import * as counter from "@goscript/github.com/samuelpmahan/gondola/counter/index.js"
import * as gobi from "@goscript/github.com/samuelpmahan/gondola/gobi/index.js"
import * as strconv from "@goscript/strconv/index.js"
import * as __goscript_view from "./view.gs.ts"
import "./view.gs.ts"

$.registerTypePackagePath("github.com/samuelpmahan/gondola/fixtures/compiled/methods", ["methods.State"])

export class State {
	public declare Parent: counter.State

	public declare Child: counter.State

	public declare ReadOnly: boolean

	public declare SavedChild: number

	constructor(__goscriptValue?: boolean, Parent$?: counter.State, Child$?: counter.State, ReadOnly$?: boolean, SavedChild$?: number) {
		this.Parent = Parent$ ?? new counter.State(true)
		this.Child = Child$ ?? new counter.State(true)
		this.ReadOnly = ReadOnly$ ?? false
		this.SavedChild = SavedChild$ ?? 0
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): State {
		return new State(true, this.Parent.clone(), this.Child.clone(), this.ReadOnly, this.SavedChild)
	}

	public __goscriptAssign(source: State): this {
		this.Parent.__goscriptAssign(source.Parent)
		this.Child.__goscriptAssign(source.Child)
		this.ReadOnly = source.ReadOnly
		this.SavedChild = source.SavedChild
		return this
	}

	public AddChild(): [State, $.Slice<gobi.Effect>] {
		const state = this;
		if (state.ReadOnly) {
			return [(state).clone(), null]
		}
		let __goscriptTuple0: any = counter.Update((state.Child).clone(), new gobi.Message(true, "add"))
		let child: counter.State = __goscriptTuple0[0]
		let effects: $.Slice<gobi.Effect> = __goscriptTuple0[1]
		state.Child.__goscriptAssign(child)
		return [(state).clone(), effects]
	}

	public AddParent(): [State, $.Slice<gobi.Effect>] {
		const state = this;
		let __goscriptTuple1: any = counter.Update((state.Parent).clone(), new gobi.Message(true, "add"))
		let parent: counter.State = __goscriptTuple1[0]
		let effects: $.Slice<gobi.Effect> = __goscriptTuple1[1]
		state.Parent.__goscriptAssign(parent)
		return [(state).clone(), effects]
	}

	public CaptureChild(): [State, $.Slice<gobi.Effect>] {
		const state = this;
		state.SavedChild = state.Child.Count
		return [(state).clone(), null]
	}

	public ComposeView(): gobi.Node {
		const state = this;
		let parentLabel = gobi.El("p", $.arrayToSlice<gobi.Node>([gobi.Txt("Parent: "), gobi.Txt(strconv.FormatFloat(state.Parent.Count, 102, -1, 64))]))
		let parentAdd = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("button", $.arrayToSlice<gobi.Node>([gobi.Txt("Parent +")])))).Keyed("parent-add"))).Handle("click", "parentAdd", "")
		let parentReset = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("button", $.arrayToSlice<gobi.Node>([gobi.Txt("Parent Reset")])))).Keyed("parent-reset"))).Handle("click", "parentReset", "")
		if (state.Parent.Count == 0) {
			parentReset = parentReset.__goscriptAssign($.markAsStructValue($.cloneStructValue(parentReset)).Flag("disabled"))
		}
		let parent = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("div", $.arrayToSlice<gobi.Node>([parentLabel, parentAdd, parentReset])))).Keyed("parent"))).Set("class", "parent-counter")

		let childLabel = gobi.El("p", $.arrayToSlice<gobi.Node>([gobi.Txt("Child: "), gobi.Txt(strconv.FormatFloat(state.Child.Count, 102, -1, 64))]))
		let childAdd = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("button", $.arrayToSlice<gobi.Node>([gobi.Txt("Child +")])))).Keyed("child-add"))).Handle("click", "childAdd", "")
		let childReset = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("button", $.arrayToSlice<gobi.Node>([gobi.Txt("Child Reset")])))).Keyed("child-reset"))).Handle("click", "childReset", "")
		if (state.ReadOnly) {
			childAdd = childAdd.__goscriptAssign($.markAsStructValue($.cloneStructValue(childAdd)).Flag("disabled"))
			childReset = childReset.__goscriptAssign($.markAsStructValue($.cloneStructValue(childReset)).Flag("disabled"))
		} else {
			if (state.Child.Count == 0) {
				childReset = childReset.__goscriptAssign($.markAsStructValue($.cloneStructValue(childReset)).Flag("disabled"))
			}
		}
		let child = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("div", $.arrayToSlice<gobi.Node>([childLabel, childAdd, childReset])))).Keyed("child"))).Set("class", "child-counter")

		let lockLabel = "Lock child"
		if (state.ReadOnly) {
			lockLabel = "Unlock child"
		}
		let lock = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("button", $.arrayToSlice<gobi.Node>([gobi.Txt(lockLabel)])))).Keyed("readonly-toggle"))).Handle("click", "toggleReadOnly", "")
		let saved = gobi.El("p", $.arrayToSlice<gobi.Node>([gobi.Txt("Saved child: "), gobi.Txt(strconv.FormatFloat(state.SavedChild, 102, -1, 64))]))
		let capture = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("button", $.arrayToSlice<gobi.Node>([gobi.Txt("Capture child")])))).Keyed("capture-child"))).Handle("click", "captureChild", "")
		let publish = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("button", $.arrayToSlice<gobi.Node>([gobi.Txt("Publish saved to parent")])))).Keyed("publish-saved"))).Handle("click", "publishSaved", "")

		return $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("div", $.arrayToSlice<gobi.Node>([parent, child, lock, saved, capture, publish])))).Keyed("methods"))).Set("class", "method-composition")
	}

	public Initialize(): State {
		const state = this;
		state.Parent.__goscriptAssign(counter.Init())
		state.Child.__goscriptAssign(counter.Init())
		return (state).clone()
	}

	public PublishSaved(): [State, $.Slice<gobi.Effect>] {
		const state = this;
		state.Parent.Count = state.SavedChild
		return [(state).clone(), null]
	}

	public Reduce(message: gobi.Message): [State, $.Slice<gobi.Effect>] {
		const state = this;
		switch (message.Name) {
			case "parentAdd":
			{
				return $.markAsStructValue($.cloneStructValue(state)).AddParent()
				break
			}
			case "parentReset":
			{
				return $.markAsStructValue($.cloneStructValue(state)).ResetParent()
				break
			}
			case "childAdd":
			{
				return $.markAsStructValue($.cloneStructValue(state)).AddChild()
				break
			}
			case "childReset":
			{
				return $.markAsStructValue($.cloneStructValue(state)).ResetChild()
				break
			}
			case "toggleReadOnly":
			{
				return $.markAsStructValue($.cloneStructValue(state)).ToggleReadOnly()
				break
			}
			case "captureChild":
			{
				return $.markAsStructValue($.cloneStructValue(state)).CaptureChild()
				break
			}
			case "publishSaved":
			{
				return $.markAsStructValue($.cloneStructValue(state)).PublishSaved()
				break
			}
			default:
			{
				return [(state).clone(), null]
				break
			}
		}
		throw new globalThis.Error("goscript: unreachable return")
	}

	public ResetChild(): [State, $.Slice<gobi.Effect>] {
		const state = this;
		if (state.ReadOnly) {
			return [(state).clone(), null]
		}
		let __goscriptTuple2: any = counter.Update((state.Child).clone(), new gobi.Message(true, "reset"))
		let child: counter.State = __goscriptTuple2[0]
		let effects: $.Slice<gobi.Effect> = __goscriptTuple2[1]
		state.Child.__goscriptAssign(child)
		return [(state).clone(), effects]
	}

	public ResetParent(): [State, $.Slice<gobi.Effect>] {
		const state = this;
		let __goscriptTuple3: any = counter.Update((state.Parent).clone(), new gobi.Message(true, "reset"))
		let parent: counter.State = __goscriptTuple3[0]
		let effects: $.Slice<gobi.Effect> = __goscriptTuple3[1]
		state.Parent.__goscriptAssign(parent)
		return [(state).clone(), effects]
	}

	public ToggleReadOnly(): [State, $.Slice<gobi.Effect>] {
		const state = this;
		state.ReadOnly = !state.ReadOnly
		return [(state).clone(), null]
	}

	static __typeInfo = $.registerStructType(
		"methods.State",
		() => new State(),
		() => [{ name: "AddChild", args: [], returns: [{ type: "methods.State" }, { type: /* @__PURE__ */ $.sliceType("gobi.Effect") }] }, { name: "AddParent", args: [], returns: [{ type: "methods.State" }, { type: /* @__PURE__ */ $.sliceType("gobi.Effect") }] }, { name: "CaptureChild", args: [], returns: [{ type: "methods.State" }, { type: /* @__PURE__ */ $.sliceType("gobi.Effect") }] }, { name: "ComposeView", args: [], returns: [{ type: "gobi.Node" }] }, { name: "Initialize", args: [], returns: [{ type: "methods.State" }] }, { name: "PublishSaved", args: [], returns: [{ type: "methods.State" }, { type: /* @__PURE__ */ $.sliceType("gobi.Effect") }] }, { name: "Reduce", args: [{ type: { kind: $.TypeKind.Basic, name: "unknown" } }], returns: [{ type: "methods.State" }, { type: /* @__PURE__ */ $.sliceType("gobi.Effect") }] }, { name: "ResetChild", args: [], returns: [{ type: "methods.State" }, { type: /* @__PURE__ */ $.sliceType("gobi.Effect") }] }, { name: "ResetParent", args: [], returns: [{ type: "methods.State" }, { type: /* @__PURE__ */ $.sliceType("gobi.Effect") }] }, { name: "ToggleReadOnly", args: [], returns: [{ type: "methods.State" }, { type: /* @__PURE__ */ $.sliceType("gobi.Effect") }] }],
		State,
		() => [{ name: "Parent", key: "Parent", type: "counter.State" }, { name: "Child", key: "Child", type: "counter.State" }, { name: "ReadOnly", key: "ReadOnly", type: /* @__PURE__ */ $.basicType("bool") }, { name: "SavedChild", key: "SavedChild", type: /* @__PURE__ */ $.basicType("float64") }]
	)
}

export function Init(): State {
	let state: State = new State(true)
	return $.markAsStructValue($.cloneStructValue(state)).Initialize()
}

export function Update(state: State, message: gobi.Message): [State, $.Slice<gobi.Effect>] {
	return state.Reduce(message)
}
