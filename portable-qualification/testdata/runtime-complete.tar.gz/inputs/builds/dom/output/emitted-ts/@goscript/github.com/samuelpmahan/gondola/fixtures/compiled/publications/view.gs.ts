// Generated file based on view.go
// Updated when compliance tests are re-run, DO NOT EDIT!

import * as $ from "@goscript/builtin/index.js"
import * as strconv from "@goscript/strconv/index.js"
import * as gobi from "@goscript/github.com/samuelpmahan/gondola/gobi/index.js"
import * as counter from "@goscript/github.com/samuelpmahan/gondola/counter/index.js"
import * as __goscript_app from "./app.gs.ts"
import "@goscript/github.com/samuelpmahan/gondola/counter/index.js"

export function View(state: __goscript_app.State): gobi.Node {
	let parentStatus = "Parent removed"
	if (state.Parent.Alive) {
		parentStatus = "Parent generation " + strconv.FormatUint(state.Parent.Generation, 10) + "; input step=" + strconv.Itoa(state.Input.Step) + " locked=" + boolText(state.Input.Locked) + " revision=" + strconv.FormatUint(state.Input.Revision, 10) + "; " + requestStatus(state.Parent.Pending, state.Parent.Token, state.Parent.Reply)
	}
	let publicationStatus = "No accepted publication"
	if (!$.stringEqual(state.Parent.PublishedKey, "")) {
		publicationStatus = "Published " + state.Parent.PublishedKey + " value=" + strconv.FormatFloat(state.Parent.PublishedValue, 102, -1, 64)
	}
	let parent = $.markAsStructValue($.cloneStructValue(gobi.El("section", $.arrayToSlice<gobi.Node>([$.markAsStructValue($.cloneStructValue(gobi.El("p", $.arrayToSlice<gobi.Node>([gobi.Txt(parentStatus)])))).Keyed("parent-status"), button("input-step-1", "Set input step 1", "input.step", "1", !state.Parent.Alive || (state.Input.Step == 1)), button("input-step-2", "Set input step 2", "input.step", "2", !state.Parent.Alive || (state.Input.Step == 2)), button("input-step-3", "Set input step 3", "input.step", "3", !state.Parent.Alive || (state.Input.Step == 3)), button("input-toggle-lock", inputLockLabel(state.Input.Locked), "input.toggleLock", "", !state.Parent.Alive), button("parent-request", "Request parent", "parent.request", "", !state.Parent.Alive || state.Parent.Pending), button("parent-remove", "Remove parent", "parent.remove", "", !state.Parent.Alive), button("parent-remount", "Remount parent", "parent.remount", "", state.Parent.Alive), $.markAsStructValue($.cloneStructValue(gobi.El("p", $.arrayToSlice<gobi.Node>([gobi.Txt(publicationStatus)])))).Keyed("parent-publication-status"), $.markAsStructValue($.cloneStructValue(gobi.El("p", $.arrayToSlice<gobi.Node>([gobi.Txt("Accepted=" + strconv.FormatUint(state.Parent.Accepted, 10) + " Rejected=" + strconv.FormatUint(state.Parent.Rejected, 10))])))).Keyed("parent-publication-counts"), $.markAsStructValue($.cloneStructValue(gobi.El("p", $.arrayToSlice<gobi.Node>([gobi.Txt("Last decision: " + state.LastDecision)])))).Keyed("last-decision")])))).Keyed("parent")

	let rows = $.makeSlice<gobi.Node>($.sliceLen(state.Children), undefined, undefined, () => new gobi.Node(true))
	for (let __goscriptRangeTarget0 = state.Children, __goscriptRangeWindow0 = $.sliceRange(__goscriptRangeTarget0), __goscriptSliceWindow0 = $.sliceRange(rows), index = 0; index < __goscriptRangeWindow0.length; index++) {
		let child = ((__goscriptRangeWindow0.backing[__goscriptRangeWindow0.offset + index] as __goscript_app.ChildState)).clone()
		let key = child.Key
		let status = "Child " + key + " generation " + strconv.FormatUint(child.Generation, 10) + "; count=" + strconv.FormatFloat(child.Counter.Count, 102, -1, 64) + "; last publication=" + strconv.FormatUint(child.LastAcceptedPublication, 10) + "; " + requestStatus(child.Pending, child.Token, child.Reply)
		let rowKids: $.Slice<gobi.Node> = $.arrayToSlice<gobi.Node>([$.markAsStructValue($.cloneStructValue(gobi.El("p", $.arrayToSlice<gobi.Node>([gobi.Txt(status)])))).Keyed("child-" + key + "-status"), button("child-" + key + "-count", "Add to " + key, "counter.add", key, !state.Parent.Alive || state.Input.Locked), button("child-" + key + "-request", "Request " + key, "child.request", key, !state.Parent.Alive || child.Pending), button("child-" + key + "-capture", "Capture " + key, "child.capture", key, !state.Parent.Alive || state.Input.Locked), button("child-" + key + "-remove", "Remove " + key, "child.remove", key, !state.Parent.Alive)])
		if (index > 0) {
			rowKids = $.appendOne(rowKids, button("child-" + key + "-move-up", "Move " + key + " up", "children.swap", $.plainSliceIndex(state.Children!, index - 1).Key + ":" + key, false))
		}
		;(__goscriptSliceWindow0.backing as any[])[$.windowSlot(__goscriptSliceWindow0, index)].__goscriptAssign($.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("section", rowKids))).Set("class", "child"))).Keyed("child-" + key))
	}
	let childList = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("div", rows))).Set("class", "children"))).Keyed("children")

	let addKeys = $.arrayToSlice<string>(["oak", "elm", "ash", "pine"])
	let controls: $.Slice<gobi.Node> = $.makeSlice<gobi.Node>(0, 5, undefined, () => new gobi.Node(true))
	for (let __goscriptRangeTarget1 = addKeys, __goscriptRangeWindow1 = $.sliceRange(__goscriptRangeTarget1), __rangeIndex = 0; __rangeIndex < __goscriptRangeWindow1.length; __rangeIndex++) {
		let key = (__goscriptRangeWindow1.backing[__goscriptRangeWindow1.offset + __rangeIndex] as string)
		controls = $.appendOne(controls, button("child-add-" + key, "Add " + key, "child.add", key, !state.Parent.Alive || (__goscript_app.childIndex(state.Children, key) >= 0)))
	}
	controls = $.appendOne(controls, button("children-clear", "Clear children", "children.clear", "", !state.Parent.Alive || ($.sliceLen(state.Children) == 0)))
	let collectionControls = $.markAsStructValue($.cloneStructValue(gobi.El("aside", controls))).Keyed("children-controls")

	let queued = $.makeSlice<gobi.Node>($.sliceLen(state.Publications), undefined, undefined, () => new gobi.Node(true))
	for (let __goscriptRangeTarget2 = state.Publications, __goscriptRangeWindow2 = $.sliceRange(__goscriptRangeTarget2), __goscriptSliceWindow1 = $.sliceRange(queued), index = 0; index < __goscriptRangeWindow2.length; index++) {
		let publication = ((__goscriptRangeWindow2.backing[__goscriptRangeWindow2.offset + index] as __goscript_app.Publication)).clone()
		let id = strconv.FormatUint(publication.ID, 10)
		let label = "Deliver #" + id + " " + publication.Key + " value=" + strconv.FormatFloat(publication.Value, 102, -1, 64);
		;(__goscriptSliceWindow1.backing as any[])[$.windowSlot(__goscriptSliceWindow1, index)].__goscriptAssign($.markAsStructValue($.cloneStructValue(gobi.El("section", $.arrayToSlice<gobi.Node>([button("publication-deliver-" + id, label, "publication.deliver", id, false), $.markAsStructValue($.cloneStructValue(gobi.El("p", $.arrayToSlice<gobi.Node>([gobi.Txt("parent=" + strconv.FormatUint(publication.ParentGeneration, 10) + " child=" + strconv.FormatUint(publication.ChildGeneration, 10) + " input=" + strconv.FormatUint(publication.InputRevision, 10))])))).Keyed("publication-" + id + "-metadata")])))).Keyed("publication-" + id))
	}
	let publicationQueue = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("section", queued))).Set("class", "publications"))).Keyed("publications")

	return $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("main", $.arrayToSlice<gobi.Node>([parent, childList, collectionControls, publicationQueue])))).Set("class", "compiled-publications"))).Keyed("compiled-publications")
}

export function inputLockLabel(locked: boolean): string {
	if (locked) {
		return "Unlock input"
	}
	return "Lock input"
}

export function boolText(value: boolean): string {
	if (value) {
		return "true"
	}
	return "false"
}

export function requestStatus(pending: boolean, token: string, reply: string): string {
	if (pending) {
		return "pending " + token
	}
	if (!$.stringEqual(reply, "")) {
		return "complete " + reply
	}
	return "idle"
}

export function button(key: string, label: string, message: string, arg: string, disabled: boolean): gobi.Node {
	let result = $.markAsStructValue($.cloneStructValue($.markAsStructValue($.cloneStructValue(gobi.El("button", $.arrayToSlice<gobi.Node>([gobi.Txt(label)])))).Keyed(key))).Handle("click", message, arg)
	if (disabled) {
		result = result.__goscriptAssign($.markAsStructValue($.cloneStructValue(result)).Flag("disabled"))
	}
	return result
}
