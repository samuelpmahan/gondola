// Generated file based on app.go
// Updated when compliance tests are re-run, DO NOT EDIT!

import * as $ from "@goscript/builtin/index.js"
import * as strconv from "@goscript/strconv/index.js"
import * as counter from "@goscript/github.com/samuelpmahan/gondola/counter/index.js"
import * as gobi from "@goscript/github.com/samuelpmahan/gondola/gobi/index.js"

$.registerTypePackagePath("github.com/samuelpmahan/gondola/fixtures/compiled/publications", ["publications.ParentInput", "publications.ParentState", "publications.ChildState", "publications.Publication", "publications.State"])

export class ParentInput {
	public declare Step: number

	public declare Locked: boolean

	public declare Revision: bigint

	constructor(__goscriptValue?: boolean, Step$?: number, Locked$?: boolean, Revision$?: bigint) {
		this.Step = Step$ ?? 0
		this.Locked = Locked$ ?? false
		this.Revision = Revision$ ?? 0n
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): ParentInput {
		return new ParentInput(true, this.Step, this.Locked, this.Revision)
	}

	public __goscriptAssign(source: ParentInput): this {
		this.Step = source.Step
		this.Locked = source.Locked
		this.Revision = source.Revision
		return this
	}

	static __typeInfo = $.registerStructType(
		"publications.ParentInput",
		() => new ParentInput(),
		() => [],
		ParentInput,
		() => [{ name: "Step", key: "Step", type: /* @__PURE__ */ $.basicType("int") }, { name: "Locked", key: "Locked", type: /* @__PURE__ */ $.basicType("bool") }, { name: "Revision", key: "Revision", type: /* @__PURE__ */ $.basicType("uint64") }]
	)
}

export class ParentState {
	public declare Alive: boolean

	public declare Generation: bigint

	public declare RequestSeq: bigint

	public declare Pending: boolean

	public declare Token: string

	public declare Reply: string

	public declare PublishedKey: string

	public declare PublishedValue: number

	public declare Accepted: bigint

	public declare Rejected: bigint

	constructor(__goscriptValue?: boolean, Alive$?: boolean, Generation$?: bigint, RequestSeq$?: bigint, Pending$?: boolean, Token$?: string, Reply$?: string, PublishedKey$?: string, PublishedValue$?: number, Accepted$?: bigint, Rejected$?: bigint) {
		this.Alive = Alive$ ?? false
		this.Generation = Generation$ ?? 0n
		this.RequestSeq = RequestSeq$ ?? 0n
		this.Pending = Pending$ ?? false
		this.Token = Token$ ?? ""
		this.Reply = Reply$ ?? ""
		this.PublishedKey = PublishedKey$ ?? ""
		this.PublishedValue = PublishedValue$ ?? 0
		this.Accepted = Accepted$ ?? 0n
		this.Rejected = Rejected$ ?? 0n
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): ParentState {
		return new ParentState(true, this.Alive, this.Generation, this.RequestSeq, this.Pending, this.Token, this.Reply, this.PublishedKey, this.PublishedValue, this.Accepted, this.Rejected)
	}

	public __goscriptAssign(source: ParentState): this {
		this.Alive = source.Alive
		this.Generation = source.Generation
		this.RequestSeq = source.RequestSeq
		this.Pending = source.Pending
		this.Token = source.Token
		this.Reply = source.Reply
		this.PublishedKey = source.PublishedKey
		this.PublishedValue = source.PublishedValue
		this.Accepted = source.Accepted
		this.Rejected = source.Rejected
		return this
	}

	static __typeInfo = $.registerStructType(
		"publications.ParentState",
		() => new ParentState(),
		() => [],
		ParentState,
		() => [{ name: "Alive", key: "Alive", type: /* @__PURE__ */ $.basicType("bool") }, { name: "Generation", key: "Generation", type: /* @__PURE__ */ $.basicType("uint64") }, { name: "RequestSeq", key: "RequestSeq", type: /* @__PURE__ */ $.basicType("uint64") }, { name: "Pending", key: "Pending", type: /* @__PURE__ */ $.basicType("bool") }, { name: "Token", key: "Token", type: /* @__PURE__ */ $.basicType("string") }, { name: "Reply", key: "Reply", type: /* @__PURE__ */ $.basicType("string") }, { name: "PublishedKey", key: "PublishedKey", type: /* @__PURE__ */ $.basicType("string") }, { name: "PublishedValue", key: "PublishedValue", type: /* @__PURE__ */ $.basicType("float64") }, { name: "Accepted", key: "Accepted", type: /* @__PURE__ */ $.basicType("uint64") }, { name: "Rejected", key: "Rejected", type: /* @__PURE__ */ $.basicType("uint64") }]
	)
}

export class ChildState {
	public declare Key: string

	public declare Counter: counter.State

	public declare Generation: bigint

	public declare RequestSeq: bigint

	public declare Pending: boolean

	public declare Token: string

	public declare Reply: string

	public declare LastAcceptedPublication: bigint

	constructor(__goscriptValue?: boolean, Key$?: string, Counter$?: counter.State, Generation$?: bigint, RequestSeq$?: bigint, Pending$?: boolean, Token$?: string, Reply$?: string, LastAcceptedPublication$?: bigint) {
		this.Key = Key$ ?? ""
		this.Counter = Counter$ ?? new counter.State(true)
		this.Generation = Generation$ ?? 0n
		this.RequestSeq = RequestSeq$ ?? 0n
		this.Pending = Pending$ ?? false
		this.Token = Token$ ?? ""
		this.Reply = Reply$ ?? ""
		this.LastAcceptedPublication = LastAcceptedPublication$ ?? 0n
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): ChildState {
		return new ChildState(true, this.Key, this.Counter.clone(), this.Generation, this.RequestSeq, this.Pending, this.Token, this.Reply, this.LastAcceptedPublication)
	}

	public __goscriptAssign(source: ChildState): this {
		this.Key = source.Key
		this.Counter.__goscriptAssign(source.Counter)
		this.Generation = source.Generation
		this.RequestSeq = source.RequestSeq
		this.Pending = source.Pending
		this.Token = source.Token
		this.Reply = source.Reply
		this.LastAcceptedPublication = source.LastAcceptedPublication
		return this
	}

	public AddFromInput(input: ParentInput): ChildState {
		const child = this;
		if ((input.Locked || (input.Step < 1)) || (input.Step > 3)) {
			return (child).clone()
		}
		if ((input.Step == 1) && ((child.Counter.Count + 1) <= $.uint64ToNumber(9007199254740991n))) {
			let __goscriptTuple0: any = counter.Update((child.Counter).clone(), new gobi.Message(true, "add"))
			child.Counter.__goscriptAssign(__goscriptTuple0[0])
			return (child).clone()
		}
		if ((input.Step == 2) && ((child.Counter.Count + 2) <= $.uint64ToNumber(9007199254740991n))) {
			let __goscriptTuple1: any = counter.Update((child.Counter).clone(), new gobi.Message(true, "add"))
			child.Counter.__goscriptAssign(__goscriptTuple1[0])
			let __goscriptTuple2: any = counter.Update((child.Counter).clone(), new gobi.Message(true, "add"))
			child.Counter.__goscriptAssign(__goscriptTuple2[0])
			return (child).clone()
		}
		if ((input.Step == 3) && ((child.Counter.Count + 3) <= $.uint64ToNumber(9007199254740991n))) {
			let __goscriptTuple3: any = counter.Update((child.Counter).clone(), new gobi.Message(true, "add"))
			child.Counter.__goscriptAssign(__goscriptTuple3[0])
			let __goscriptTuple4: any = counter.Update((child.Counter).clone(), new gobi.Message(true, "add"))
			child.Counter.__goscriptAssign(__goscriptTuple4[0])
			let __goscriptTuple5: any = counter.Update((child.Counter).clone(), new gobi.Message(true, "add"))
			child.Counter.__goscriptAssign(__goscriptTuple5[0])
		}
		return (child).clone()
	}

	static __typeInfo = $.registerStructType(
		"publications.ChildState",
		() => new ChildState(),
		() => [{ name: "AddFromInput", args: [{ type: { kind: $.TypeKind.Basic, name: "unknown" } }], returns: [{ type: "publications.ChildState" }] }],
		ChildState,
		() => [{ name: "Key", key: "Key", type: /* @__PURE__ */ $.basicType("string") }, { name: "Counter", key: "Counter", type: "counter.State" }, { name: "Generation", key: "Generation", type: /* @__PURE__ */ $.basicType("uint64") }, { name: "RequestSeq", key: "RequestSeq", type: /* @__PURE__ */ $.basicType("uint64") }, { name: "Pending", key: "Pending", type: /* @__PURE__ */ $.basicType("bool") }, { name: "Token", key: "Token", type: /* @__PURE__ */ $.basicType("string") }, { name: "Reply", key: "Reply", type: /* @__PURE__ */ $.basicType("string") }, { name: "LastAcceptedPublication", key: "LastAcceptedPublication", type: /* @__PURE__ */ $.basicType("uint64") }]
	)
}

export class Publication {
	public declare ID: bigint

	public declare Key: string

	public declare ParentGeneration: bigint

	public declare ChildGeneration: bigint

	public declare InputRevision: bigint

	public declare Value: number

	constructor(__goscriptValue?: boolean, ID$?: bigint, Key$?: string, ParentGeneration$?: bigint, ChildGeneration$?: bigint, InputRevision$?: bigint, Value$?: number) {
		this.ID = ID$ ?? 0n
		this.Key = Key$ ?? ""
		this.ParentGeneration = ParentGeneration$ ?? 0n
		this.ChildGeneration = ChildGeneration$ ?? 0n
		this.InputRevision = InputRevision$ ?? 0n
		this.Value = Value$ ?? 0
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): Publication {
		return new Publication(true, this.ID, this.Key, this.ParentGeneration, this.ChildGeneration, this.InputRevision, this.Value)
	}

	public __goscriptAssign(source: Publication): this {
		this.ID = source.ID
		this.Key = source.Key
		this.ParentGeneration = source.ParentGeneration
		this.ChildGeneration = source.ChildGeneration
		this.InputRevision = source.InputRevision
		this.Value = source.Value
		return this
	}

	static __typeInfo = $.registerStructType(
		"publications.Publication",
		() => new Publication(),
		() => [],
		Publication,
		() => [{ name: "ID", key: "ID", type: /* @__PURE__ */ $.basicType("uint64") }, { name: "Key", key: "Key", type: /* @__PURE__ */ $.basicType("string") }, { name: "ParentGeneration", key: "ParentGeneration", type: /* @__PURE__ */ $.basicType("uint64") }, { name: "ChildGeneration", key: "ChildGeneration", type: /* @__PURE__ */ $.basicType("uint64") }, { name: "InputRevision", key: "InputRevision", type: /* @__PURE__ */ $.basicType("uint64") }, { name: "Value", key: "Value", type: /* @__PURE__ */ $.basicType("float64") }]
	)
}

export class State {
	public declare Parent: ParentState

	public declare Children: $.Slice<ChildState>

	public declare NextGeneration: bigint

	public declare Input: ParentInput

	public declare Publications: $.Slice<Publication>

	public declare NextPublication: bigint

	public declare LastDecision: string

	constructor(__goscriptValue?: boolean, Parent$?: ParentState, Children$?: $.Slice<ChildState>, NextGeneration$?: bigint, Input$?: ParentInput, Publications$?: $.Slice<Publication>, NextPublication$?: bigint, LastDecision$?: string) {
		this.Parent = Parent$ ?? new ParentState(true)
		this.Children = Children$ ?? (null! as $.Slice<ChildState>)
		this.NextGeneration = NextGeneration$ ?? 0n
		this.Input = Input$ ?? new ParentInput(true)
		this.Publications = Publications$ ?? (null! as $.Slice<Publication>)
		this.NextPublication = NextPublication$ ?? 0n
		this.LastDecision = LastDecision$ ?? ""
		;(this as any).__goStructValue = __goscriptValue === true
	}

	public clone(): State {
		return new State(true, this.Parent.clone(), this.Children, this.NextGeneration, this.Input.clone(), this.Publications, this.NextPublication, this.LastDecision)
	}

	public __goscriptAssign(source: State): this {
		this.Parent.__goscriptAssign(source.Parent)
		this.Children = source.Children
		this.NextGeneration = source.NextGeneration
		this.Input.__goscriptAssign(source.Input)
		this.Publications = source.Publications
		this.NextPublication = source.NextPublication
		this.LastDecision = source.LastDecision
		return this
	}

	static __typeInfo = $.registerStructType(
		"publications.State",
		() => new State(),
		() => [],
		State,
		() => [{ name: "Parent", key: "Parent", type: "publications.ParentState" }, { name: "Children", key: "Children", type: /* @__PURE__ */ $.sliceType("publications.ChildState") }, { name: "NextGeneration", key: "NextGeneration", type: /* @__PURE__ */ $.basicType("uint64") }, { name: "Input", key: "Input", type: "publications.ParentInput" }, { name: "Publications", key: "Publications", type: /* @__PURE__ */ $.sliceType("publications.Publication") }, { name: "NextPublication", key: "NextPublication", type: /* @__PURE__ */ $.basicType("uint64") }, { name: "LastDecision", key: "LastDecision", type: /* @__PURE__ */ $.basicType("string") }]
	)
}

export const maxSafeID: bigint = 9007199254740991n

export function Init(): State {
	return new State(true, new ParentState(true, true, 1n), $.arrayToSlice<ChildState>([(() => { const __goscriptLiteralField0 = counter.Init(); return new ChildState(true, "oak", __goscriptLiteralField0, 2n) })(), (() => { const __goscriptLiteralField1 = counter.Init(); return new ChildState(true, "elm", __goscriptLiteralField1, 3n) })()]), 3n, new ParentInput(true, 1, undefined, 1n), $.makeSlice<Publication>(0, undefined, undefined, () => new Publication(true)))
}

export function Update(state: State, message: gobi.Message): [State, $.Slice<gobi.Effect>] {
	state = state.__goscriptAssign(cloneState((state).clone()))
	switch (message.Name) {
		case "child.add":
		{
			return addChild((state).clone(), message.Arg)
			break
		}
		case "child.remove":
		{
			return removeChild((state).clone(), message.Arg)
			break
		}
		case "children.swap":
		{
			return [swapChildren((state).clone(), message.Arg), $.arrayToSlice<gobi.Effect>([])]
			break
		}
		case "children.clear":
		{
			if ((!$.stringEqual(message.Arg, "")) || !state.Parent.Alive) {
				return [state, $.arrayToSlice<gobi.Effect>([])]
			}
			let effects = cancelChildren(state.Children)
			state.Children = $.makeSlice<ChildState>(0, undefined, undefined, () => new ChildState(true))
			return [state, effects]
			break
		}
		case "counter.add":
		{
			return [addCounter((state).clone(), message.Arg), $.arrayToSlice<gobi.Effect>([])]
			break
		}
		case "child.capture":
		{
			return [captureChild((state).clone(), message.Arg), $.arrayToSlice<gobi.Effect>([])]
			break
		}
		case "publication.deliver":
		{
			return [deliverPublication((state).clone(), message.Arg), $.arrayToSlice<gobi.Effect>([])]
			break
		}
		case "child.request":
		{
			return requestChild((state).clone(), message.Arg)
			break
		}
		case "parent.request":
		{
			if (!$.stringEqual(message.Arg, "")) {
				return [state, $.arrayToSlice<gobi.Effect>([])]
			}
			return requestParent((state).clone())
			break
		}
		case "parent.remove":
		{
			if (!$.stringEqual(message.Arg, "")) {
				return [state, $.arrayToSlice<gobi.Effect>([])]
			}
			return removeParent((state).clone())
			break
		}
		case "parent.remount":
		{
			if (!$.stringEqual(message.Arg, "")) {
				return [state, $.arrayToSlice<gobi.Effect>([])]
			}
			return [remountParent((state).clone()), $.arrayToSlice<gobi.Effect>([])]
			break
		}
		case "input.step":
		{
			return [setInputStep((state).clone(), message.Arg), $.arrayToSlice<gobi.Effect>([])]
			break
		}
		case "input.toggleLock":
		{
			if (!$.stringEqual(message.Arg, "")) {
				return [state, $.arrayToSlice<gobi.Effect>([])]
			}
			return [toggleInputLock((state).clone()), $.arrayToSlice<gobi.Effect>([])]
			break
		}
		case "complete":
		{
			return [complete((state).clone(), message.Arg), $.arrayToSlice<gobi.Effect>([])]
			break
		}
		default:
		{
			return [state, $.arrayToSlice<gobi.Effect>([])]
			break
		}
	}
	throw new globalThis.Error("goscript: unreachable return")
}

export function cloneState(state: State): State {
	if (state.Children != null) {
		let children: $.Slice<ChildState> = $.makeSlice<ChildState>(0, $.sliceLen(state.Children), undefined, () => new ChildState(true))
		children = $.appendSlice(children, state.Children)
		state.Children = children
	}
	if (state.Publications != null) {
		let publications: $.Slice<Publication> = $.makeSlice<Publication>(0, $.sliceLen(state.Publications), undefined, () => new Publication(true))
		publications = $.appendSlice(publications, state.Publications)
		state.Publications = publications
	}
	return state
}

export function addChild(state: State, key: string): [State, $.Slice<gobi.Effect>] {
	if ((!state.Parent.Alive || !validKey(key)) || (childIndex(state.Children, key) >= 0)) {
		return [state, $.arrayToSlice<gobi.Effect>([])]
	}
	if (state.NextGeneration < 9007199254740991n) {
		state.NextGeneration++
		state.Children = $.appendOne(state.Children, (() => { const __goscriptLiteralField2 = counter.Init(); return new ChildState(true, key, __goscriptLiteralField2, state.NextGeneration) })())
	}
	return [state, $.arrayToSlice<gobi.Effect>([])]
}

export function removeChild(state: State, key: string): [State, $.Slice<gobi.Effect>] {
	if (!state.Parent.Alive || !validKey(key)) {
		return [(state).clone(), $.arrayToSlice<gobi.Effect>([])]
	}
	let index = childIndex(state.Children, key)
	if (index < 0) {
		return [(state).clone(), $.arrayToSlice<gobi.Effect>([])]
	}
	let effects: $.Slice<gobi.Effect> = $.arrayToSlice<gobi.Effect>([])
	if ($.plainSliceIndex(state.Children!, index).Pending) {
		effects = $.appendOne(effects, cancelEffect($.plainSliceIndex(state.Children!, index).Token))
	}
	state.Children = $.appendSlice($.goSlice(state.Children, undefined, index), $.goSlice($.goSlice(state.Children, index, undefined), 1, undefined))
	if ($.sliceLen(state.Children) == 0) {
		state.Children = $.makeSlice<ChildState>(0, undefined, undefined, () => new ChildState(true))
	}
	return [(state).clone(), effects]
}

export function swapChildren(state: State, argument: string): State {
	if (!state.Parent.Alive || ($.stringLen(argument) > 33)) {
		return state
	}
	let separator = -1
	for (let index = 0; (index < $.stringLen(argument)) && (index < 33); index++) {
		if ($.indexString(argument, index) == 58) {
			if (separator >= 0) {
				return state
			}
			separator = index
		}
	}
	if (separator <= 0) {
		return state
	}
	let first = $.sliceStringOrBytes(argument, undefined, separator)
	let rest = $.sliceStringOrBytes(argument, separator, undefined)
	let second = $.sliceStringOrBytes(rest, 1, undefined)
	if ((!validKey(first) || !validKey(second)) || ($.stringEqual(first, second))) {
		return state
	}
	let firstIndex = childIndex(state.Children, first)
	let secondIndex = childIndex(state.Children, second)
	if ((firstIndex < 0) || (secondIndex < 0)) {
		return state
	}
	let __goscriptAssign0_0: ChildState = ($.plainSliceIndex(state.Children!, secondIndex)).clone()
	let __goscriptAssign0_1: ChildState = ($.plainSliceIndex(state.Children!, firstIndex)).clone()
	$.sliceElems(state.Children!)[$.sliceSlot(state.Children!, firstIndex)].__goscriptAssign(__goscriptAssign0_0)
	$.sliceElems(state.Children!)[$.sliceSlot(state.Children!, secondIndex)].__goscriptAssign(__goscriptAssign0_1)
	return state
}

export function addCounter(state: State, key: string): State {
	if ((!state.Parent.Alive || state.Input.Locked) || !validKey(key)) {
		return state
	}
	let index = childIndex(state.Children, key)
	if (index < 0) {
		return state
	}
	let child = $.markAsStructValue($.cloneStructValue($.plainSliceIndex(state.Children!, index))).AddFromInput(state.Input)
	$.sliceElems(state.Children!)[$.sliceSlot(state.Children!, index)].__goscriptAssign(child)
	return state
}

export function captureChild(state: State, key: string): State {
	if ((!state.Parent.Alive || state.Input.Locked) || !validKey(key)) {
		return state
	}
	let index = childIndex(state.Children, key)
	if (index < 0) {
		return state
	}
	let child = ($.plainSliceIndex(state.Children!, index)).clone()
	if (state.NextPublication < 9007199254740991n) {
		state.NextPublication++
		let publication = new Publication(true, state.NextPublication, child.Key, state.Parent.Generation, child.Generation, state.Input.Revision, child.Counter.Count)
		state.Publications = $.appendOne(state.Publications, publication)
	}
	return state
}

export function deliverPublication(state: State, argument: string): State {
	let index = publicationIndex(state.Publications, argument)
	if (index < 0) {
		return (state).clone()
	}
	let publication = ($.plainSliceIndex(state.Publications!, index)).clone()
	let decision = rejectionReason((state).clone(), publication)
	if (!$.stringEqual(decision, "")) {
		if (state.Parent.Rejected < 9007199254740991n) {
			state.Publications = $.appendSlice($.goSlice(state.Publications, undefined, index), $.goSlice($.goSlice(state.Publications, index, undefined), 1, undefined))
			if ($.sliceLen(state.Publications) == 0) {
				state.Publications = $.makeSlice<Publication>(0, undefined, undefined, () => new Publication(true))
			}
			state.Parent.Rejected++
			state.LastDecision = "rejected:" + decision + ":" + strconv.FormatUint(publication.ID, 10)
		}
		return (state).clone()
	}
	if (state.Parent.Accepted < 9007199254740991n) {
		let childIndexValue = childIndex(state.Children, publication.Key)
		let child = ($.plainSliceIndex(state.Children!, childIndexValue)).clone()
		child.LastAcceptedPublication = publication.ID
		$.sliceElems(state.Children!)[$.sliceSlot(state.Children!, childIndexValue)].__goscriptAssign(child)
		state.Parent.PublishedKey = publication.Key
		state.Parent.PublishedValue = publication.Value
		state.Publications = $.appendSlice($.goSlice(state.Publications, undefined, index), $.goSlice($.goSlice(state.Publications, index, undefined), 1, undefined))
		if ($.sliceLen(state.Publications) == 0) {
			state.Publications = $.makeSlice<Publication>(0, undefined, undefined, () => new Publication(true))
		}
		state.Parent.Accepted++
		state.LastDecision = "accepted:" + publication.Key + ":" + strconv.FormatUint(publication.ID, 10)
	}
	return (state).clone()
}

export function rejectionReason(state: State, publication: Publication): string {
	if (!state.Parent.Alive) {
		return "parent-dead"
	}
	if (publication.ParentGeneration != state.Parent.Generation) {
		return "parent-generation"
	}
	if (state.Input.Locked) {
		return "locked"
	}
	if (publication.InputRevision != state.Input.Revision) {
		return "stale-input"
	}
	let index = childIndex(state.Children, publication.Key)
	if (index < 0) {
		return "missing-child"
	}
	let child = ($.plainSliceIndex(state.Children!, index)).clone()
	if (publication.ChildGeneration != child.Generation) {
		return "child-generation"
	}
	if (publication.ID <= child.LastAcceptedPublication) {
		return "stale-id"
	}
	return ""
}

export function publicationIndex(publications: $.Slice<Publication>, argument: string): number {
	if (($.stringLen(argument) == 0) || ($.stringLen(argument) > 16)) {
		return -1
	}
	for (let __goscriptSliceWindow0 = $.sliceRange(publications), index = 0; index < __goscriptSliceWindow0.length; index++) {
		if ($.stringEqual(strconv.FormatUint(((__goscriptSliceWindow0.backing as any[])[$.windowSlot(__goscriptSliceWindow0, index)] as Publication).ID, 10), argument)) {
			return index
		}
	}
	return -1
}

export function setInputStep(state: State, argument: string): State {
	if (!state.Parent.Alive) {
		return state
	}
	let step = 0
	switch (argument) {
		case "1":
		{
			step = 1
			break
		}
		case "2":
		{
			step = 2
			break
		}
		case "3":
		{
			step = 3
			break
		}
		default:
		{
			return state
			break
		}
	}
	if (step == state.Input.Step) {
		return state
	}
	if (state.Input.Revision < 9007199254740991n) {
		state.Input.Step = step
		state.Input.Revision++
	}
	return state
}

export function toggleInputLock(state: State): State {
	if (!state.Parent.Alive) {
		return state
	}
	if (state.Input.Revision < 9007199254740991n) {
		state.Input.Locked = !state.Input.Locked
		state.Input.Revision++
	}
	return state
}

export function requestChild(state: State, key: string): [State, $.Slice<gobi.Effect>] {
	if (!state.Parent.Alive || !validKey(key)) {
		return [state, $.arrayToSlice<gobi.Effect>([])]
	}
	let index = childIndex(state.Children, key)
	if ((index < 0) || $.plainSliceIndex(state.Children!, index).Pending) {
		return [state, $.arrayToSlice<gobi.Effect>([])]
	}
	let child = ($.plainSliceIndex(state.Children!, index)).clone()
	if (child.RequestSeq < 9007199254740991n) {
		child.RequestSeq++
		child.Pending = true
		child.Token = childToken(child.Key, child.Generation, child.RequestSeq)
		child.Reply = ""
		$.sliceElems(state.Children!)[$.sliceSlot(state.Children!, index)].__goscriptAssign(child)
		return [state, $.arrayToSlice<gobi.Effect>([requestEffect(child.Token)])]
	}
	return [state, $.arrayToSlice<gobi.Effect>([])]
}

export function requestParent(state: State): [State, $.Slice<gobi.Effect>] {
	if (!state.Parent.Alive || state.Parent.Pending) {
		return [state, $.arrayToSlice<gobi.Effect>([])]
	}
	if (state.Parent.RequestSeq < 9007199254740991n) {
		state.Parent.RequestSeq++
		state.Parent.Pending = true
		state.Parent.Token = parentToken(state.Parent.Generation, state.Parent.RequestSeq)
		state.Parent.Reply = ""
		return [(state).clone(), $.arrayToSlice<gobi.Effect>([requestEffect(state.Parent.Token)])]
	}
	return [state, $.arrayToSlice<gobi.Effect>([])]
}

export function removeParent(state: State): [State, $.Slice<gobi.Effect>] {
	if (!state.Parent.Alive) {
		return [state, $.arrayToSlice<gobi.Effect>([])]
	}
	let effects: $.Slice<gobi.Effect> = cancelChildren(state.Children)
	if (state.Parent.Pending) {
		effects = $.appendOne(effects, cancelEffect(state.Parent.Token))
	}
	state.Children = $.makeSlice<ChildState>(0, undefined, undefined, () => new ChildState(true))
	state.Parent.Alive = false
	state.Parent.Pending = false
	state.Parent.Token = ""
	return [state, effects]
}

export function remountParent(state: State): State {
	if (state.Parent.Alive) {
		return state
	}
	if (state.NextGeneration < 9007199254740991n) {
		state.NextGeneration++
		state.Parent.__goscriptAssign(new ParentState(true, true, state.NextGeneration))
		state.Children = $.makeSlice<ChildState>(0, undefined, undefined, () => new ChildState(true))
		state.LastDecision = ""
	}
	return state
}

export function complete(state: State, token: string): State {
	if ($.stringEqual(token, "")) {
		return state
	}
	if ((state.Parent.Alive && state.Parent.Pending) && ($.stringEqual(state.Parent.Token, token))) {
		state.Parent.Pending = false
		state.Parent.Reply = token
		return state
	}
	for (let index = 0; index < $.sliceLen(state.Children); index++) {
		let child = ($.plainSliceIndex(state.Children!, index)).clone()
		if (child.Pending && ($.stringEqual(child.Token, token))) {
			child.Pending = false
			child.Reply = token
			$.sliceElems(state.Children!)[$.sliceSlot(state.Children!, index)].__goscriptAssign(child)
			return state
		}
	}
	return state
}

export function cancelChildren(children: $.Slice<ChildState>): $.Slice<gobi.Effect> {
	let effects: $.Slice<gobi.Effect> = $.arrayToSlice<gobi.Effect>([])
	for (let __goscriptSliceWindow1 = $.sliceRange(children), index = 0; index < __goscriptSliceWindow1.length; index++) {
		if (((__goscriptSliceWindow1.backing as any[])[$.windowSlot(__goscriptSliceWindow1, index)] as ChildState).Pending) {
			effects = $.appendSlice($.arrayToSlice<gobi.Effect>([cancelEffect(((__goscriptSliceWindow1.backing as any[])[$.windowSlot(__goscriptSliceWindow1, index)] as ChildState).Token)]), effects)
		}
	}
	return effects
}

export function childIndex(children: $.Slice<ChildState>, key: string): number {
	for (let __goscriptSliceWindow2 = $.sliceRange(children), index = 0; index < __goscriptSliceWindow2.length; index++) {
		if ($.stringEqual(((__goscriptSliceWindow2.backing as any[])[$.windowSlot(__goscriptSliceWindow2, index)] as ChildState).Key, key)) {
			return index
		}
	}
	return -1
}

export function validKey(key: string): boolean {
	if (((($.stringLen(key) == 0) || ($.stringLen(key) > 16)) || ($.indexString(key, 0) < 97)) || ($.indexString(key, 0) > 122)) {
		return false
	}
	for (let __goscriptRunes0 = $.stringRunes(key); __goscriptRunes0.next(); ) {
		const index = __goscriptRunes0.index
		const value = __goscriptRunes0.rune
		if (index == 0) {
			continue
		}
		if (((((value < 97) || (value > 122)) && ((value < 48) || (value > 57))) && (value != 95)) && (value != 45)) {
			return false
		}
	}
	return true
}

export function childToken(key: string, generation: bigint, requestSeq: bigint): string {
	return "child:" + key + ":g" + strconv.FormatUint(generation, 10) + ":r" + strconv.FormatUint(requestSeq, 10)
}

export function parentToken(generation: bigint, requestSeq: bigint): string {
	return "parent:g" + strconv.FormatUint(generation, 10) + ":r" + strconv.FormatUint(requestSeq, 10)
}

export function requestEffect(token: string): gobi.Effect {
	return new gobi.Effect(true, "fixture.request", "lookup", token, "complete")
}

export function cancelEffect(token: string): gobi.Effect {
	return new gobi.Effect(true, "lifecycle.cancel", "cancel", token, "")
}
