// Package composition adds typed parent/child communication to an immutable
// multisession tree while leaving collection transitions owned by Go.
package composition

import (
	"fmt"
	"sort"
	"strconv"
	"strings"
	"sync"
	"unicode/utf8"

	"github.com/samuelpmahan/gondola/asyncsave"
	"github.com/samuelpmahan/gondola/collection"
	"github.com/samuelpmahan/gondola/gobi"
	"github.com/samuelpmahan/gondola/inputbinding"
	"github.com/samuelpmahan/gondola/multisession"
)

// SessionID identifies a live collection session.
type SessionID = multisession.SessionID

// Inputs are the direct, typed values a parent assigns to one child.
type Inputs struct {
	Title    string
	ReadOnly bool
}

// Publication is an immutable receipt appended to a child's immediate
// parent's inbox.
type Publication struct {
	Sequence      uint64
	ParentID      SessionID
	ChildID       SessionID
	RowID         collection.RowID
	Saved         string
	Saves         int
	InputRevision uint64
}

// State extends the owned collection state with this session's direct inputs,
// input revision, and publication inbox.
type State struct {
	collection.State
	Inputs        Inputs
	InputRevision uint64
	Inbox         []Publication
}

// Snapshot pairs the complete composition state with its Gobi view, input
// bindings, and ordered message history.
type Snapshot struct {
	State    State                  `json:"state"`
	Tree     gobi.Node              `json:"tree"`
	Bindings []inputbinding.Binding `json:"bindings"`
	Messages []gobi.Message         `json:"messages"`
}

type sessionState struct {
	parent        SessionID
	inputs        Inputs
	inputRevision uint64
	inbox         []Publication
	messages      []gobi.Message
}

// Manager serializes composition policy with all operations on its private
// multisession manager. The wrapped manager is intentionally not exposed.
type Manager struct {
	mu           sync.Mutex
	base         *multisession.Manager
	sessions     map[SessionID]*sessionState
	changes      map[SessionID]struct{}
	nextSequence uint64
}

// NewManager returns an empty composition manager.
func NewManager() *Manager {
	return &Manager{
		base:     multisession.NewManager(),
		sessions: make(map[SessionID]*sessionState),
		changes:  make(map[SessionID]struct{}),
	}
}

// Create allocates a fresh root collection session.
func (m *Manager) Create() (SessionID, error) {
	m.mu.Lock()
	defer m.mu.Unlock()

	id, err := m.base.Create()
	if err != nil {
		return 0, err
	}
	m.addSessionLocked(id, 0)
	return id, nil
}

// CreateChild allocates a fresh collection session beneath a live parent.
func (m *Manager) CreateChild(parent SessionID) (SessionID, error) {
	m.mu.Lock()
	defer m.mu.Unlock()

	if err := validSessionID(parent); err != nil {
		return 0, err
	}
	id, err := m.base.CreateChild(parent)
	if err != nil {
		return 0, err
	}
	m.addSessionLocked(id, parent)
	return id, nil
}

func (m *Manager) addSessionLocked(id, parent SessionID) {
	m.sessions[id] = &sessionState{
		parent:   parent,
		inbox:    []Publication{},
		messages: []gobi.Message{},
	}
}

// Tree returns the live session tree in ascending SessionID order.
func (m *Manager) Tree() []multisession.SessionInfo {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.base.Tree()
}

// List returns the live session IDs in ascending allocation order.
func (m *Manager) List() []SessionID {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.base.List()
}

// Snapshot returns the current composition view for one live session.
func (m *Manager) Snapshot(id SessionID) (Snapshot, error) {
	m.mu.Lock()
	defer m.mu.Unlock()

	baseSnapshot, err := m.base.Snapshot(id)
	if err != nil {
		return Snapshot{}, err
	}
	return m.snapshotLocked(id, baseSnapshot)
}

// Dispatch applies one event to a session. Row publication controls are
// resolved here as typed calls; all other enabled collection events delegate
// to the wrapped collection manager.
func (m *Manager) Dispatch(id SessionID, step collection.Step) (Snapshot, error) {
	m.mu.Lock()
	defer m.mu.Unlock()

	baseBefore, err := m.base.Snapshot(id)
	if err != nil {
		return Snapshot{}, err
	}
	current, err := m.snapshotLocked(id, baseBefore)
	if err != nil {
		return Snapshot{}, err
	}
	view := inputbinding.View{Tree: current.Tree, Bindings: current.Bindings}
	if err := validateCompositionView(view); err != nil {
		return current, fmt.Errorf("invalid composition view: %w", err)
	}
	target, err := nodeAtPath(current.Tree, step.Path)
	if err != nil {
		return current, err
	}
	if target.Key != step.Key {
		return current, fmt.Errorf("dispatch key %q does not match target key %q", step.Key, target.Key)
	}

	if isPublishControl(target) {
		publishHandlers := make([]gobi.On, 0, 1)
		for _, handler := range target.On {
			if handler.Message == "publish" {
				publishHandlers = append(publishHandlers, handler)
			}
		}
		if len(publishHandlers) != 1 || publishHandlers[0].Event != "click" || step.Event != "click" {
			return current, fmt.Errorf("publish control path, key, or event is not canonical")
		}
		if err := validateEventAt(view, step.Path, step.Event); err != nil {
			return current, fmt.Errorf("publish control path, key, or event is not canonical")
		}
		row, err := rowAtPublishPath(current.State.Rows, step.Path)
		if err != nil {
			return current, fmt.Errorf("publish control does not identify a current collection row")
		}
		expectedKey := "row-" + strconv.FormatUint(uint64(row.ID), 10) + "-publish"
		expectedArg := strconv.FormatUint(uint64(row.ID), 10) + "/" + strconv.FormatUint(current.State.InputRevision, 10)
		if target.Key != expectedKey || publishHandlers[0].Arg != expectedArg {
			return current, fmt.Errorf("publish control must carry an exact ROW/REVISION argument")
		}
		if step.Value != publishHandlers[0].Arg {
			return current, fmt.Errorf("publish dispatch value must equal the current literal ROW/REVISION argument")
		}
		if isDisabled(target) {
			return current, nil
		}
		_, err = m.publishLocked(id, row.ID, current.State.InputRevision)
		if err != nil {
			return current, err
		}
		baseAfter, err := m.base.Snapshot(id)
		if err != nil {
			return Snapshot{}, err
		}
		return m.snapshotLocked(id, baseAfter)
	}

	if err := validateEventAt(view, step.Path, step.Event); err != nil {
		return current, err
	}
	// A disabled control still has to name a real declared event. Read-only
	// suppresses valid events after that path/key/event validation has passed.
	if isDisabled(target) || current.State.Inputs.ReadOnly {
		return current, nil
	}

	baseAfter, err := m.base.Dispatch(id, step)
	if err != nil {
		return current, err
	}
	m.appendBaseMessagesLocked(id, len(baseBefore.Messages), baseAfter.Messages)
	if len(baseAfter.Messages) > len(baseBefore.Messages) {
		m.changes[id] = struct{}{}
	}
	return m.snapshotLocked(id, baseAfter)
}

// Complete delivers a reply to the addressed collection, even when its inputs
// are read-only. Read-only policy does not cancel or reject pending requests.
func (m *Manager) Complete(id SessionID, reply asyncsave.Reply) (Snapshot, error) {
	m.mu.Lock()
	defer m.mu.Unlock()

	baseBefore, err := m.base.Snapshot(id)
	if err != nil {
		return Snapshot{}, err
	}
	baseAfter, err := m.base.Complete(id, reply)
	if err != nil {
		current, snapshotErr := m.snapshotLocked(id, baseBefore)
		if snapshotErr != nil {
			return Snapshot{}, snapshotErr
		}
		return current, err
	}
	m.appendBaseMessagesLocked(id, len(baseBefore.Messages), baseAfter.Messages)
	if len(baseAfter.Messages) > len(baseBefore.Messages) {
		m.changes[id] = struct{}{}
	}
	return m.snapshotLocked(id, baseAfter)
}

// Effects drains commands queued by the addressed collection session.
func (m *Manager) Effects(id SessionID) ([]collection.Command, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.base.Effects(id)
}

// Audit returns the completion history for the addressed collection session.
func (m *Manager) Audit(id SessionID) ([]collection.Outcome, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.base.Audit(id)
}

// Dispose removes a leaf session. Its inbox is discarded, while receipts in
// its parent's inbox remain untouched.
func (m *Manager) Dispose(id SessionID) ([]collection.Command, error) {
	m.mu.Lock()
	defer m.mu.Unlock()

	commands, err := m.base.Dispose(id)
	if err != nil {
		return nil, err
	}
	delete(m.sessions, id)
	delete(m.changes, id)
	return commands, nil
}

// DisposeTree removes a session and all descendants atomically.
func (m *Manager) DisposeTree(id SessionID) ([]multisession.Disposal, error) {
	m.mu.Lock()
	defer m.mu.Unlock()

	disposals, err := m.base.DisposeTree(id)
	if err != nil {
		return nil, err
	}
	for _, disposal := range disposals {
		delete(m.sessions, disposal.SessionID)
		delete(m.changes, disposal.SessionID)
	}
	return disposals, nil
}

// SetChildInputs sets a direct child's inputs and advances its revision.
// Equal values are accepted and still advance the revision.
func (m *Manager) SetChildInputs(parent, child SessionID, inputs Inputs) (Snapshot, error) {
	if !utf8.ValidString(inputs.Title) {
		return Snapshot{}, fmt.Errorf("input title must be valid UTF-8")
	}
	if len(inputs.Title) > 256 {
		return Snapshot{}, fmt.Errorf("input title exceeds 256 UTF-8 bytes")
	}
	if err := validSessionID(parent); err != nil {
		return Snapshot{}, err
	}
	if err := validSessionID(child); err != nil {
		return Snapshot{}, err
	}

	m.mu.Lock()
	defer m.mu.Unlock()
	parentState, parentLive := m.sessions[parent]
	childState, childLive := m.sessions[child]
	if !parentLive {
		return Snapshot{}, fmt.Errorf("unknown session ID %d", parent)
	}
	if !childLive {
		return Snapshot{}, fmt.Errorf("unknown session ID %d", child)
	}
	if childState.parent != parent {
		return Snapshot{}, fmt.Errorf("session ID %d is not an immediate child of session ID %d", child, parent)
	}
	_ = parentState // Parent liveness is part of the direct-parent authorization check.
	if childState.inputRevision >= collection.MaxID {
		return Snapshot{}, fmt.Errorf("input revision space exhausted at %d", childState.inputRevision)
	}
	baseSnapshot, err := m.base.Snapshot(child)
	if err != nil {
		return Snapshot{}, err
	}
	childState.inputs = inputs
	childState.inputRevision++
	m.changes[child] = struct{}{}
	return m.snapshotLocked(child, baseSnapshot)
}

// Publish captures the child's current saved row value and appends a receipt
// to its immediate parent's inbox.
func (m *Manager) Publish(child SessionID, row collection.RowID, revision uint64) (Publication, error) {
	if err := validSessionID(child); err != nil {
		return Publication{}, err
	}
	if row == 0 || uint64(row) > collection.MaxID {
		return Publication{}, fmt.Errorf("row ID %d is outside the supported range 1..%d", row, collection.MaxID)
	}
	if revision > collection.MaxID {
		return Publication{}, fmt.Errorf("input revision %d is outside the supported range 0..%d", revision, collection.MaxID)
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.publishLocked(child, row, revision)
}

func (m *Manager) publishLocked(child SessionID, rowID collection.RowID, revision uint64) (Publication, error) {
	childState, ok := m.sessions[child]
	if !ok {
		return Publication{}, fmt.Errorf("unknown session ID %d", child)
	}
	if childState.parent == 0 {
		return Publication{}, fmt.Errorf("root session ID %d cannot publish", child)
	}
	parentState, ok := m.sessions[childState.parent]
	if !ok {
		return Publication{}, fmt.Errorf("unknown parent session ID %d", childState.parent)
	}
	if childState.inputs.ReadOnly {
		return Publication{}, fmt.Errorf("session ID %d is read-only", child)
	}
	if revision != childState.inputRevision {
		return Publication{}, fmt.Errorf("input revision %d is stale; current revision is %d", revision, childState.inputRevision)
	}
	if m.nextSequence >= collection.MaxID {
		return Publication{}, fmt.Errorf("publication sequence space exhausted at %d", m.nextSequence)
	}
	baseSnapshot, err := m.base.Snapshot(child)
	if err != nil {
		return Publication{}, err
	}
	var row *collection.Row
	for index := range baseSnapshot.State.Rows {
		if baseSnapshot.State.Rows[index].ID == rowID {
			row = &baseSnapshot.State.Rows[index]
			break
		}
	}
	if row == nil {
		return Publication{}, fmt.Errorf("row %d no longer exists", rowID)
	}
	if row.Saved == "" {
		return Publication{}, fmt.Errorf("row %d has no saved value to publish", rowID)
	}

	publication := Publication{
		Sequence:      m.nextSequence + 1,
		ParentID:      childState.parent,
		ChildID:       child,
		RowID:         row.ID,
		Saved:         row.Saved,
		Saves:         row.Saves,
		InputRevision: childState.inputRevision,
	}
	m.nextSequence = publication.Sequence
	parentState.inbox = append(parentState.inbox, publication)
	childState.messages = append(childState.messages, gobi.Message{
		Name: "publish",
		Arg:  strconv.FormatUint(uint64(row.ID), 10) + "/" + strconv.FormatUint(childState.inputRevision, 10),
	})
	m.changes[child] = struct{}{}
	m.changes[childState.parent] = struct{}{}
	return publication, nil
}

// Changes drains sorted unique IDs changed by successful composition or
// collection operations. The result is always a fresh, nonnil slice.
func (m *Manager) Changes() []SessionID {
	m.mu.Lock()
	defer m.mu.Unlock()

	ids := make([]SessionID, 0, len(m.changes))
	for id := range m.changes {
		if _, live := m.sessions[id]; live {
			ids = append(ids, id)
		}
	}
	sort.Slice(ids, func(i, j int) bool { return ids[i] < ids[j] })
	m.changes = make(map[SessionID]struct{})
	return ids
}

func (m *Manager) snapshotLocked(id SessionID, baseSnapshot collection.Snapshot) (Snapshot, error) {
	state, ok := m.sessions[id]
	if !ok {
		return Snapshot{}, fmt.Errorf("unknown session ID %d", id)
	}
	compositionState := State{
		State:         cloneCollectionState(baseSnapshot.State),
		Inputs:        state.inputs,
		InputRevision: state.inputRevision,
		Inbox:         clonePublications(state.inbox),
	}
	view := compositionView(compositionState, state.parent == 0)
	return Snapshot{
		State:    compositionState,
		Tree:     view.Tree,
		Bindings: cloneBindings(view.Bindings),
		Messages: cloneMessages(state.messages),
	}, nil
}

func compositionView(state State, root bool) inputbinding.View {
	view := collection.View(state.State)
	rootNode := view.Tree
	rootNode.Kids = append(rootNode.Kids[:len(rootNode.Kids):len(rootNode.Kids)],
		gobi.El("p", gobi.Txt("Title: "+state.Inputs.Title)).Keyed("composition-title"),
		gobi.El("p", gobi.Txt("Published: "+strconv.Itoa(len(state.Inbox)))).Keyed("composition-inbox"),
	)
	rows := rootNode.Kids[2]
	for index := range rows.Kids {
		row := &rows.Kids[index]
		currentRow := state.Rows[index]
		id := strconv.FormatUint(uint64(currentRow.ID), 10)
		publish := gobi.El("button", gobi.Txt("Publish")).Keyed("row-"+id+"-publish").
			Set("class", "publish").
			Handle("click", "publish", id+"/"+strconv.FormatUint(state.InputRevision, 10))
		if root || currentRow.Saved == "" || state.Inputs.ReadOnly {
			publish = publish.Flag("disabled")
		}
		row.Kids = append(row.Kids[:len(row.Kids):len(row.Kids)], publish)
	}
	view.Tree = rootNode
	if state.Inputs.ReadOnly {
		setReadonlyDisabled(&view.Tree)
	}
	return view
}

func setReadonlyDisabled(node *gobi.Node) {
	if node.Kind == gobi.Element && (node.Tag == "button" || node.Tag == "input") {
		found := false
		for index := range node.Attrs {
			if node.Attrs[index].Name == "disabled" {
				node.Attrs[index].Flag = true
				node.Attrs[index].Value = ""
				node.Attrs[index].Style = nil
				found = true
			}
		}
		if !found {
			node.Attrs = append(node.Attrs[:len(node.Attrs):len(node.Attrs)], gobi.Attr{Name: "disabled", Flag: true})
		}
	}
	for index := range node.Kids {
		setReadonlyDisabled(&node.Kids[index])
	}
}

func (m *Manager) appendBaseMessagesLocked(id SessionID, previousCount int, current []gobi.Message) {
	if previousCount < 0 || previousCount > len(current) {
		return
	}
	state := m.sessions[id]
	state.messages = append(state.messages, current[previousCount:]...)
}

func cloneCollectionState(state collection.State) collection.State {
	rows := make([]collection.Row, len(state.Rows))
	copy(rows, state.Rows)
	state.Rows = rows
	return state
}

func clonePublications(publications []Publication) []Publication {
	result := make([]Publication, len(publications))
	copy(result, publications)
	return result
}

func cloneMessages(messages []gobi.Message) []gobi.Message {
	result := make([]gobi.Message, len(messages))
	copy(result, messages)
	return result
}

func cloneBindings(bindings []inputbinding.Binding) []inputbinding.Binding {
	result := make([]inputbinding.Binding, len(bindings))
	copy(result, bindings)
	return result
}

func validSessionID(id SessionID) error {
	if id == 0 || uint64(id) > collection.MaxID {
		return fmt.Errorf("session ID %d is outside the supported range 1..%d", id, collection.MaxID)
	}
	return nil
}

func isPublishControl(node gobi.Node) bool {
	if strings.HasSuffix(node.Key, "-publish") {
		return true
	}
	for _, handler := range node.On {
		if handler.Message == "publish" {
			return true
		}
	}
	return false
}

func rowAtPublishPath(rows []collection.Row, path string) (collection.Row, error) {
	for index, row := range rows {
		if path == "2/"+strconv.Itoa(index)+"/9" {
			return row, nil
		}
	}
	return collection.Row{}, fmt.Errorf("path %q is not a canonical row publication control", path)
}

func validateEventAt(view inputbinding.View, path, event string) error {
	count := 0
	for _, binding := range view.Bindings {
		if binding.Path == path && binding.Event == event {
			count++
		}
	}
	node, err := nodeAtPath(view.Tree, path)
	if err != nil {
		return err
	}
	for _, handler := range node.On {
		if handler.Event == event {
			count++
		}
	}
	if count == 0 {
		return fmt.Errorf("no %q handler or binding at path %q", event, path)
	}
	if count > 1 {
		return fmt.Errorf("ambiguous %q handlers at path %q", event, path)
	}
	return nil
}

func validateCompositionView(view inputbinding.View) error {
	if err := inputbinding.Validate(view); err != nil {
		return err
	}
	seen := make(map[string]struct{})
	return validateNodeKeys(view.Tree, seen)
}

func validateNodeKeys(node gobi.Node, seen map[string]struct{}) error {
	switch node.Kind {
	case gobi.Element:
		if !validKey(node.Key) {
			return fmt.Errorf("element key %q is not a valid nonempty ASCII token", node.Key)
		}
		if _, exists := seen[node.Key]; exists {
			return fmt.Errorf("duplicate element key %q", node.Key)
		}
		seen[node.Key] = struct{}{}
	case gobi.Text:
		if node.Key != "" {
			return fmt.Errorf("text nodes must have empty keys, got %q", node.Key)
		}
	case gobi.Fragment:
		if node.Key != "" {
			return fmt.Errorf("fragments must have empty keys, got %q", node.Key)
		}
	default:
		return fmt.Errorf("unknown Gobi node kind %d", node.Kind)
	}
	for _, child := range node.Kids {
		if err := validateNodeKeys(child, seen); err != nil {
			return err
		}
	}
	return nil
}

func validKey(value string) bool {
	if len(value) == 0 || len(value) > 64 || !asciiLetter(value[0]) {
		return false
	}
	for index := 1; index < len(value); index++ {
		character := value[index]
		if !asciiLetter(character) && (character < '0' || character > '9') && character != '-' {
			return false
		}
	}
	return true
}

func asciiLetter(character byte) bool {
	return character >= 'A' && character <= 'Z' || character >= 'a' && character <= 'z'
}

func nodeAtPath(root gobi.Node, path string) (gobi.Node, error) {
	if path == "" {
		return root, nil
	}
	current := root
	for _, part := range strings.Split(path, "/") {
		if part == "" || (len(part) > 1 && part[0] == '0') {
			return gobi.Node{}, fmt.Errorf("invalid canonical collection path %q", path)
		}
		for _, character := range part {
			if character < '0' || character > '9' {
				return gobi.Node{}, fmt.Errorf("invalid canonical collection path %q", path)
			}
		}
		index, err := strconv.ParseUint(part, 10, 64)
		if err != nil || index > collection.MaxID {
			return gobi.Node{}, fmt.Errorf("collection path index exceeds the JavaScript-safe integer limit")
		}
		if index >= uint64(len(current.Kids)) {
			return gobi.Node{}, fmt.Errorf("collection path is out of range: %q", path)
		}
		current = current.Kids[int(index)]
	}
	return current, nil
}

func isDisabled(node gobi.Node) bool {
	for _, attr := range node.Attrs {
		if attr.Name == "disabled" && attr.Flag {
			return true
		}
	}
	return false
}
