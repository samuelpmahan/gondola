import { spawn } from "node:child_process";
import { createInterface } from "node:readline";

function errorText(error) {
  return error instanceof Error ? error.message : String(error);
}

function bounded(value, fallback, label) {
  if (value === undefined) return fallback;
  if (!Number.isInteger(value) || value < 1 || value > 60_000) {
    throw new RangeError(`${label} must be an integer from 1 through 60000 milliseconds`);
  }
  return value;
}

/**
 * Start the loopback lab and capture its exit/error promise before readiness
 * can settle. Call close() from finally; its waits are bounded even when a
 * failed spawn has no child process to terminate.
 */
export function startHTTPProcess({
  command,
  args = [],
  cwd,
  spawnImpl = spawn,
  readinessTimeoutMs,
  cleanupTimeoutMs,
} = {}) {
  if (typeof command !== "string" || command.length === 0) throw new TypeError("command must be a nonempty string");
  if (!Array.isArray(args) || args.some((arg) => typeof arg !== "string")) throw new TypeError("args must be strings");
  if (typeof spawnImpl !== "function") throw new TypeError("spawnImpl must be a function");
  const readyTimeout = bounded(readinessTimeoutMs, 10_000, "readinessTimeoutMs");
  const cleanupTimeout = bounded(cleanupTimeoutMs, 2_000, "cleanupTimeoutMs");

  let child;
  try {
    child = spawnImpl(command, args, { cwd, stdio: ["ignore", "pipe", "pipe"] });
  } catch (error) {
    throw new Error(`could not spawn HTTP lab: ${errorText(error)}`, { cause: error });
  }
  if (!child || typeof child.once !== "function" || typeof child.kill !== "function" ||
      !child.stdout || typeof child.stdout.on !== "function" ||
      !child.stderr || typeof child.stderr.on !== "function") {
    throw new TypeError("spawnImpl must return a child process with stdout, stderr, once(), and kill()");
  }

  const lines = createInterface({ input: child.stdout });
  let stderr = "";
  child.stderr.setEncoding?.("utf8");
  child.stderr.on("data", (chunk) => { stderr += String(chunk); });

  let exited = false;
  let exitResult = null;
  let spawnError = null;
  let exitResolve;
  const exit = new Promise((resolve) => { exitResolve = resolve; });
  function finishExit(result) {
    if (exited) return;
    exited = true;
    exitResult = result;
    exitResolve(result);
  }

  let readySettled = false;
  let readyResolve;
  let readyReject;
  let readinessTimer;
  const ready = new Promise((resolve, reject) => {
    readyResolve = resolve;
    readyReject = reject;
  });
  function settleReady(error, value) {
    if (readySettled) return;
    readySettled = true;
    clearTimeout(readinessTimer);
    if (error) readyReject(error);
    else readyResolve(value);
  }
  function readinessError(message, cause) {
    return new Error(`HTTP lab ${message}${stderr ? `: ${stderr.trim()}` : ""}`, cause === undefined ? undefined : { cause });
  }

  child.once("exit", (code, signal) => {
    finishExit({ kind: "exit", code, signal });
    if (!readySettled) {
      settleReady(readinessError(`exited before readiness (code=${code}, signal=${signal})`));
    }
  });
  child.once("error", (error) => {
    spawnError = error;
    finishExit({ kind: "error", error });
    if (!readySettled) settleReady(readinessError(`failed to start: ${errorText(error)}`, error));
  });

  // Real ChildProcess emits exit asynchronously, but preserve a completed
  // state if a test double or future adapter reports it before registration.
  if (child.exitCode !== null && child.exitCode !== undefined) {
    finishExit({ kind: "exit", code: child.exitCode, signal: child.signalCode ?? null });
    settleReady(readinessError(`exited before readiness (code=${child.exitCode}, signal=${child.signalCode ?? null})`));
  } else if (child.signalCode !== null && child.signalCode !== undefined) {
    finishExit({ kind: "exit", code: null, signal: child.signalCode });
    settleReady(readinessError(`exited before readiness (code=null, signal=${child.signalCode})`));
  }

  lines.once("line", (line) => {
    try {
      const result = JSON.parse(line);
      if (typeof result.url !== "string" || result.url.length === 0) throw new Error("readiness record has no url");
      settleReady(null, result.url);
    } catch (error) {
      settleReady(readinessError(`returned invalid readiness data: ${errorText(error)}`, error));
    }
  });
  if (!readySettled) {
    readinessTimer = setTimeout(() => {
      settleReady(readinessError(`readiness timed out after ${readyTimeout} ms`));
    }, readyTimeout);
  }

  let closePromise = null;
  async function close() {
    if (closePromise) return closePromise;
    closePromise = (async () => {
      lines.close();
      if (exited || spawnError) return exitResult;
      try { child.kill("SIGTERM"); }
      catch (error) {
        if (!exited) return { kind: "kill-error", error };
      }

      let timer;
      const wait = (milliseconds) => Promise.race([
        exit,
        new Promise((resolve) => { timer = setTimeout(() => resolve(null), milliseconds); }),
      ]).finally(() => clearTimeout(timer));

      let result = await wait(cleanupTimeout);
      if (result) return result;
      try { child.kill("SIGKILL"); }
      catch (error) {
        if (!exited) return { kind: "kill-error", error };
      }
      result = await wait(cleanupTimeout);
      return result ?? { kind: "timed-out", timeoutMs: cleanupTimeout };
    })();
    return closePromise;
  }

  return { child, lines, ready, exit, close };
}
